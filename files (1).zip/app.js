/* ===== Sürüm denetimi: yeni sürüm varsa sayfayı yeniler (eski <head> betiği) ===== */
(function(){ if(!/^https?:/.test(location.protocol)) return; try{ const now = Date.now(), last = +sessionStorage.getItem('posChk') || 0; if(now - last < 600000) return; sessionStorage.setItem('posChk', now); const f = new URL(location.href); f.searchParams.set('_t', Date.now());
  fetch(f.toString(), { cache: 'no-store' }).then(r => r.text()).then(t => { const m = t.match(/name="build" content="([^"]+)"/), cur = document.querySelector('meta[name=build]').content;
    if(m && m[1] !== cur && sessionStorage.getItem('posReload') !== m[1]){ sessionStorage.setItem('posReload', m[1]); const u = new URL(location.href); u.searchParams.set('_v', m[1]); location.replace(u.toString()); } }).catch(() => {}); }catch(e){} })();
/* ===== Ana ekran / ikon ve manifest oluşturma (eski <head> betiği) ===== */
(function(){ try{ const c = document.createElement('canvas'); c.width = c.height = 192; const x = c.getContext('2d');
  x.fillStyle = '#0F1A2C'; x.fillRect(0,0,192,192); x.fillStyle = '#fff'; x.font = '800 92px system-ui,sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(APP_CONFIG.brand.initials, 96, 100);
  const u = c.toDataURL('image/png'); document.getElementById('appleIcon').href = u;
  if(/^https?:/.test(location.protocol)){ const m = { name:APP_CONFIG.brand.name, short_name:String(APP_CONFIG.brand.line1 || APP_CONFIG.brand.name).slice(0, 12), start_url: location.origin + location.pathname + (window.__cfgId ? '?i=' + window.__cfgId : ''), scope: location.origin + location.pathname.replace(/[^\/]*$/, ''), display:'standalone', background_color:'#ffffff', theme_color:'#0F1A2C', lang:'tr', icons:[{ src:u, sizes:'192x192', type:'image/png', purpose:'any' }] };
    const l = document.createElement('link'); l.rel = 'manifest'; l.href = URL.createObjectURL(new Blob([JSON.stringify(m)], { type:'application/manifest+json' })); document.head.appendChild(l); }
}catch(e){} })();
/* ===== Personel arayüzü <template> yükleyici (eski <body> sonu betiği 1) ===== */

/* Personel arayüzü (ciro, raporlar, ayarlar) ham HTML'de <template> içinde durur: okuma modu / sayfa dönüştürücü / ekran okuyucu / çeviri araçları göremez.
   DOM'a yalnızca personel girişi başarılı olunca takılır. */
(function(){
  const tpl = document.getElementById('staffTpl'), holder = document.createElement('div'), mark = document.createComment('staff');
  holder.appendChild(document.importNode(tpl.content, true));
  tpl.parentNode.insertBefore(mark, tpl); tpl.remove();
  const D = document, g = D.getElementById, q = D.querySelector, qa = D.querySelectorAll;
  D.getElementById = function(id){ return g.call(D, id) || holder.querySelector('#' + CSS.escape(id)); };
  D.querySelector = function(sel){ return q.call(D, sel) || holder.querySelector(sel); };
  D.querySelectorAll = function(sel){ return Array.from(qa.call(D, sel)).concat(Array.from(holder.querySelectorAll(sel))); };
  window.__staffUI = { show(){ while(holder.firstChild) mark.parentNode.insertBefore(holder.firstChild, mark); mark.remove(); delete D.getElementById; delete D.querySelector; delete D.querySelectorAll; window.__staffUI = null; } };
})();

/* ===== Ana uygulama kodu (eski <body> sonu betiği 2) ===== */

  // theme toggle — the one eye-comfort feature
  const body = document.body;
  const eyeToggle = document.getElementById('eyeToggle');
  const eyeIcon = document.getElementById('eyeIcon');
  const eyeLabel = document.getElementById('eyeLabel');
  eyeToggle.addEventListener('click', () => {
    const isDark = body.getAttribute('data-theme') === 'dark';
    body.setAttribute('data-theme', isDark ? 'light' : 'dark');
    eyeIcon.textContent = isDark ? '☀️' : '🌙';
    eyeLabel.textContent = isDark ? 'Göz dinlendirme' : 'Karanlık mod açık';
    try{ localStorage.setItem('posTheme', isDark ? 'light' : 'dark'); }catch(e){}
  });

  // ana gruplar: yalnızca biri açık kalır (akordeon)
  function accOpen(sec){ document.querySelectorAll('.nav-acc').forEach(a => a.classList.toggle('open', a === sec)); }
  document.querySelectorAll('.nav-acc > .nav-label').forEach(h => {
    const tg = () => { const sec = h.parentElement; if(sec.classList.contains('open')) sec.classList.remove('open'); else accOpen(sec); };
    h.addEventListener('click', tg); h.addEventListener('keydown', e => { if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); tg(); } });
  });
  // açılır alt gruplar (durum hatırlanır)
  const FOLD_KEY = 'posFolds';
  function foldState(){ try{ return JSON.parse(localStorage.getItem(FOLD_KEY) || '{}'); }catch(e){ return {}; } }
  function foldSave(k, v){ try{ const st = foldState(); st[k] = v ? 1 : 0; localStorage.setItem(FOLD_KEY, JSON.stringify(st)); }catch(e){} }
  document.querySelectorAll('.nav-fold').forEach(f => {
    if(foldState()[f.dataset.fold]) f.classList.add('open');
    f.querySelector(':scope > .nav-item').addEventListener('click', () => { f.classList.toggle('open'); foldSave(f.dataset.fold, f.classList.contains('open')); });
  });

  // screen switching
  const titles = {
    home: 'Ana Sayfa', settings: 'Ayarlar', users: 'Kullanıcı Ekle',
    perms: 'Yetki / İzin Ekranı', tables: 'Masa / Bölgeler', order: 'Adisyon',
    digitalmenu: 'Dijital Menü', urunler: 'Menü / Ürünler', birimler: 'Birimler',
    ozellikler: 'Özellikler', kdv: 'Kdv Oranları', indirimler: 'İndirimler',
    mutfakgruplari: 'Mutfak Grupları', musteriler: 'Müşteriler', odenmezler: 'Ödenmezler',
    paketler: 'Paket / Gel-Al', 'siparis-masa': 'Sipariş / Masa', gider: 'Gider / Masraf İşlemleri', zayi: 'Zayi İşlemleri',
    'rapor-urun': 'Ürün Satış Raporu', 'rapor-gunsonu': 'Gün Sonu Raporu',
    'rapor-vardiya': 'Vardiya Satış Raporu', 'rapor-istatistik': 'Restaurant İstatistikleri',
    'rapor-fire': 'Fire Raporu', ciro: 'Ciro Takibi', mutfak: 'Mutfak Ekranı'
  };
  function showScreen(name){
    if(!screenAllowed(name)){
      showToast('Bu bölüm için yetkiniz yok.');
      const f = ['home', 'siparis-masa', 'paketler', 'mutfak'].find(screenAllowed);
      if(!f || f === name) return; name = f;
    }
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('show'));
    const el = document.getElementById('screen-' + name);
    if(el) el.classList.add('show');
    document.getElementById('topTitle').textContent = titles[name] || name;
    document.querySelectorAll('.nav-item, .sub-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.sidebar .nav-item[data-screen="' + name + '"]').forEach(n => { n.classList.add('active'); const f = n.closest('.nav-fold'); if(f) f.classList.add('open'); const ac = n.closest('.nav-acc'); if(ac) accOpen(ac); });
    if(name === 'urunler'){ try{ renderCatList(); renderProductGrid(); }catch(e){} }
    if(typeof onScreen === 'function') onScreen(name);
    try{ if(document.body.classList.contains('staff')) sessionStorage.setItem('posScreen', name); }catch(e){}
  }
  document.querySelectorAll('[data-screen]').forEach(el => {
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      const target = el.getAttribute('data-screen');
      showScreen(target);
      el.classList.add('active');
      if(target === 'siparis-masa' && typeof renderSiparisMasa === 'function') renderSiparisMasa();
      if(target === 'rapor-gunsonu' && typeof renderGunSonu === 'function') renderGunSonu();
      if(target === 'digitalmenu') renderDigitalMenu();
    });
  });

  // ---- cart data model: every table, paket and gel-al orders keep their own line items ----
  const carts = {};
  const discountByKey = {}, guestsByKey = {};
  let payLog = [], saleLog = [], closedAt = 0, lists = {}, payTypes = [], uiReady = false;
  let cancelLog = [];
  let extOrders = {}, extSeq = 0, perms = {}, waiveLog = [], colLog = [], dayReports = [], curUser = null;
  let settings = { restName: APP_CONFIG.brand.name, dayStart:'05:00', firstOrderNo:'101', pin:'' };
  const tableLabels = {};
  const tableGuest = {};
  const tname = n => tableGuest[n] || tableLabels[n] || ('Masa ' + n);
  const _e = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const cellName = n => tableGuest[n] ? _e(tableGuest[n]) + '<span class="bn">' + _e(tableLabels[n] || ('Masa ' + n)) + '</span>' : _e(tableLabels[n] || ('Masa ' + n));
  let regions = [
    { name: 'Salon', tables: [1,2,3,4,5,6] },
    { name: 'Bahçe', tables: [7,8,9,10] },
    { name: 'Okey', tables: [11,12,13,14] }
  ];
  let activeRegion = 0;
  let nextTableNo = 15;
  regions.forEach(r => r.tables.forEach(n => { carts['table_' + n] = []; tableLabels[n] = 'Masa ' + n; }));
      let currentCartKey = 'table_1';

  function grossTotal(key){ return (carts[key] || []).reduce((sum, item) => sum + item.unit * item.qty, 0); }
  function cartTotal(key){ const g = grossTotal(key), d = discountByKey[key]; if(!d || !g) return g; const a = d.type === 'pct' ? g * d.v / 100 : d.v; return Math.max(0, Math.round((g - a) * 100) / 100); }

  function renderRegionTabs(){
    const wrap = document.getElementById('regionTabs');
    wrap.innerHTML = '';
    regions.forEach((r, idx) => {
      const t = document.createElement('div');
      t.className = 'region-tab' + (idx === activeRegion ? ' active' : '');
      t.textContent = r.name;
      t.addEventListener('click', () => { activeRegion = idx; renderRegionTabs(); renderTableGrid(); });
      wrap.appendChild(t);
    });
  }

  function renderTableGrid(){
    const grid = document.getElementById('tableGrid');
    grid.innerHTML = '';
    regions[activeRegion].tables.forEach(n => {
      const key = 'table_' + n;
      const total = cartTotal(key);
      const isBusy = carts[key] && carts[key].length > 0;
      const cell = document.createElement('div');
      cell.className = 'plain-table-cell t-' + tableState(n);
      cell.innerHTML = '<span class="pencil" data-n="' + n + '">✎</span>' +
        cellName(n) +
        (isBusy ? '<span class="amt">₺' + total.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</span>' : '');
      cell.addEventListener('click', () => openOrder(key, tname(n), 'tables'));
      cell.querySelector('.pencil').addEventListener('click', async (e) => {
        e.stopPropagation();
        const newName = await uiPrompt('Masa adı (silmek için SİL yazın):', tableLabels[n] || ('Masa ' + n));
        if(newName){
          if(/^s[iİı]l$/i.test(newName.trim())){
            if((carts[key] || []).length){ showToast('Masada açık adisyon var.'); return; }
            regions[activeRegion].tables = regions[activeRegion].tables.filter(x => x !== n); delete carts[key]; delete tableLabels[n];
          } else tableLabels[n] = newName.trim();
          renderTableGrid(); saveState();
        }
      });
      grid.appendChild(cell);
    });
  }
  renderRegionTabs();
  renderTableGrid();

  document.getElementById('btnYeniBolge').addEventListener('click', async () => {
    const name = await uiPrompt('Yeni bölge adı:');
    if(!name) return;
    regions.push({ name, tables: [] });
    activeRegion = regions.length - 1;
    renderRegionTabs(); renderTableGrid();
    showToast('Bölge eklendi: ' + name);
  });
  document.getElementById('btnYeniMasa').addEventListener('click', () => {
    const n = nextTableNo++;
    carts['table_' + n] = [];
    tableLabels[n] = 'Masa ' + n;
    regions[activeRegion].tables.push(n);
    renderTableGrid();
    showToast('Masa ' + n + ' eklendi.');
  });
  document.getElementById('btnTopluMasa').addEventListener('click', async () => {
    const count = parseInt(await uiPrompt('Kaç masa eklensin?', '4')) || 0;
    for(let k = 0; k < count; k++){
      const n = nextTableNo++;
      carts['table_' + n] = [];
      tableLabels[n] = 'Masa ' + n;
      regions[activeRegion].tables.push(n);
    }
    renderTableGrid();
    if(count) showToast(count + ' masa eklendi.');
  });
  document.getElementById('btnBolgeleriDuzenle').addEventListener('click', async () => {
    const r = regions[activeRegion]; if(!r) return;
    const v = await uiPrompt('Bölge adı (bölgeyi silmek için SİL yazın):', r.name); if(!v) return;
    if(/^s[iİı]l$/i.test(v.trim())){
      if(r.tables.some(n => (carts['table_' + n] || []).length)){ showToast('Açık adisyonu olan masalar var, silinemez.'); return; }
      if(regions.length <= 1){ showToast('En az bir bölge kalmalı.'); return; }
      r.tables.forEach(n => { delete carts['table_' + n]; delete tableLabels[n]; });
      regions.splice(activeRegion, 1); activeRegion = 0;
    } else r.name = v.trim();
    renderRegionTabs(); renderTableGrid(); saveState();
  });

  // ======================================================================
  // SİPARİŞ > MASA — operational Bölgeler / Siparişler screen
  // ======================================================================
  let smActiveRegion = 0;
  let smSearch = '';
  const orderOpenedAt = {};

  function smRegionCounts(r){
    const occ = r.tables.filter(n => carts['table_' + n] && carts['table_' + n].length > 0).length;
    return occ + '/' + r.tables.length;
  }

  function renderSmRegionTabs(){
    const wrap = document.getElementById('smRegionTabs');
    wrap.innerHTML = '';
    if(regions[smActiveRegion] && !regionAllowed(regions[smActiveRegion])){ const f = regions.findIndex(regionAllowed); if(f >= 0) smActiveRegion = f; }
    regions.forEach((r, idx) => {
      if(!regionAllowed(r)) return;
      const t = document.createElement('div');
      t.className = 'region-tab' + (idx === smActiveRegion ? ' active' : '');
      t.innerHTML = r.name + ' <span class="badge">' + smRegionCounts(r) + '</span>';
      t.addEventListener('click', () => { smActiveRegion = idx; renderSmRegionTabs(); renderSmTableGrid(); });
      wrap.appendChild(t);
    });
  }

  function renderSmTableGrid(){
    const grid = document.getElementById('smTableGrid');
    grid.innerHTML = '';
    regions[smActiveRegion].tables.forEach(n => {
      const key = 'table_' + n;
      const total = cartTotal(key);
      const isBusy = carts[key] && carts[key].length > 0;
      const label = tname(n);
      const cell = document.createElement('div');
      cell.className = 'sm-pill t-' + tableState(n);
      cell.innerHTML = cellName(n) + (isBusy ? '<span class="amt">₺' + total.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</span>' : '');
      cell.addEventListener('click', () => openOrder(key, label, 'siparis-masa'));
      grid.appendChild(cell);
    });
  }

  function fmtElapsed(ms){
    const s = Math.floor(ms / 1000);
    const hh = String(Math.floor(s / 3600)).padStart(2, '0');
    const mm = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
    const ss = String(s % 60).padStart(2, '0');
    return hh + ':' + mm + ':' + ss;
  }


  function renderSiparisMasa(){
    renderSmRegionTabs();
    renderSmTableGrid();
    renderSmKanban();
  }

  document.getElementById('smTabBolgeler').addEventListener('click', () => {
    document.getElementById('smTabBolgeler').classList.add('active');
    document.getElementById('smTabSiparisler').classList.remove('active');
    document.getElementById('smBolgelerView').style.display = 'block';
    document.getElementById('smSiparislerView').style.display = 'none';
  });
  document.getElementById('smTabSiparisler').addEventListener('click', () => {
    document.getElementById('smTabSiparisler').classList.add('active');
    document.getElementById('smTabBolgeler').classList.remove('active');
    document.getElementById('smBolgelerView').style.display = 'none';
    document.getElementById('smSiparislerView').style.display = 'block';
    renderSmKanban();
  });
  document.getElementById('smOrderSearch').addEventListener('input', (e) => {
    smSearch = e.target.value;
    renderSmKanban();
  });
  document.getElementById('smIconRefresh').addEventListener('click', () => { refreshNow(); });
  document.getElementById('smIconWifi').addEventListener('click', () => showConnInfo());
  setInterval(() => {
    if(document.getElementById('smSiparislerView').style.display === 'none') return;
    document.querySelectorAll('[data-timer-key]').forEach(el => {
      const key = el.getAttribute('data-timer-key');
      if(orderOpenedAt[key]) el.textContent = fmtElapsed(Date.now() - orderOpenedAt[key]);
    });
  }, 1000);

  let currentBackScreen = 'tables';
  function openOrder(key, title, backScreen){
    currentCartKey = key;
    currentBackScreen = backScreen || 'tables';
    mvSel.clear(); mpDraft = [];
    if(key.startsWith('table_')) title = orderLabel(key);
    document.getElementById('orderTableTitle').textContent = title;
    document.getElementById('menuPicker').style.display = 'none';
    document.getElementById('paymentPanel').style.display = 'none';
    renderOrderLines();
    applyOrderPerms();
    showScreen('order');
    if(can('orders') && !paidByKey[key]) openMenuPicker();
  }

  const mvSel = new Set();
  let adisyonSeq = 0;
  const adisyonNoByKey = {};
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const fmtTL = v => '₺' + v.toLocaleString('tr-TR', {minimumFractionDigits:2});

  function afterOrderChange(){
    if(currentCartKey && currentCartKey.startsWith('table_') && !(carts[currentCartKey] || []).length) delete tableGuest[+currentCartKey.slice(6)];
    renderOrderLines();
    renderTableGrid(); renderSiparisMasa(); if(typeof renderPaketler === 'function') renderPaketler();
    saveState();
  }

  function renderOrderLines(){
    const key = currentCartKey, cart = carts[key];
    if(!cart) return;
    for(let i = cart.length - 1; i >= 0; i--){ if(!(cart[i].qty > 0)) cart.splice(i, 1); }
    const container = document.getElementById('orderLines');
    container.innerHTML = '';
    const ed = can('orders');
    cart.forEach(item => {
      const line = document.createElement('div');
      line.className = 'order-line';
      const mvOn = can('move') && key.startsWith('table_');
      line.innerHTML = '' +
        '<div class="qty-ctl"><button class="qbtn" data-d="-1">−</button><b class="qv">' + item.qty + '</b><button class="qbtn" data-d="1">+</button></div>' +
        '<div><div class="name">' + esc(item.name) + '</div><div class="sub">' + esc(item.sub) + ' · ' + fmtTL(item.unit) + (item.sent ? ' · ✔ mutfakta' : '') + '</div>' +
        (item.by ? '<div class="sub ol-by">👤 ' + esc(item.by) + (item.at ? ' · ' + hhmm(item.at) : '') + '</div>' : '') +
        (item.note ? '<div class="sub" style="color:var(--red);">📝 ' + esc(item.note) + '</div>' : '') +
        (ed ? '<span class="link-btn nt">📝 ' + (item.note ? 'Notu düzenle' : 'Not / özellik') + '</span>' : '') + (mvOn ? '<span class="link-btn mvl">⇄ Başka masaya taşı</span>' : '') + '</div>' +
        '<div class="price">' + fmtTL(item.unit * item.qty) + '</div>' +
        '<button class="del-btn" title="Satırı sil">🗑</button>';
      line.querySelectorAll('.qbtn').forEach(btn => btn.addEventListener('click', () => {
        const dd = parseInt(btn.dataset.d), nq = Math.round((item.qty + dd) * 100) / 100;
        if(!itemChange(item, nq)) return;
        if(dd > 0 && uname() && (item.by || '') !== uname()){   // başkasının girdiği satıra ekleme: ekleyen kişi adına ayrı satır
          const sib = cart.find(i => i !== item && i.name === item.name && i.unit === item.unit && (i.note || '') === (item.note || '') && (i.by || '') === uname());
          if(sib) sib.qty += dd; else cart.splice(cart.indexOf(item) + 1, 0, { name: item.name, sub: item.sub, unit: item.unit, qty: dd, note: item.note || '', sent: 0, by: uname(), at: Date.now() });
          afterOrderChange(); return;
        }
        item.qty = nq; if((item.sent || 0) > nq) item.sent = nq;
        afterOrderChange();
      }));
      line.querySelector('.del-btn').addEventListener('click', () => {
        if(!itemChange(item, 0)) return;
        cart.splice(cart.indexOf(item), 1);
        afterOrderChange();
      });
      const nt = line.querySelector('.nt'); if(nt) nt.addEventListener('click', () => editNote(item));
      const mvl = line.querySelector('.mvl'); if(mvl) mvl.addEventListener('click', () => openMoveDialog(item));
      container.appendChild(line);
    });
    if(cart.length && !adisyonNoByKey[key]) adisyonNoByKey[key] = (parseInt(settings.firstOrderNo) || 1) + (adisyonSeq++);
    if(!cart.length) delete adisyonNoByKey[key];
    document.getElementById('adisyonNo').value = adisyonNoByKey[key] || '—';
    document.getElementById('guestNo').value = guestsByKey[key] || 1;
    document.getElementById('orderTotalValue').textContent = fmtTL(cartTotal(key)) + (discountByKey[key] ? ' (indirimli)' : '');
    const paidSoFar = paidByKey[key] || 0;
    let statusText = 'Boş';
    if(cart.length){
      statusText = paidSoFar > 0 ? 'Kısmi Ödendi (' + fmtTL(paidSoFar) + ' alındı)' : 'Hazırlanıyor';
    }
    document.getElementById('orderStatusLabel').textContent = 'Sipariş Durumu: ' + statusText;
    document.getElementById('orderEmptyHint').classList.toggle('show', cart.length === 0);
    updateHomeStats();
  }

  // ---- quick-add from the menu (mirrors Menü/Ürünler categories) ----
  let mpActiveCat = 0, mpSub = -1, mpList = [], mpDraft = [];
  const mpEl = id => document.getElementById(id);
  const draftCount = () => mpDraft.reduce((a, i) => a + i.qty, 0);
  const draftTotal = () => Math.round(mpDraft.reduce((a, i) => a + i.qty * i.unit, 0) * 100) / 100;
  function renderMenuPicker(){
    const groups = menuGroups(categories); if(mpActiveCat >= groups.length) mpActiveCat = 0;
    const q = mpEl('mpSearch').value.trim().toLocaleLowerCase('tr-TR'), saved = carts[currentCartKey] || [];
    const tabs = mpEl('mpTabs'); tabs.innerHTML = '';
    groups.forEach((g, i) => { const t = document.createElement('div'); t.className = 'mp-tab mp-cat' + (i === mpActiveCat && !q ? ' active' : ''); t.innerHTML = catVis(g) + '<span class="lb">' + esc(g.name) + '</span>';
      t.addEventListener('click', () => { mpActiveCat = i; mpSub = -1; mpEl('mpSearch').value = ''; renderMenuPicker(); }); tabs.appendChild(t); });
    const g0 = groups[mpActiveCat] || { subs: [] }, subsEl = mpEl('mpSubs'); subsEl.innerHTML = '';
    if(!q && g0.subs.length > 1){ [{ idx: -1, label: 'Tümü' }].concat(g0.subs).forEach(sb => { const t = document.createElement('div'); t.className = 'mp-tab' + (sb.idx === mpSub ? ' active' : ''); t.textContent = sb.label;
      t.addEventListener('click', () => { mpSub = sb.idx; renderMenuPicker(); }); subsEl.appendChild(t); }); subsEl.style.display = ''; } else subsEl.style.display = 'none';
    mpList = q ? categories.flatMap(c => c.products).filter(p => p.name.toLocaleLowerCase('tr-TR').includes(q)) : g0.subs.filter(sb => mpSub < 0 || sb.idx === mpSub).flatMap(sb => sb.cat.products);
    const grid = mpEl('mpGrid'), st = grid.scrollTop;
    grid.innerHTML = mpList.map((p, i) => { const d = mpDraft.find(it => it.name === p.name && it.unit === p.price), n = d ? d.qty : 0, sv = saved.filter(it => it.name === p.name && it.unit === p.price).reduce((s, it) => s + it.qty, 0);
      return '<div class="mp-card' + (n ? ' in' : '') + '" data-i="' + i + '">' + visHtml(p, '', 'v-mp') + '<b>' + esc(p.name) + '</b>' + (p.desc ? '<small>' + esc(p.desc) + '</small>' : '') + '<span class="pr">' + fmtTL(p.price) + '</span>' + skChip(p.name) + (sv ? '<span class="mp-ex">adisyonda: ' + sv + '</span>' : '') + '<div class="ctl">' +
        (n ? '<button class="mn" aria-label="Azalt">−</button><span class="q">' + n + '</span>' : '<span></span><span></span>') + '<button class="pl" aria-label="Ekle">+</button></div></div>'; }).join('') || '<p style="color:var(--ink-faint);padding:12px">Ürün bulunamadı.</p>';
    grid.scrollTop = st;
    const cnt = draftCount(), tot = cartTotal(currentCartKey);
    mpEl('mpSum').textContent = cnt ? cnt + ' ürün seçildi · ' + fmtTL(draftTotal()) : (tot > 0 ? 'Adisyon: ' + fmtTL(tot) : 'Sepet boş');
    mpEl('mpSave').textContent = cnt ? '🛒 Sepeti Gör (' + cnt + ')' : '🛒 Sepeti Gör';
    mpEl('mpPay').disabled = !(tot > 0) || !can('pay'); mpEl('mpPay').style.display = can('pay') ? '' : 'none';
  }
  function mpChange(p, d){
    if(!can('orders')){ showToast('Sipariş ekleme yetkiniz yok.'); return; }
    const x = mpDraft.find(i => i.name === p.name && i.unit === p.price);
    if(d > 0 && STK.pset.block && stkTracked(p.name) && stkAvail(p.name) - (x ? x.qty : 0) <= 0){ showToast(p.name + (stkAvail(p.name) <= 0 ? ' tükendi.' : ': stokta yeterli adet yok.')); return; }
    if(d > 0){ if(x) x.qty++; else mpDraft.push({ name: p.name, sub: (p.portion || 'tam').toLowerCase(), unit: p.price, qty: 1 }); }
    else if(x){ x.qty--; if(x.qty <= 0) mpDraft.splice(mpDraft.indexOf(x), 1); }
    renderMenuPicker();
  }
  function openMenuPicker(){ if(!can('orders')) return; mpEl('menuPicker').style.display = 'flex'; mpEl('mpCart').classList.remove('show'); mpEl('mpTitle').textContent = '🍽️ ' + orderLabel(currentCartKey); renderMenuPicker(); }
  function closeMenuPicker(){ mpEl('menuPicker').style.display = 'none'; mpEl('mpCart').classList.remove('show'); }
  // ✕ : hiçbir işlem yapmadan masalardan çık
  async function exitPicker(){
    if(mpDraft.length && !await uiConfirm('Sepetteki ' + draftCount() + ' ürün kaydedilmedi. Yine de çıkılsın mı?')) return;
    mpDraft = []; closeMenuPicker();
    if(currentCartKey.startsWith('table_') && !(carts[currentCartKey] || []).length) delete tableGuest[+currentCartKey.slice(6)];
    const back = currentBackScreen || 'siparis-masa';
    showScreen(back); if(back === 'siparis-masa') renderSiparisMasa(); renderTableGrid(); if(typeof renderPaketler === 'function') renderPaketler(); saveState();
  }
  function renderMpCart(){
    const saved = carts[currentCartKey] || [];
    mpEl('mpCartDraft').innerHTML = mpDraft.length ? mpDraft.map((it, i) => '<div class="c-crow"><span>' + esc(it.name) + '<small>' + fmtTL(it.unit) + ' × ' + it.qty + ' = ' + fmtTL(it.unit * it.qty) + '</small></span><div class="qty-ctl"><button class="qbtn" data-i="' + i + '" data-d="-1">−</button><b class="qv">' + it.qty + '</b><button class="qbtn" data-i="' + i + '" data-d="1">+</button></div></div>').join('') : '<p class="mp-empty">Henüz yeni ürün seçilmedi.</p>';
    mpEl('mpCartSaved').innerHTML = saved.length ? saved.map(it => '<div class="c-crow ro"><span>' + it.qty + '× ' + esc(it.name) + (it.note ? ' <small>📝 ' + esc(it.note) + '</small>' : '') + '</span><b>' + fmtTL(it.unit * it.qty) + '</b></div>').join('') : '<p class="mp-empty">Bu masada kayıtlı ürün yok.</p>';
    mpEl('mpCartTot').textContent = fmtTL(draftTotal());
    mpEl('mpCartOk').disabled = !mpDraft.length;
    mpEl('mpCartOk').textContent = mpDraft.length ? '✓ Onayla ve Kaydet · ' + draftCount() + ' ürün' : 'Kaydedilecek ürün yok';
  }
  function commitDraft(){
    if(!mpDraft.length) return;
    const key = currentCartKey, cart = carts[key] = carts[key] || [];
    mpDraft.forEach(d => { const x = cart.find(i => i.name === d.name && i.unit === d.unit && !i.note && (i.by || '') === uname()); if(x) x.qty += d.qty; else cart.push({ name: d.name, sub: d.sub, unit: d.unit, qty: d.qty, by: uname(), at: Date.now() }); });
    mpDraft = []; afterOrderChange(); saveOrderAndExit();
  }
  mpEl('mpGrid').addEventListener('click', e => { const c = e.target.closest('.mp-card'); if(!c) return; const p = mpList[+c.dataset.i]; if(p) mpChange(p, e.target.closest('.mn') ? -1 : 1); });
  mpEl('mpSearch').addEventListener('input', renderMenuPicker);
  mpEl('mpClose').addEventListener('click', exitPicker);
  mpEl('mpSave').addEventListener('click', () => { renderMpCart(); mpEl('mpCart').classList.add('show'); });
  mpEl('mpCartBack').addEventListener('click', () => { mpEl('mpCart').classList.remove('show'); renderMenuPicker(); });
  mpEl('mpCartDraft').addEventListener('click', e => { const b = e.target.closest('.qbtn'); if(!b) return; const it = mpDraft[+b.dataset.i]; if(!it) return; it.qty += +b.dataset.d; if(it.qty <= 0) mpDraft.splice(+b.dataset.i, 1); renderMpCart(); });
  mpEl('mpCartOk').addEventListener('click', commitDraft);
  mpEl('mpPay').addEventListener('click', () => {
    if(!can('pay')){ showToast('Ödeme alma yetkiniz yok.'); return; }
    if(mpDraft.length){ showToast('Önce sepetteki ürünleri kaydedin (Sepeti Gör).'); return; }
    if(cartTotal(currentCartKey) <= 0){ showToast('Sepet boş, ödeme alınamaz.'); return; }
    mpEl('paymentPanel').style.display = 'block'; renderPaymentPanel();
  });
  mpEl('mpAdisyon').addEventListener('click', () => {
    if(mpDraft.length){ showToast('Önce sepetteki ürünleri kaydedin ya da silin.'); return; }
    closeMenuPicker(); renderOrderLines(); showScreen('order'); window.scrollTo(0, 0);
  });
  mpEl('btnToggleMenuPicker').addEventListener('click', openMenuPicker);
  mpEl('ppClose').addEventListener('click', () => { mpEl('paymentPanel').style.display = 'none'; });
  document.addEventListener('keydown', e => { if(e.key === 'Escape'){ mpEl('paymentPanel').style.display = 'none'; mpEl('mpCart').classList.remove('show'); } });
  document.getElementById('btnCustomItem').addEventListener('click', () => {
    if(!can('orders')) return;
    openForm({ title: 'Özel Ürün', fields: [{ id: 'n', label: 'Ürün adı' }, { id: 'u', label: 'Birim fiyat (₺)', type: 'number', step: '0.01', value: 0 }, { id: 'q', label: 'Adet', type: 'number', value: 1 }],
      onOk(v){ if(!v.n) return 'Ürün adı gerekli.'; if(!(v.u >= 0) || !(v.q > 0)) return 'Fiyat ve adet geçerli olmalı.';
        carts[currentCartKey].push({ name: v.n, sub: 'tam', unit: Math.round(v.u * 100) / 100, qty: v.q, by: uname(), at: Date.now() }); afterOrderChange(); showToast(v.n + ' eklendi.'); } });
  });

  // ---- payment: split/partial payment support, closes the table once fully paid ----
  let dailyStats = { sales: 0, guests: 0, cashTotal: 0, cardTotal: 0 };
  let paidByKey = {};
  let paymentHistoryByKey = {};
  const paymentIcons = { 'Nakit':'💵', 'Kredi Kartı':'💳', 'Multinet':'🍽️', 'Smart Ticket':'🎫', 'SetCard':'💳' };

  function remainingForKey(key){
    const paid = paidByKey[key] || 0;
    return Math.max(0, Math.round((cartTotal(key) - paid) * 100) / 100);
  }

  // reads which payment types are switched on in Ayarlar > Ödeme Tipleri (and their current, possibly renamed, labels)
  function getActivePaymentTypes(){ const t = payTypes.filter(p => p.on).map(p => p.name); return t.length ? t : ['Nakit']; }

  function renderPaymentMethods(){
    const wrap = document.getElementById('ppMethods');
    const cls = t => /nakit/i.test(t) ? 'm-nakit' : /a[cç][iı]k/i.test(t) ? 'm-acik' : /kart|multinet|ticket|setcard/i.test(t) ? 'm-kart' : 'm-diger';
    wrap.innerHTML = getActivePaymentTypes().map(t =>
      '<button class="pp-method ' + cls(t) + '" data-method="' + t.replace(/"/g,'&quot;') + '"><span class="mi">' +
      (paymentIcons[t] || (/a[cç][iı]k/i.test(t) ? '📒' : '💳')) + '</span><span>' + esc(t) + '</span></button>'
    ).join('');
  }

  function renderPaymentPanel(){
    const key = currentCartKey;
    const total = cartTotal(key);
    const paid = paidByKey[key] || 0;
    const remaining = remainingForKey(key);
    document.getElementById('ppTitle').textContent = document.getElementById('orderTableTitle').textContent;
    document.getElementById('ppSummaryTotal').textContent = '₺' + total.toLocaleString('tr-TR', {minimumFractionDigits:2});
    document.getElementById('ppSummaryPaid').textContent = '₺' + paid.toLocaleString('tr-TR', {minimumFractionDigits:2});
    document.getElementById('ppSummaryRemaining').textContent = '₺' + remaining.toLocaleString('tr-TR', {minimumFractionDigits:2});
    document.getElementById('ppAmountInput').value = remaining.toFixed(2);
    document.getElementById('ppSplitCount').value = 2;
    const pg = document.getElementById('ppProg'); if(pg) pg.style.width = (total > 0 ? Math.min(100, Math.round(paid / total * 100)) : 0) + '%';
    renderPaymentMethods();
    fillDiscSel();
    const hist = paymentHistoryByKey[key] || [];
    document.getElementById('ppHistory').innerHTML = hist.map(h =>
      '<div class="pp-hist-item"><span>✓ ' + esc(h.method) + '</span><span>₺' + h.amount.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</span></div>'
    ).join('');
  }

  document.getElementById('btnTogglePayment').addEventListener('click', () => {
    const total = cartTotal(currentCartKey);
    if(total <= 0){ showToast('Sepet boş, ödeme alınamaz.'); return; }
    const el = document.getElementById('paymentPanel');
    const show = el.style.display === 'none';
    el.style.display = show ? 'block' : 'none';
    if(show) renderPaymentPanel();
  });

  // hesabı böl: fills the amount field with the per-person share of what's still remaining
  document.getElementById('btnSplitCalc').addEventListener('click', () => {
    const n = Math.max(1, parseInt(document.getElementById('ppSplitCount').value) || 1);
    const share = remainingForKey(currentCartKey) / n;
    document.getElementById('ppAmountInput').value = share.toFixed(2);
    showToast(n + ' kişiye bölündü — kişi başı ₺' + share.toLocaleString('tr-TR', {minimumFractionDigits:2}));
  });


  // settings tabs
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const which = tab.getAttribute('data-tab');
      ['genel','odeme','sistem','marka'].forEach(t => document.getElementById('tab-' + t).style.display = which === t ? 'block' : 'none');
      if(which === 'sistem') updateSysStatus();
    });
  });

  // ---- toast feedback ----
  let toastTimer;
  function showToast(msg, ms){
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), ms || 2200);
  }

  // ---- every toggle switch (payment types, user flags) becomes clickable ----
  function wireToggle(t){
    t.addEventListener('click', (e) => {
      e.stopPropagation();
      const on = t.classList.contains('on');
      t.classList.toggle('on', !on);
      t.classList.toggle('off', on);
    });
  }
  document.querySelectorAll('.mini-toggle').forEach(wireToggle);

  // ---- payment types: add new + keep names editable/renameable ----
  document.getElementById('btnOdemeTipiEkle').addEventListener('click', async () => {
    const name = await uiPrompt('Yeni ödeme tipi adı:');
    if(!name) return;
    payTypes.push({ name: name.trim(), on: true }); renderPayTypes(); saveState(); showToast(name + ' eklendi.');
  });

  // ---- every permission checkbox becomes clickable ----
  document.querySelectorAll('.chk').forEach(c => {
    c.addEventListener('click', (e) => {
      e.stopPropagation();
      const on = c.classList.contains('on');
      c.classList.toggle('on', !on);
      c.textContent = on ? '' : '✓';
    });
  });

  // ---- topbar icons ----
    document.getElementById('btnRefresh').addEventListener('click', () => {
    document.getElementById('btnRefresh').style.transform = 'rotate(360deg)';
    setTimeout(() => { document.getElementById('btnRefresh').style.transform = ''; }, 300);
    refreshNow();
  });

  // ---- settings: Güncelle ----
  document.getElementById('btnGuncelle').addEventListener('click', () => {
    const newName = document.getElementById('setRestName').textContent.trim();
    if(newName){
      document.getElementById('restName').value = newName;
    }
    readSettings(); saveState(); showToast('Ayarlar güncellendi.');
  });

  // ---- gün sonu: Günü Kapat ----

  // ---- generic "+ ... Ekle" buttons across the definition screens ----
  document.querySelectorAll('.btn-add-item-old').forEach(btn => {
    btn.addEventListener('click', async () => {
      const label = btn.textContent.replace('+', '').replace('Ekle', '').trim() || 'Öğe';
      const name = await uiPrompt(label + ' adı girin:');
      if(!name) return;
      const value = await uiPrompt('Değer / not (opsiyonel, boş bırakılabilir):', '');
      const panel = btn.closest('.panel-card');
      const list = panel.querySelector('.plist');
      const row = document.createElement('div');
      row.className = 'prow';
      row.innerHTML = '<span class="pic">＋</span><div class="pmain"><b>' + name.replace(/</g,'&lt;') + '</b></div>' +
        (value ? '<span class="pval">' + value.replace(/</g,'&lt;') + '</span>' : '');
      list.appendChild(row);
      showToast(name + ' eklendi.');
    });
  });


  // ---- order ticket: edit mode, print, customer, save (cart-aware) ----
  let orderEditMode = false;
    document.getElementById('btnPrintOrder').addEventListener('click', () => printReceipt());
    document.getElementById('btnOrderBack').addEventListener('click', () => {
    showScreen(currentBackScreen);
    if(currentBackScreen === 'siparis-masa') renderSiparisMasa();
  });
  // ---- kayıt onay bannerı (büyük, yeşil/kırmızı) ----
  let sbTimer;
  function showSaveBanner(title, sub, isErr, ms){
    const b = document.getElementById('saveBanner');
    document.getElementById('sbT').textContent = title; document.getElementById('sbS').textContent = sub || '';
    b.classList.toggle('err', !!isErr); b.querySelector('.sb-ic').textContent = isErr ? '!' : '✓';
    b.classList.add('show'); clearTimeout(sbTimer); sbTimer = setTimeout(() => b.classList.remove('show'), ms || (isErr ? 4500 : 3500));
    try{ if(navigator.vibrate) navigator.vibrate(isErr ? [120, 80, 120] : 90); }catch(e){}
  }
  // KAYDET: mutfağa gönder → Sipariş/Masa ekranına dön → onay göster (hata olursa aynı ekranda kal)
  function saveOrderAndExit(){
    if(!can('orders')){ showToast('Yetkiniz yok.'); return; }
    const key = currentCartKey, label = orderLabel(key);
    if(!(carts[key] || []).length){ showSaveBanner('Sepet boş', 'Önce menüden ürün ekleyin.', true); return; }
    try{
      sendToKitchen();
      const total = cartTotal(key);
      renderTableGrid(); renderSiparisMasa(); if(typeof renderPaketler === 'function') renderPaketler();
      saveState();
      closeMenuPicker();
      const back = currentBackScreen === 'paketler' ? 'paketler' : 'siparis-masa';
      showScreen(back); if(back === 'siparis-masa') renderSiparisMasa();
      window.scrollTo(0, 0);
      showSaveBanner('Sipariş ' + label + ' için kaydedildi', 'Toplam ' + fmtTL(total) + ' · mutfağa iletildi');
    }catch(err){
      console.error(err);
      showSaveBanner('Kaydedilemedi!', 'Bir hata oluştu, tekrar deneyin.', true);
    }
  }
  document.getElementById('btnSaveOrder').addEventListener('click', saveOrderAndExit);

  // ======================================================================
  // MENÜ / ÜRÜNLER — categories with product cards
  // ======================================================================
  // ---- hazır örnek menü: [kategori, ikon, mutfak grubu, [[ürün, ikon, fiyat TL], ...]] ----
  const SEED_MENU = [
    ["Kahvaltı","🍳","Mutfak",[["Serpme Kahvaltı (2 Kişilik)","🍽️",950],["Kahvaltı Tabağı","🍳",400],["Peynir Tabağı","🧀",250],["Söğüş Tabağı","🥒",100],["Zeytin","🫒",80],["Bal Kaymak","🍯",250],["Reçeller","🍓",100],["Sosis Tava","🌭",220]]],
    ["Yumurta Çeşitleri","🥚","Mutfak",[["Sahanda Yumurta","🍳",150],["Peynirli Omlet","🧀",180],["Sucuklu Yumurta","🥓",230],["Kavurmalı Yumurta","🥩",300],["Menemen","🍅",220],["Kavurmalı Menemen","🥩",300],["Kaşarlı Menemen","🧀",250],["Sucuklu Menemen","🥓",270],["Kaşarlı Sucuklu Menemen","🧀",300]]],
    ["Çorbalar","🍲","Mutfak",[["Mercimek Çorbası","🍲",120]]],
    ["Ana Yemekler","🍖","Mutfak",[["Saç Tava (Kuzu)","🍖",450],["Et Sote","🥘",420],["Tavuk Sote","🍗",330],["Kasap Köfte","🧆",380],["Kiremitte Kaşarlı Köfte","🧆",400],["Kuzu Pirzola","🥩",650],["Tavuk Izgara","🍗",330],["Tavuk Şinitsel","🍗",350],["Köri Soslu Tavuk","🍛",350],["Soya Soslu Tavuk","🍗",350],["Çıtır Tavuk","🍗",330]]],
    ["Tost, Burger & Hamur İşleri","🥪","Mutfak",[["Sucuklu Kaşarlı Tost","🥪",200],["Yumurtalı Sucuklu Kaşarlı Tost","🥪",240],["Kavurmalı Kaşarlı Tost","🥪",260],["Hamburger","🍔",340],["Gözleme","🫓",220],["Sigara Böreği","🥟",180]]],
    ["Makarna & Mantı","🍝","Mutfak",[["Bolonez Makarna","🍝",240],["Tavuklu Mantarlı Makarna","🍄",260],["Arabiata Makarna","🌶️",220],["Ton Balıklı Makarna","🐟",260],["Napoliten Makarna","🍅",210],["Sade Makarna","🍝",160],["Mantı","🥟",260]]],
    ["Salatalar","🥗","Mutfak",[["Çoban Salata","🥗",160],["Mevsim Salata","🥬",170],["Kaşık Salata","🥄",170],["Ton Balıklı Salata","🐟",270],["Gavurdağı Salata","🥗",220],["Tavuklu Sezar Salata","🍗",280],["Greek Salata","🫒",220],["Hellim Peynirli Salata","🧀",270]]],
    ["Tatlılar","🍰","Mutfak",[["Supangle","🍮",150],["Fırın Sütlaç","🍮",140],["Profiterol","🍩",170],["Trileçe","🍰",150],["Fıstıklı Baklava","🥮",280],["Cevizli Baklava","🥮",230],["Soğuk Baklava","🥮",200],["Meyveli Yaş Pasta","🎂",180],["Meyve Tabağı (Mevsimlik)","🍉",250]]],
    ["Dondurma","🍦","Bar",[["Vanilya Dondurma","🍦",120],["Çikolata Dondurma","🍫",120],["Muz Dondurma","🍌",120],["Limon Dondurma","🍋",120],["Karamel Dondurma","🍮",120],["Çilek Dondurma","🍓",120]]],
    ["Çerez & Atıştırmalık","🥜","Bar",[["Dakota Çekirdek","🌻",100],["Leblebi","🫘",100],["Kabak Çekirdeği","🎃",120],["Fındık","🌰",180],["Antep Fıstığı","🥜",250],["Karışık Çerez","🥜",220],["Cips","🍟",130]]],
    ["Sıcak İçecekler","🥛","Bar",[["Sahlep","🥛",150],["Damla Sakızlı Sahlep","🥛",170],["Sıcak Çikolata","🍫",150],["Sütlü Kakao","🥛",120],["Ballı Süt","🍯",110],["Sıcak Süt","🥛",90],["Çay","🍵",40],["Chai Tea Latte","🫖",190],["Nane Limon Oralet","🌿",70],["Kuşburnu Oralet","🌹",70],["Muz Oralet","🍌",70],["Limon Oralet","🍋",70],["Elma Oralet","🍎",70],["Kivi Oralet","🥝",70],["Portakal Oralet","🍊",70],["Atom Oralet","⚡",70]]],
    ["Bitki Çayları","🍵","Bar",[["Ihlamur","🌼",80],["Adaçayı","🌿",80],["Kış Çayı","❄️",90],["Papatya","🌼",80],["Rezene","🌱",80],["Tarçın & Karanfil Çayı","🍂",80],["Tarçın Çayı","🍂",80],["Yeşil Çay","🍃",90]]],
    ["Türk Kahveleri","🫖","Bar",[["Türk Kahvesi","☕",110],["Sütlü Türk Kahvesi","☕",130],["Damla Sakızlı Türk Kahvesi","☕",130],["Duble Türk Kahvesi","☕",180],["Dibek Kahvesi","☕",140],["Menengiç Kahvesi","☕",140],["Osmanlı Kahvesi","☕",120]]],
    ["Espresso","🤎","Bar",[["Classic Espresso","☕",150],["Colombia Espresso","☕",160],["Costa Rica Espresso","☕",160],["Kakule Espresso","☕",170],["Beyaz Çikolata Espresso","🤍",180],["French Vanilya Espresso","🍦",180],["Swiss Chocolate Espresso","🍫",180],["Chocolate Raspberry Espresso","🍫",190]]],
    ["Sıcak Kahveler","☕","Bar",[["Filtre Kahve","☕",130],["Americano","☕",150],["Cappuccino","☕",170],["Caffe Latte","🥛",170],["Caramel Macchiato","🍮",190],["Caffe Mocha","🍫",190],["White Chocolate Mocha","🤍",200],["Nescafe","☕",110]]],
    ["Soğuk Kahveler","🧊","Bar",[["Iced Latte","🧊",180],["Iced Americano","🧊",160],["Iced Mocha","🧊",200],["Iced Chocolate","🍫",190]]],
    ["Frozen","❄️","Bar",[["Mango Frozen","🥭",180],["Elma Frozen","🍎",180],["Çilek Frozen","🍓",180],["Kivi Frozen","🥝",180],["Şeftali Frozen","🍑",180],["Limon Frozen","🍋",180],["Muz Frozen","🍌",180]]],
    ["Milkshake","🥤","Bar",[["Muz Milkshake","🍌",190],["Çilek Milkshake","🍓",190],["Vanilya Milkshake","🍦",190],["Çikolata Milkshake","🍫",190],["Karamel Milkshake","🍮",190],["Vişne Milkshake","🍒",190],["Limon Milkshake","🍋",190],["Portakal Milkshake","🍊",190],["Mango Milkshake","🥭",190],["Elma Milkshake","🍎",190],["Kivi Milkshake","🥝",190],["Şeftali Milkshake","🍑",190]]],
    ["Taze Sıkma & Limonata","🍋","Bar",[["El Yapımı Limonata","🍋",130],["Portakal Suyu (Sıkma)","🍊",150],["Mandalina Suyu (Sıkma)","🍊",150],["Nar Suyu (Sıkma)","🍹",170]]],
    ["Soda","💧","Bar",[["Sade Soda","💧",50],["Limonlu Soda","🍋",70],["Elmalı Soda","🍎",70],["Vişneli Soda","🍒",70],["Çilekli Soda","🍓",70],["Çilek-Karpuzlu Soda","🍉",70],["Churchill","🧂",90]]],
    ["Soğuk İçecekler","🥫","Bar",[["Coca Cola","🥤",80],["Sprite","🥤",80],["Fanta","🥤",80],["Burn (Enerji İçeceği)","⚡",120],["Ayran","🥛",50],["Su","💧",25],["Fuse Tea Mango","🥭",90],["Fuse Tea Şeftali","🍑",90],["Fuse Tea Limon","🍋",90],["Fuse Tea Karpuz","🍉",90],["Cappy Vişne","🍒",80],["Cappy Şeftali","🍑",80],["Cappy Karışık","🧃",80]]],
    ["Nargile","💨","Nargile",[["Anason Nargile","🌱",450],["Çilek Nargile","🍓",450],["Yanık Şeftali Nargile","🍑",450],["Limon Nargile","🍋",450],["Şeftali Nargile","🍑",450],["Karpuz Nargile","🍉",450],["Kavun Nargile","🍈",450],["Karadut Nargile","🍇",450],["Yaban Mersini Nargile","🫐",450],["Elma Nargile","🍎",450],["Portakal Nargile","🍊",450],["Gül Nargile","🌹",450],["Ice Şeftali Nargile","🧊",450],["Nane Nargile","🌿",450],["Üzüm Nargile","🍇",450],["Kapuçino Nargile","☕",500],["Vivident Nargile","💨",500],["Lady Killer Nargile","💋",500],["Love 66 Nargile","❤️",500],["Pink Nargile","🌸",500],["Brownie Nargile","🍫",500],["Ice Bom Bom Nargile","🧊",500],["İzmir Romantik Nargile","💐",500],["Limon Cheesecake Nargile","🍰",500],["Kola Nargile","🥤",500],["Bisküvit Nargile","🍪",500]]]
  ];
  const SEED_GROUPS = ['Mutfak', 'Bar', 'Nargile'];

  // ---- ANA KATEGORİ / ALT KATEGORİ (mevcut menü silinmeden gruplanır) ----
  const MENU_GROUPS = [['Kahvaltı & Yumurta','🍳'],['Yemekler','🍽️'],['Tatlı & Atıştırmalık','🍰'],['Kahveler','☕'],['Sıcak İçecekler','🍵'],['Soğuk İçecekler','🥤'],['Nargile','💨']];
  const OLD_GROUP_OF = {
    'Tost, Burger & Hamur İşleri':['Yemekler'], 'Makarna & Mantı':['Yemekler'], 'Salatalar':['Yemekler'], 'Tatlılar':['Yemekler'], 'Çerez & Atıştırmalık':['Yemekler'],
    'Frozen':['Soğuk İçecekler'], 'Milkshake':['Soğuk İçecekler'], 'Taze Sıkma & Limonata':['Soğuk İçecekler'], 'Soda':['Soğuk İçecekler'], 'Soğuk İçecekler':['Soğuk İçecekler','Hazır İçecekler'],
    'Sıcak İçecekler':['Sıcak İçecekler','Çaylar & Sıcaklar'], 'Bitki Çayları':['Sıcak İçecekler'], 'Dondurma':['Dondurmalar'],
    'Türk Kahveleri':['Kahveler'], 'Espresso':['Kahveler'], 'Sıcak Kahveler':['Kahveler'], 'Soğuk Kahveler':['Kahveler'], 'Nargile':['Nargileler']
  };
  // [üst kategori, alt kategori etiketi] — sıra aynı zamanda alt kategorilerin görünme sırası
  const GROUP_OF = {
    'Kahvaltı':['Kahvaltı & Yumurta','Kahvaltı'], 'Yumurta Çeşitleri':['Kahvaltı & Yumurta','Yumurtalar'],
    'Çorbalar':['Yemekler','Çorbalar'], 'Salatalar':['Yemekler','Salatalar'], 'Ana Yemekler':['Yemekler','Ana Yemekler'], 'Makarna & Mantı':['Yemekler','Makarna & Mantı'], 'Tost, Burger & Hamur İşleri':['Yemekler','Tost & Hamur İşleri'],
    'Tatlılar':['Tatlı & Atıştırmalık','Tatlılar'], 'Dondurma':['Tatlı & Atıştırmalık','Dondurma'], 'Çerez & Atıştırmalık':['Tatlı & Atıştırmalık','Çerez & Atıştırmalık'],
    'Türk Kahveleri':['Kahveler','Türk Kahvesi'], 'Sıcak Kahveler':['Kahveler','Sıcak Kahveler'], 'Espresso':['Kahveler','Espresso'], 'Soğuk Kahveler':['Kahveler','Soğuk Kahveler'],
    'Sıcak İçecekler':['Sıcak İçecekler','Çaylar & Sıcaklar'], 'Bitki Çayları':['Sıcak İçecekler','Bitki Çayları'],
    'Frozen':['Soğuk İçecekler','Frozen'], 'Milkshake':['Soğuk İçecekler','Milkshake'], 'Taze Sıkma & Limonata':['Soğuk İçecekler','Taze Sıkma & Limonata'], 'Soda':['Soğuk İçecekler','Soda'], 'Soğuk İçecekler':['Soğuk İçecekler','Hazır İçecekler'],
    'Nargile':['Nargile']
  };
  const SUB_ORDER = Object.keys(GROUP_OF);
  const OLD_IMG = /^https?:\/\/(www\.)?karekodrestaurantmenu\.com\//i;
  const oldImg = u => OLD_IMG.test(u || '');
  function stripOldImgs(cats){ (cats || []).forEach(c => { if(oldImg(c.img)) c.img = ''; (c.products || []).forEach(pr => { if(oldImg(pr.img)) pr.img = ''; }); }); return cats; }
  function migrateMenuGroups(cats){ (cats || []).forEach(c => {
    const nm = GROUP_OF[c.name];
    if(nm && c.gv !== 3){ const o = OLD_GROUP_OF[c.name], og = o ? o[0] : c.name, os = (o && o[1]) || '';
      if(!c.grp || c.gv !== 2 || (c.grp === og && (c.sub || '') === os)){ c.grp = nm[0]; c.sub = nm[1] || ''; c.gv = 2; } }
    else if(!c.grp){ const k = String(c.name).split(' / '); c.grp = k.length > 1 ? k[0] : c.name; if(k.length > 1) c.sub = k.slice(1).join(' / '); }
  }); return cats; }
  function menuGroups(cats){
    migrateMenuGroups(cats); const gmArr = cats._gm || (typeof groupMeta !== 'undefined' ? groupMeta : []) || [], gmOf = n => gmArr.find(x => x && x.name === n) || {}, m = new Map();
    cats.forEach((c, i) => { const g = c.grp || c.name, mt = gmOf(g);
      if(!m.has(g)) m.set(g, { name: g, icon: mt.icon || (MENU_GROUPS.find(x => x[0] === g) || [])[1] || c.icon || '', img: mt.img || '', fi: m.size, subs: [] });
      if(c.img && !c.sub && !m.get(g).img) m.get(g).img = c.img;
      m.get(g).subs.push({ idx: i, label: c.sub || c.name, cat: c }); });
    m.forEach(g => g.subs.sort((x, y) => { const a = SUB_ORDER.indexOf(x.cat.name), b = SUB_ORDER.indexOf(y.cat.name); return (a < 0 ? 999 : a) - (b < 0 ? 999 : b); }));
    const order = MENU_GROUPS.map(x => x[0]);
    const key = g => { const mt = gmOf(g.name); if(typeof mt.ord === 'number' && mt.ord >= 0) return mt.ord; const x = order.indexOf(g.name); return x < 0 ? 100 + g.fi : x; };
    return [...m.values()].sort((a, b) => key(a) - key(b));
  }
  // ---- çizim (illüstrasyon) üretici: ürün/kategori adına göre uyumlu görsel ----
  const FLV = [[/çilek/,'#ff5c8a'],[/vişne/,'#b3132f'],[/şeftali/,'#ffae73'],[/mango/,'#ffb62e'],[/limon/,'#f4e04d'],[/elma/,'#9bd44e'],[/kivi/,'#8bc34a'],[/portakal|mandalina/,'#ff9a1f'],[/muz/,'#ffe07a'],[/karpuz/,'#ff6f7d'],[/kavun/,'#ffd27a'],[/karadut|üzüm/,'#7b3fa0'],[/yaban/,'#4b3f9e'],[/nar/,'#b3123d'],[/gül|pink|love|lady|romantik/,'#ff7fa8'],[/nane|anason|yeşil|adaçay|rezene/,'#5fc98a'],[/çikolata|kakao|brownie|mocha|kahve|espresso|latte|americano|nescafe|kapu|macchiato|dibek|menengiç|kola|cola|profiterol|supangle/,'#6b3a1e'],[/karamel|bal|baklava/,'#d8892b'],[/vanilya|ayran|sahlep|süt|beyaz|trileçe|sütlaç/,'#f3e7cf'],[/fanta|burn|atom/,'#ff8a1f'],[/sprite|soda|^su$/,'#bfe6f5'],[/cappy/,'#e0532d'],[/fıstı|fuse/,'#a9c75a'],[/ıhlamur|papatya|kış|tarçın/,'#e9c46a'],[/çay/,'#c2531f'],[/[iı]ce|buz/,'#9fe3ff']];
  const flv = n => { for(const [r, c] of FLV) if(r.test(n)) return c; return 'hsl(' + artHue(n) + ',70%,60%)'; };
  const KINDS = [[/nargile/,'hookah'],[/dondurma/,'cone'],[/milkshake/,'shake'],[/frozen/,'frozen'],[/^soğuk kahveler$|[iı]ced/,'iced'],[/soda|limonata|sıkma|taze|churchill/,'glass'],[/^soğuk içecekler$|coca|sprite|fanta|burn|fuse|cappy/,'can'],[/ayran|^su$/,'glass'],[/oralet|çay|ıhlamur|adaçayı|rezene|papatya|bitki|^sıcak içecekler$/,'tea'],[/türk kahve|dibek|menengiç|osmanlı|espresso/,'cup'],[/kahve|latte|cappuccino|americano|mocha|macchiato|nescafe|sahlep|kakao|sıcak|süt/,'mug'],[/baklava/,'baklava'],[/tatlı|supangle|sütlaç|profiterol|trileçe|pasta|karamel|meyve/,'cake'],[/salata/,'salad'],[/çorba/,'soup'],[/makarna/,'pasta'],[/mantı/,'manti'],[/hamburger/,'burger'],[/tost/,'toast'],[/gözleme|böreği|hamur/,'roll'],[/yumurta|omlet|menemen/,'egg'],[/kahvaltı|peynir|söğüş|zeytin|reçel|sosis|bal kaymak/,'break'],[/çerez|çekirdek|leblebi|fındık|fıstı|cips|atıştır/,'nuts'],[/köfte|tavuk|sote|pirzola|kuzu|saç|şinitsel|ana yemek|yemekler|et /,'meat']];
  const SH = '<ellipse cx="100" cy="134" rx="60" ry="7" fill="#000" opacity=".14"/>', PL = SH + '<ellipse cx="100" cy="82" rx="76" ry="48" fill="#fff"/><ellipse cx="100" cy="82" rx="58" ry="35" fill="#f1f1f1"/>', STM = '<path d="M88 36q-6-10 0-20M108 36q-6-10 0-20" stroke="#fff" stroke-width="4" fill="none" opacity=".75" stroke-linecap="round"/>';
  const gl = (c, top) => SH + '<path d="M66 30h68l-9 100H75z" fill="#fff" fill-opacity=".5" stroke="#fff" stroke-width="3"/><path d="M70 58h60l-5 70H75z" fill="' + c + '"/><path d="M78 40l6 80" stroke="#fff" stroke-width="4" opacity=".5" stroke-linecap="round"/><rect x="84" y="70" width="16" height="16" rx="3" fill="#fff" opacity=".45"/><rect x="104" y="92" width="16" height="16" rx="3" fill="#fff" opacity=".35"/>' + (top || '');
  const STRAW = '<path d="M112 10l-10 72" stroke="#e53935" stroke-width="5" stroke-linecap="round"/>';
  const D = {
    glass: c => gl(c, STRAW + '<circle cx="134" cy="34" r="12" fill="' + c + '" stroke="#fff" stroke-width="3"/><path d="M134 24v20M124 34h20" stroke="#fff" stroke-width="2" opacity=".7"/>'),
    shake: c => gl(c, STRAW + '<ellipse cx="100" cy="32" rx="34" ry="12" fill="#fff"/><ellipse cx="100" cy="24" rx="22" ry="10" fill="#fff"/><circle cx="100" cy="12" r="7" fill="#d81b3c"/>'),
    frozen: c => gl(c, STRAW + '<path d="M64 40q8-24 36-24t36 24z" fill="' + c + '"/><path d="M70 34q8-14 26-16" stroke="#fff" opacity=".6" fill="none" stroke-width="3"/>'),
    iced: () => gl('#8a5a3a', '<path d="M70 58h60l-2 24H72z" fill="#f3e7cf"/>' + STRAW),
    can: c => SH + '<rect x="68" y="26" width="64" height="100" rx="10" fill="' + c + '"/><rect x="68" y="26" width="64" height="12" rx="6" fill="#cfd8dc"/><rect x="68" y="114" width="64" height="12" rx="6" fill="#b0bec5"/><path d="M68 62q32 20 64 0v30q-32 20-64 0z" fill="#fff" opacity=".9"/><circle cx="100" cy="77" r="9" fill="' + c + '"/><rect x="76" y="40" width="6" height="70" rx="3" fill="#fff" opacity=".28"/>',
    cup: c => SH + '<ellipse cx="100" cy="120" rx="52" ry="10" fill="#fff"/><path d="M62 70h76q0 46-38 46t-38-46z" fill="#fff" stroke="#e3e3e3" stroke-width="2"/><path d="M138 78q22 2 18 18t-30 12" fill="none" stroke="#fff" stroke-width="7"/><ellipse cx="100" cy="70" rx="38" ry="9" fill="' + c + '"/>' + STM,
    mug: c => SH + '<rect x="58" y="48" width="76" height="74" rx="16" fill="#fff"/><path d="M134 62q30 0 26 22t-26 20" fill="none" stroke="#fff" stroke-width="9"/><ellipse cx="96" cy="50" rx="38" ry="9" fill="' + c + '"/><path d="M96 54c-10-8-18 2-8 10l8 7 8-7c10-8 2-18-8-10z" fill="#fff" opacity=".75"/>' + STM.replace(/M88 36/, 'M80 36').replace(/M108 36/, 'M100 36'),
    tea: c => SH + '<path d="M74 50q0 62 26 62t26-62z" fill="#fff" fill-opacity=".55" stroke="#fff" stroke-width="3"/><path d="M77 66q2 44 23 44t23-44z" fill="' + c + '"/><ellipse cx="100" cy="118" rx="44" ry="8" fill="#fff"/>' + STM,
    cone: c => SH + '<path d="M72 74h56l-28 56z" fill="#e0a45a"/><path d="M80 82h40M88 98h24" stroke="#c4843a" stroke-width="3"/><circle cx="100" cy="62" r="30" fill="' + c + '"/><circle cx="100" cy="32" r="22" fill="' + c + '"/><circle cx="94" cy="26" r="8" fill="#fff" opacity=".3"/><circle cx="108" cy="12" r="6" fill="#d81b3c"/>',
    hookah: c => SH + '<path d="M80 108q-14-26 8-44h24q22 18 8 44q-20 10-40 0z" fill="' + c + '"/><path d="M90 126h20l10-18q-20 10-40 0z" fill="#455a64"/><path d="M96 64h8V44h-8z" fill="#90a4ae"/><path d="M84 44h32l-6-14H90z" fill="#78909c"/><ellipse cx="100" cy="29" rx="14" ry="5" fill="#ff7043"/><path d="M118 90q36 4 40-24" fill="none" stroke="#5d4037" stroke-width="5" stroke-linecap="round"/>',
    break: () => PL + '<ellipse cx="78" cy="78" rx="20" ry="15" fill="#fff" stroke="#e0e0e0"/><circle cx="78" cy="78" r="7" fill="#ffb300"/><circle cx="122" cy="70" r="12" fill="#e53935"/><ellipse cx="108" cy="98" rx="7" ry="5" fill="#33411f"/><ellipse cx="124" cy="100" rx="7" ry="5" fill="#556b2f"/><path d="M70 102l24-8v14z" fill="#ffe082"/><circle cx="98" cy="62" r="8" fill="#8bc34a"/>',
    egg: (c, n) => SH + '<path d="M150 84h40" stroke="#37474f" stroke-width="10" stroke-linecap="round"/><circle cx="100" cy="80" r="52" fill="#37474f"/><circle cx="100" cy="80" r="43" fill="#546e7a"/>' + (/menemen/.test(n) ? '<ellipse cx="100" cy="80" rx="35" ry="29" fill="#e5532d"/><circle cx="90" cy="74" r="6" fill="#ffd54f"/><circle cx="112" cy="88" r="5" fill="#ffd54f"/>' : '<ellipse cx="100" cy="82" rx="34" ry="26" fill="#fff"/><circle cx="100" cy="82" r="12" fill="#ffb300"/>'),
    meat: (c, n) => { const m = /tavuk|şinitsel/.test(n) ? '#e0a040' : /köfte/.test(n) ? '#8d5524' : '#a0522d'; return PL + '<ellipse cx="80" cy="80" rx="20" ry="14" fill="' + m + '"/><ellipse cx="112" cy="72" rx="20" ry="14" fill="' + m + '"/><ellipse cx="108" cy="98" rx="20" ry="12" fill="' + m + '"/><circle cx="136" cy="96" r="7" fill="#7cb342"/><circle cx="68" cy="100" r="6" fill="#e53935"/>'; },
    soup: () => SH + '<path d="M42 70h116q0 50-58 50t-58-50z" fill="#fff"/><ellipse cx="100" cy="70" rx="58" ry="12" fill="#f0a030"/>' + STM,
    pasta: (c, n) => { const r = /bolonez/.test(n) ? '#a8321f' : /mantar|tavuk/.test(n) ? '#d8c3a0' : /ton/.test(n) ? '#e8836a' : /sade/.test(n) ? '#f3d27a' : '#d8432b'; return PL + '<g stroke="#f3d27a" stroke-width="5" fill="none" stroke-linecap="round"><path d="M64 84q36-40 72 0M68 92q32-30 64 0M74 76q26-20 52 0"/></g><ellipse cx="100" cy="72" rx="20" ry="9" fill="' + r + '"/><circle cx="100" cy="68" r="4" fill="#43a047"/>'; },
    manti: () => PL + '<ellipse cx="100" cy="80" rx="34" ry="22" fill="#fff"/><circle cx="88" cy="78" r="8" fill="#f0c36a"/><circle cx="108" cy="74" r="8" fill="#f0c36a"/><circle cx="104" cy="92" r="8" fill="#f0c36a"/><circle cx="90" cy="94" r="3" fill="#e53935"/>',
    salad: () => SH + '<path d="M38 72h124q-4 46-62 46t-62-46z" fill="#fff"/><ellipse cx="100" cy="72" rx="62" ry="14" fill="#66bb6a"/><circle cx="82" cy="68" r="9" fill="#e53935"/><circle cx="112" cy="66" r="9" fill="#e53935"/><circle cx="98" cy="74" r="7" fill="#c5e1a5"/><path d="M120 76q14-10 24 0" stroke="#2e7d32" stroke-width="5" fill="none"/>',
    burger: () => SH + '<path d="M50 74q0-44 50-44t50 44z" fill="#e0a040"/><rect x="44" y="76" width="112" height="10" rx="5" fill="#7cb342"/><rect x="48" y="86" width="104" height="16" rx="8" fill="#6d3b1d"/><path d="M50 102h100q0 22-50 22t-50-22z" fill="#e0a040"/><circle cx="84" cy="52" r="3" fill="#fff3c4"/><circle cx="106" cy="44" r="3" fill="#fff3c4"/><circle cx="124" cy="56" r="3" fill="#fff3c4"/>',
    toast: () => SH + '<rect x="50" y="42" width="100" height="26" rx="12" fill="#e8b25a"/><rect x="46" y="68" width="108" height="8" fill="#fdd835"/><rect x="46" y="76" width="108" height="7" fill="#c0392b"/><rect x="50" y="83" width="100" height="28" rx="12" fill="#e8b25a"/><path d="M66 50v12M86 50v12M106 50v12M126 50v12" stroke="#c98a2e" stroke-width="3"/>',
    roll: () => SH + '<rect x="46" y="62" width="108" height="46" rx="22" fill="#e6b45a"/><path d="M62 70v30M82 70v30M102 70v30M122 70v30" stroke="#c98a2e" stroke-width="4" opacity=".6"/>',
    cake: c => SH + '<path d="M52 112V76l96-18v54z" fill="#fff3e0"/><path d="M52 92l96-18v10l-96 18z" fill="' + c + '"/><path d="M52 76l96-18q-4-12-18-10L66 62q-12 2-14 14z" fill="' + c + '" opacity=".85"/><circle cx="130" cy="44" r="7" fill="#d81b3c"/>',
    baklava: () => SH + '<path d="M100 38l36 32-36 32-36-32z" fill="#e0982a" stroke="#c4761c" stroke-width="3"/><path d="M80 70h40M100 50v40" stroke="#c4761c" stroke-width="3"/><circle cx="100" cy="70" r="7" fill="#9ccc65"/><path d="M150 104l16-14 16 14-16 14z" fill="#e0982a"/><path d="M26 108l14-12 14 12-14 12z" fill="#e0982a"/>',
    nuts: (c, n) => { const k = /cips/.test(n) ? '#f2c14e' : /fıstı/.test(n) ? '#9cba5a' : /fındık/.test(n) ? '#a8743b' : /çekirdek/.test(n) ? '#5d4037' : /leblebi/.test(n) ? '#e6c47a' : '#c8924a'; return SH + '<path d="M46 76h108q-4 46-54 46t-54-46z" fill="#fff"/><g fill="' + k + '"><circle cx="76" cy="70" r="8"/><circle cx="96" cy="62" r="9"/><circle cx="118" cy="68" r="8"/><circle cx="106" cy="76" r="8"/><circle cx="86" cy="76" r="7"/><circle cx="130" cy="74" r="7"/></g>'; }
  };
  const _il = {};
  function illus(name){
    const n = String(name || '').trim().toLocaleLowerCase('tr-TR'); if(n in _il) return _il[n];
    let k = ''; for(const [r, x] of KINDS) if(r.test(n)){ k = x; break; }
    const svg = k ? D[k](flv(n), n) : '';
    return _il[n] = svg ? 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 150">' + svg + '</svg>') : '';
  }
  function artHue(s){ let h = 0; for(const c of String(s || '')) h = (h * 31 + c.charCodeAt(0)) % 360; return h; }
  function imgOk(u){ return /^https:\/\//i.test(u || '') || /^data:image\/(jpeg|png|webp);base64,/.test(u || ''); }
  // görsel varsa fotoğraf, yoksa renkli zemin üstünde ürün/kategori emojisi (görsel bozuksa da emoji kalır)
  let holdImgs = false; // Firebase'den güncel veri gelene kadar eski (yerel) görseller çizilmesin
  function visHtml(o, fallbackIcon, cls){
    const ic = o.icon || fallbackIcon || '🍽️', ok = imgOk(o.img) && !holdImgs, fb = illus(o.name), src = ok ? o.img : fb;
    return '<div class="vis ' + cls + '" style="--h:' + artHue(o.name || ic) + '">' + (src && !ok ? '' : '<span class="vi">' + _e(ic) + '</span>') + (src ? '<img src="' + _e(src) + '" alt="" decoding="async" loading="lazy" referrerpolicy="no-referrer" style="opacity:0;transition:opacity .25s" onload="this.style.opacity=1"' + (ok ? ' data-fb="' + _e(fb) + '" onerror="this.onerror=null;if(this.dataset.fb)this.src=this.dataset.fb;else this.remove()"' : '') + '>' : '') + '</div>';
  }
  const catVis = g => visHtml({ img: g.img, icon: g.icon, name: g.name }, '', 'v-cat');
  function fileToThumb(file, max, cb){
    const r = new FileReader();
    r.onload = () => { const im = new Image(); im.onload = () => { const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); cb(c.toDataURL('image/jpeg', 0.72)); }; im.onerror = () => cb(''); im.src = r.result; };
    r.onerror = () => cb(''); r.readAsDataURL(file);
  }
  const MENU_VER = 2; // yalnızca bilgi amaçlı; sürüm değişse bile mevcut menü ASLA silinmez
  function buildSeedMenu(){ return migrateMenuGroups(SEED_MENU.map(c => ({ name: c[0], icon: c[1], products: c[3].map(p => ({ name: p[0], icon: p[1], portion: 'Tam', price: p[2], kg: c[2] })) }))); }
  function ensureSeedGroups(){ SEED_GROUPS.forEach(n => { if(!mutfakGruplari.some(g => g.name === n)) mutfakGruplari.push({ name: n, durum: 'Hazırlanıyor ve Hazırlandı' }); }); }
  let categories = buildSeedMenu();
  let activeCatIndex = 0;
  let activeGrp = null;            // ana kategori (alt kategorileriyle birlikte) seçiliyse adı
  let prodSearch = '';
  let showAllProds = false;
  let groupMeta = [];              // ana kategori görsel / ikon / sıra bilgisi: [{ name, icon, img, ord }]
  let priceMode = false;           // Toplu Fiyat Düzenleme görünümü
  const priceDraft = new Map();    // ürün adı -> kaydedilmemiş yeni fiyat
  const priceOff = new Set();      // toplu araçlardan hariç tutulan ürün adları
  const openGrps = new Set();      // açık ana kategoriler (kenar çubuğu)
  let openInit = false, lastGroups = [], curRows = [], curSecs = [], headCtx = {}, popAnchor = null;
  const allMode = () => showAllProds && !!(curUser && curUser.admin);
  const mnEl = id => document.getElementById(id);
  const isAdm = () => !!(curUser && curUser.admin);
  const fmtP = n => '₺' + (+n || 0).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fmtIn = n => (+n || 0).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  function parseNum(s){ s = String(s == null ? '' : s).replace(/[₺\s]/g, ''); if(!s) return NaN; if(s.indexOf(',') >= 0) s = s.replace(/\./g, '').replace(',', '.'); return parseFloat(s); }
  function normGM(x){ return Array.isArray(x) ? x.filter(Boolean) : (x && typeof x === 'object' ? Object.values(x).filter(Boolean) : []); }
  function gmSet(name, patch){ let m = groupMeta.find(x => x.name === name); if(!m){ m = { name }; groupMeta.push(m); } Object.assign(m, patch); return m; }
  const grpName = c => c.grp || c.name;
  const grpIdx = g => categories.map((c, i) => i).filter(i => grpName(categories[i]) === g);
  function catLabel(c){ return c.sub ? grpName(c) + ' › ' + c.sub : ((c.grp && c.grp !== c.name) ? c.grp + ' › ' + c.name : c.name); }
  const menuRender = () => { renderCatList(); renderProductGrid(); };

  function fixActive(){
    if(activeCatIndex >= categories.length) activeCatIndex = categories.length - 1;
    if(activeCatIndex < 0) activeCatIndex = 0;
    if(activeGrp && !categories.some(c => grpName(c) === activeGrp)) activeGrp = null;
  }
  function curView(){
    fixActive();
    if(allMode()) return { kind: 'all' };
    if(activeGrp) return { kind: 'grp', grp: activeGrp };
    return { kind: 'cat', idx: [activeCatIndex] };
  }
  function viewIdxs(){
    const v = curView(), gs = menuGroups(categories);
    if(v.kind === 'all') return gs.flatMap(g => g.subs.map(s => s.idx));
    if(v.kind === 'grp'){ const g = gs.find(x => x.name === v.grp); return g ? g.subs.map(s => s.idx) : []; }
    return v.idx;
  }
  function selectAll(){ showAllProds = true; menuRender(); }
  function selectGrp(name){ showAllProds = false; activeGrp = name; const ix = grpIdx(name); if(ix.length) activeCatIndex = ix[0]; openGrps.add(name); menuRender(); }
  function selectCat(i){ showAllProds = false; activeGrp = null; activeCatIndex = i; if(categories[i]) openGrps.add(grpName(categories[i])); menuRender(); }

  // ---------- kenar çubuğu: ana kategori › alt kategori ağacı ----------
  function renderCatList(){
    const list = mnEl('catList'); if(!list) return;
    migrateMenuGroups(categories);
    const adm = isAdm(); if(!adm) showAllProds = false;
    const gs = lastGroups = menuGroups(categories), v = curView();
    if(!openInit){ openInit = true; const c0 = categories[activeCatIndex]; if(c0) openGrps.add(grpName(c0)); }
    let h = '';
    if(adm){
      const tot = categories.reduce((n, c) => n + c.products.length, 0);
      h += '<div class="tg-row tg-main tg-all' + (v.kind === 'all' ? ' active' : '') + '" data-act="all"><span class="tg-spacer"></span>' + visHtml({ img: '', icon: '📋', name: 'Tüm Ürünler' }, '', 'v-tg') + '<span class="tg-name"><b>Tüm Ürünler</b><small>Bütün kategoriler tek listede</small></span><span class="cnt">' + tot + '</span></div>';
    }
    h += '<div class="sb-label">Ana kategoriler</div>';
    gs.forEach((g, gi) => {
      const nProd = g.subs.reduce((n, s) => n + s.cat.products.length, 0), gv = { img: g.img, icon: g.icon, name: g.name };
      const leaf = g.subs.length === 1 && !g.subs[0].cat.sub;
      if(leaf){
        const s0 = g.subs[0], on = v.kind === 'cat' && v.idx[0] === s0.idx;
        h += '<div class="tg-row tg-main' + (on ? ' active' : '') + '" data-act="cat" data-i="' + s0.idx + '" data-gi="' + gi + '"><span class="tg-spacer"></span>' + visHtml(gv, '', 'v-tg') + '<span class="tg-name"><b>' + esc(g.name) + '</b><small>Ana kategori · alt kategori yok</small></span><span class="cnt">' + nProd + '</span><span class="tg-k" data-act="kebab" data-t="grp" data-gi="' + gi + '" title="İşlemler">⋮</span></div>';
        return;
      }
      const open = openGrps.has(g.name), on = v.kind === 'grp' && v.grp === g.name;
      h += '<div class="tg-row tg-main' + (on ? ' active' : '') + '" data-act="grp" data-gi="' + gi + '"><span class="tg-chev' + (open ? ' open' : '') + '" data-act="tog" data-gi="' + gi + '" title="Aç / kapat">▸</span>' + visHtml(gv, '', 'v-tg') + '<span class="tg-name"><b>' + esc(g.name) + '</b><small>' + g.subs.length + ' alt kategori</small></span><span class="cnt">' + nProd + '</span><span class="tg-k" data-act="kebab" data-t="grp" data-gi="' + gi + '" title="İşlemler">⋮</span></div>';
      if(open){
        h += '<div class="tg-subs">';
        g.subs.forEach(s => {
          const son = v.kind === 'cat' && v.idx[0] === s.idx;
          h += '<div class="tg-row tg-sub' + (son ? ' active' : '') + '" data-act="cat" data-i="' + s.idx + '" data-gi="' + gi + '">' + visHtml({ img: s.cat.img, icon: s.cat.icon || g.icon, name: s.label }, g.icon, 'v-s') + '<span class="tg-name"><b>' + esc(s.label) + '</b></span><span class="cnt">' + s.cat.products.length + '</span><span class="tg-k" data-act="kebab" data-t="cat" data-i="' + s.idx + '" title="İşlemler">⋮</span></div>';
        });
        h += '</div>';
      }
    });
    list.innerHTML = h;
  }

  // ---------- açılır işlem menüsü ----------
  function closePop(){ const p = mnEl('catPop'); if(p) p.style.display = 'none'; popAnchor = null; }
  function openPop(anchor, items){
    let p = mnEl('catPop'); if(!p){ p = document.createElement('div'); p.id = 'catPop'; document.body.appendChild(p); }
    if(popAnchor === anchor && p.style.display === 'block'){ closePop(); return; }
    popAnchor = anchor;
    p.innerHTML = items.map((it, i) => it.sep ? '<div class="cp-sep"></div>' : '<div class="cp-it' + (it.danger ? ' danger' : '') + '" data-i="' + i + '"><span>' + it.ic + '</span>' + esc(it.t) + '</div>').join('');
    p.style.display = 'block';
    const r = anchor.getBoundingClientRect(), w = p.offsetWidth, hh = p.offsetHeight;
    let left = r.right + 6; if(left + w > innerWidth - 8) left = Math.max(8, r.right - w);
    p.style.left = left + 'px'; p.style.top = Math.max(8, Math.min(r.top, innerHeight - hh - 8)) + 'px';
    p.onclick = e => { const it = e.target.closest('.cp-it'); if(!it) return; closePop(); items[+it.dataset.i].fn(); };
  }
  document.addEventListener('click', e => { if(!e.target.closest('#catPop') && !e.target.closest('[data-act="kebab"]')) closePop(); });
  window.addEventListener('resize', closePop);
  document.addEventListener('keydown', e => { if(e.key === 'Escape') closePop(); });

  function groupMenu(g){
    const leaf = g.subs.length === 1 && !g.subs[0].cat.sub;
    return [
      { ic: '＋', t: 'Yeni Ürün Ekle', fn: () => openProductForm(null, g.subs[0].idx) },
      { ic: '↳', t: 'Alt Kategori Ekle', fn: () => addSub(g.name) },
      { ic: '✎', t: leaf ? 'Kategoriyi Düzenle (ad, görsel)' : 'Ana Kategoriyi Düzenle (ad, görsel)', fn: () => editGroup(g.name) },
      { ic: '⇩', t: 'Alt Kategoriye Çevir', fn: () => mainToSub(g.name) },
      { ic: '💲', t: 'Fiyatları Toplu Düzenle', fn: () => { if(leaf) selectCat(g.subs[0].idx); else selectGrp(g.name); setPriceMode(true); } },
      { sep: 1 },
      { ic: '↑', t: 'Yukarı Taşı', fn: () => moveGroup(g.name, -1) },
      { ic: '↓', t: 'Aşağı Taşı', fn: () => moveGroup(g.name, 1) },
      { sep: 1 },
      { ic: '🗑', t: leaf ? 'Kategoriyi Sil' : 'Ana Kategoriyi Sil', danger: 1, fn: () => delGroup(g.name) }
    ];
  }
  function catMenu(i){
    return [
      { ic: '＋', t: 'Yeni Ürün Ekle', fn: () => openProductForm(null, i) },
      { ic: '✎', t: 'Alt Kategoriyi Düzenle (ad, görsel)', fn: () => editCat(i) },
      ...(categories[i] && categories[i].sub ? [{ ic: '⇧', t: 'Ana Kategoriye Çevir', fn: () => subToMain(i) }] : []),
      { ic: '💲', t: 'Fiyatları Toplu Düzenle', fn: () => { selectCat(i); setPriceMode(true); } },
      { sep: 1 },
      { ic: '🗑', t: 'Alt Kategoriyi Sil', danger: 1, fn: () => delCat(i) }
    ];
  }
  mnEl('catList').addEventListener('click', e => {
    const t = e.target.closest('[data-act]'); if(!t) return;
    const act = t.dataset.act, g = lastGroups[+t.dataset.gi];
    if(act === 'tog'){ e.stopPropagation(); if(g){ openGrps.has(g.name) ? openGrps.delete(g.name) : openGrps.add(g.name); renderCatList(); } return; }
    if(act === 'kebab'){ e.stopPropagation(); if(t.dataset.t === 'grp' && g) openPop(t, groupMenu(g)); else if(t.dataset.t === 'cat') openPop(t, catMenu(+t.dataset.i)); return; }
    closePop();
    if(act === 'all') selectAll(); else if(act === 'grp' && g) selectGrp(g.name); else if(act === 'cat') selectCat(+t.dataset.i);
  });

  // ---------- kategori işlemleri ----------

  // ---------- ana ↔ alt kategori çevirme ----------
  // Alt kategoriyi ana kategoriye çevirir (ürünleri korunur; ana kategori listesinde eski ana kategorisinin hemen altına girer)
  function subToMain(i){
    const c = categories[i]; if(!c || !c.sub) return;
    const from = grpName(c), nm = c.sub, low = x => String(x).toLocaleLowerCase('tr-TR');
    if(menuGroups(categories).some(g => low(g.name) === low(nm))){ showToast('“' + nm + '” adında bir ana kategori zaten var. Önce alt kategorinin adını değiştirin.'); return; }
    c.name = nm; c.grp = nm; c.sub = ''; c.gv = 3;
    const gs = menuGroups(categories), ni = gs.findIndex(g => g.name === nm);
    if(ni >= 0){ const x = gs.splice(ni, 1)[0], at = gs.findIndex(g => g.name === from); gs.splice(at >= 0 ? at + 1 : gs.length, 0, x); }
    gs.forEach((g, k) => gmSet(g.name, { ord: k }));
    if(!categories.some(x => x !== c && grpName(x) === from)){ groupMeta = groupMeta.filter(m => m.name !== from); openGrps.delete(from); }
    showAllProds = false; activeGrp = null; activeCatIndex = i; openGrps.add(nm);
    menuRender(); saveState(); showToast('“' + nm + '” artık ana kategori.');
  }
  // Ana kategoriyi (alt kategorileriyle birlikte) başka bir ana kategorinin altına alt kategori olarak taşır
  function mainToSub(gname){
    const all = menuGroups(categories), g = all.find(x => x.name === gname); if(!g) return;
    const others = all.filter(x => x.name !== gname);
    if(!others.length){ showToast('Alt kategoriye çevirmek için başka bir ana kategori olmalı.'); return; }
    const low = x => String(x).toLocaleLowerCase('tr-TR'), nProd = g.subs.reduce((n, s) => n + s.cat.products.length, 0);
    openForm({
      title: 'Alt Kategoriye Çevir',
      sub: '“' + gname + '” (' + nProd + ' ürün) seçeceğiniz ana kategorinin içine alt kategori olarak taşınır. Ürünler silinmez.' + (g.subs.length > 1 ? ' İçindeki ' + g.subs.length + ' alt kategori de aynı ana kategorinin altına geçer.' : ''),
      fields: [{ id: 'to', label: 'Hangi ana kategorinin altına eklensin?', type: 'select', options: others.map(x => ({ v: x.name, t: x.name })), value: others[0].name }],
      okText: 'Çevir',
      onOk(v){
        const to = v.to; if(!others.some(x => x.name === to)) return 'Geçerli bir ana kategori seçin.';
        const used = new Set(categories.filter(c => grpName(c) === to).map(c => low(c.sub || c.name)));
        g.subs.map(s => s.cat).forEach(c => {
          let label = c.sub || gname; if(used.has(low(label))) label = label + ' (' + gname + ')';
          used.add(low(label));
          if(!c.sub){ if(!c.img && g.img) c.img = g.img; if(!c.icon && g.icon) c.icon = g.icon; }
          c.grp = to; c.sub = label; c.gv = 3;
        });
        groupMeta = groupMeta.filter(m => m.name !== gname); openGrps.delete(gname); openGrps.add(to);
        showAllProds = false; activeGrp = null; activeCatIndex = categories.indexOf(g.subs[0].cat);
        menuRender(); saveState(); showToast('“' + gname + '” artık “' + to + '” altında alt kategori.');
      }
    });
  }
  function renameGroup(old, nw){
    menuGroups(categories).forEach((g, i) => gmSet(g.name, { ord: i }));   // mevcut sırayı sabitle
    categories.forEach(c => { if(grpName(c) === old) c.grp = nw; });
    const m = groupMeta.find(x => x.name === old); if(m) m.name = nw;
  }
  function moveGroup(name, d){
    const gs = menuGroups(categories), i = gs.findIndex(g => g.name === name), j = i + d;
    if(i < 0 || j < 0 || j >= gs.length) return;
    const t = gs[i]; gs[i] = gs[j]; gs[j] = t;
    gs.forEach((g, k) => gmSet(g.name, { ord: k }));
    menuRender(); saveState();
  }
  function addGroup(){
    openForm({
      title: 'Ana Kategori Ekle', sub: 'Menünün üstünde görsel + isimle görünen ana sekmedir. Alt kategorileri sonra ekleyebilirsiniz.',
      fields: [
        { id: 'name', label: 'Ana kategori adı', value: '' },
        { id: 'imgf', label: 'Ana kategori görseli (yükle)', type: 'file', value: '', icon: '', name: '' },
        { id: 'icon', label: 'İkon (emoji) — görsel yoksa bu görünür', value: '' }
      ],
      onOk(v){
        if(!v.name) return 'Ana kategori adı gerekli.';
        if(menuGroups(categories).some(g => g.name.toLocaleLowerCase('tr-TR') === v.name.toLocaleLowerCase('tr-TR'))) return 'Bu adda bir ana kategori zaten var.';
        categories.push({ name: v.name, grp: v.name, sub: '', gv: 2, icon: v.icon, img: v.imgf || '', products: [] });
        gmSet(v.name, { icon: v.icon, img: v.imgf || '' }); try{ imgQueue('grp', v.name); }catch(e){}
        showAllProds = false; activeGrp = null; activeCatIndex = categories.length - 1; openGrps.add(v.name);
        menuRender(); saveState(); showToast('Ana kategori eklendi: ' + v.name);
      }
    });
  }
  function addSub(gname){
    openForm({
      title: 'Alt Kategori Ekle', sub: '“' + gname + '” ana kategorisinin içine eklenir.',
      fields: [
        { id: 'name', label: 'Alt kategori adı', value: '' },
        { id: 'imgf', label: 'Görsel (isteğe bağlı)', type: 'file', value: '', icon: '', name: '' },
        { id: 'icon', label: 'İkon (emoji, isteğe bağlı)', value: '' }
      ],
      onOk(v){
        if(!v.name) return 'Alt kategori adı gerekli.';
        if(categories.some(c => grpName(c) === gname && (c.sub || c.name).toLocaleLowerCase('tr-TR') === v.name.toLocaleLowerCase('tr-TR'))) return 'Bu ana kategoride aynı adlı bir alt kategori var.';
        migrateMenuGroups(categories);
        const gix = grpIdx(gname), c0 = categories[gix[0]];
        if(gix.length === 1 && c0 && !c0.sub && !c0.products.length){   // boş, alt kategorisiz ana kategori: ilk alt kategoriye dönüşür (gereksiz tekrar satır oluşmasın)
          gmSet(gname, { icon: groupMeta.some(m => m.name === gname && m.icon) ? undefined : c0.icon, img: groupMeta.some(m => m.name === gname && m.img) ? undefined : c0.img });
          Object.keys(groupMeta.find(m => m.name === gname) || {}).forEach(k => { const m = groupMeta.find(x => x.name === gname); if(m[k] === undefined) delete m[k]; });
          Object.assign(c0, { name: gname + ' / ' + v.name, sub: v.name, gv: 2, icon: v.icon, img: v.imgf || '' }); activeCatIndex = gix[0];
        } else { categories.push({ name: gname + ' / ' + v.name, grp: gname, sub: v.name, gv: 2, icon: v.icon, img: v.imgf || '', products: [] }); activeCatIndex = categories.length - 1; }
        showAllProds = false; activeGrp = null; openGrps.add(gname); try{ imgQueue('cat', categories[activeCatIndex]); }catch(e){}
        menuRender(); saveState(); showToast('Alt kategori eklendi: ' + v.name);
      }
    });
  }
  function deptField(n, what){ return { id: 'dept', label: 'Toplu departman (' + what + ' ' + n + ' ürünün hepsi için)', type: 'select', options: [{ v: '', t: '— Değiştirme —' }].concat(mutfakGruplari.map(x => ({ v: x.name, t: x.name }))), value: '' }; }
  function editGroup(gname){
    const g = menuGroups(categories).find(x => x.name === gname); if(!g) return;
    const cats = g.subs.map(s => s.cat), plain = cats.filter(c => !c.sub), nProd = cats.reduce((n, c) => n + c.products.length, 0);
    const leaf = g.subs.length === 1 && !g.subs[0].cat.sub;
    openForm({
      title: leaf ? 'Kategoriyi Düzenle' : 'Ana Kategoriyi Düzenle',
      sub: 'Ana kategori, müşteri menüsünde ve sipariş ekranında üstteki görselli sekmedir.',
      fields: [
        { id: 'name', label: 'Ana kategori adı', value: g.name },
        { id: 'imgf', label: 'Ana kategori görseli (yükle)', type: 'file', value: /^data:/.test(g.img || '') ? g.img : '', icon: g.icon, name: g.name },
        { id: 'img', label: 'veya görsel bağlantısı (link yapıştır)', placeholder: 'https://...', value: /^https:/.test(g.img || '') ? g.img : '' },
        { id: 'icon', label: 'İkon (emoji) — görsel yoksa bu görünür', value: g.icon || '' },
        deptField(nProd, 'bu ana kategorideki')
      ],
      onOk(v){
        if(!v.name) return 'Ana kategori adı gerekli.';
        if(v.name !== g.name && menuGroups(categories).some(x => x.name.toLocaleLowerCase('tr-TR') === v.name.toLocaleLowerCase('tr-TR'))) return 'Bu adda bir ana kategori zaten var.';
        const lnk = normImgUrl(v.img); if(lnk === null) return 'Görsel adresi geçerli bir bağlantı olmalı (https://...).';
        const nm = v.name, img = v.imgf || lnk;
        if(nm !== g.name){
          plain.forEach(c => { if(c.name === g.name) c.name = nm; });
          renameGroup(g.name, nm); openGrps.delete(g.name); openGrps.add(nm);
          if(activeGrp === g.name) activeGrp = nm;
        }
        gmSet(nm, { icon: v.icon, img });
        plain.forEach(c => { c.icon = v.icon; c.img = img; }); try{ imgQueue('grp', nm); }catch(e){}
        let moved = 0; if(v.dept) cats.forEach(c => c.products.forEach(pr => { pr.kg = v.dept; moved++; }));
        menuRender(); saveState();
        showToast(moved ? moved + ' ürün “' + v.dept + '” departmanına bağlandı.' : 'Ana kategori güncellendi.');
      }
    });
  }
  function editCat(i){
    const c = categories[i]; if(!c) return;
    openForm({
      title: 'Alt Kategoriyi Düzenle', sub: catLabel(c),
      fields: [
        { id: 'name', label: 'Alt kategori adı', value: c.sub || c.name },
        { id: 'imgf', label: 'Alt kategori görseli (yükle)', type: 'file', value: /^data:/.test(c.img || '') ? c.img : '', icon: c.icon, name: c.sub || c.name },
        { id: 'img', label: 'veya görsel bağlantısı (link yapıştır)', placeholder: 'https://...', value: /^https:/.test(c.img || '') ? c.img : '' },
        { id: 'icon', label: 'İkon (emoji) — görsel yoksa bu görünür', value: c.icon || '' },
        deptField(c.products.length, 'kategorideki')
      ],
      onOk(v){
        if(!v.name) return 'Alt kategori adı gerekli.';
        const lnk = normImgUrl(v.img); if(lnk === null) return 'Görsel adresi geçerli bir bağlantı olmalı (https://...).';
        if(c.sub) c.sub = v.name; else c.name = v.name;
        c.icon = v.icon; c.img = v.imgf || lnk; try{ imgQueue('cat', c); }catch(e){}
        let moved = 0; if(v.dept) c.products.forEach(pr => { pr.kg = v.dept; moved++; });
        menuRender(); saveState();
        showToast(moved ? moved + ' ürün “' + v.dept + '” departmanına bağlandı.' : 'Alt kategori güncellendi.');
      }
    });
  }
  async function delCat(i){
    const c = categories[i]; if(!c) return;
    if(categories.length <= 1){ showToast('En az bir kategori kalmalı.'); return; }
    const n = c.products.length;
    if(!await uiConfirm('“' + catLabel(c) + '” alt kategorisi' + (n ? ' ve içindeki ' + n + ' ürün' : '') + ' silinsin mi? Bu işlem geri alınamaz.')) return;
    c.products.forEach(p => priceDraft.delete(p.name));
    categories.splice(i, 1); if(i < activeCatIndex) activeCatIndex--;
    menuRender(); saveState(); showToast('Alt kategori silindi.');
  }
  async function delGroup(name){
    const ix = grpIdx(name), n = ix.reduce((s, i) => s + categories[i].products.length, 0);
    if(categories.length - ix.length < 1){ showToast('En az bir kategori kalmalı.'); return; }
    if(!await uiConfirm('“' + name + '” ana kategorisi' + (ix.length > 1 ? ', ' + ix.length + ' alt kategorisi' : '') + (n ? ' ve toplam ' + n + ' ürünle birlikte' : '') + ' silinsin mi? Bu işlem geri alınamaz.')) return;
    ix.forEach(i => categories[i].products.forEach(p => priceDraft.delete(p.name)));
    categories = categories.filter(c => grpName(c) !== name);
    groupMeta = groupMeta.filter(m => m.name !== name);
    openGrps.delete(name); activeGrp = null; activeCatIndex = 0;
    menuRender(); saveState(); showToast('Ana kategori silindi.');
  }

  // ---------- üst başlık (seçili ana / alt kategori) ----------
  function renderHead(){
    const el = mnEl('menuHead'); if(!el) return;
    const v = curView(), gs = menuGroups(categories), idxs = viewIdxs();
    let lvl, lvlTxt, title, crumb = '', obj, edit = null, canSub = null, subN = 0, conv = null;
    if(v.kind === 'all'){ lvl = 'all'; lvlTxt = 'Genel görünüm'; title = 'Tüm Ürünler'; obj = { name: title, icon: '📋', img: '' }; }
    else if(v.kind === 'grp'){ const g = gs.find(x => x.name === v.grp) || { name: v.grp, icon: '', img: '', subs: [] }; lvl = 'main'; lvlTxt = 'Ana kategori'; title = g.name; subN = g.subs.length; obj = { name: g.name, icon: g.icon, img: g.img }; edit = () => editGroup(g.name); canSub = g.name; if(gs.length > 1) conv = { t: '⇩ Alt Kategoriye Çevir', fn: () => mainToSub(g.name) }; }
    else {
      const c = categories[v.idx[0]], gn = grpName(c), g = gs.find(x => x.name === gn) || { name: gn, icon: '', img: '' }, leaf = !c.sub && grpIdx(gn).length === 1;
      if(leaf){ lvl = 'main'; lvlTxt = 'Ana kategori'; title = g.name; obj = { name: g.name, icon: g.icon, img: g.img }; edit = () => editGroup(g.name); canSub = g.name; if(gs.length > 1) conv = { t: '⇩ Alt Kategoriye Çevir', fn: () => mainToSub(g.name) }; }
      else { lvl = 'sub'; lvlTxt = 'Alt kategori'; crumb = gn; title = c.sub || c.name; obj = { name: title, icon: c.icon || g.icon, img: c.img }; const ci = v.idx[0]; edit = () => editCat(ci); conv = { t: '⇧ Ana Kategoriye Çevir', fn: () => subToMain(ci) }; }
    }
    const prices = idxs.flatMap(i => categories[i].products.map(p => p.price)), n = prices.length, st = [];
    if(subN) st.push('<span><b>' + subN + '</b> alt kategori</span>');
    if(n){ st.push('<span><b>' + n + '</b> ürün</span>', '<span>Ort. <b>' + fmtP(prices.reduce((a, b) => a + b, 0) / n) + '</b></span>', '<span><b>' + fmtP(Math.min.apply(null, prices)) + '</b> – <b>' + fmtP(Math.max.apply(null, prices)) + '</b></span>'); }
    else st.push('<span>Henüz ürün yok</span>');
    headCtx = { edit, canSub, conv, ci: v.kind === 'cat' ? v.idx[0] : (idxs[0] != null ? idxs[0] : activeCatIndex) };
    el.innerHTML =
      '<div class="mh-thumb" data-act="editself"' + (edit ? ' title="Görseli / adı değiştir"' : '') + '>' + visHtml(obj, '', 'v-mh') + (edit ? '<span class="mh-edit">✎</span>' : '') + '</div>' +
      '<div class="mh-txt"><div class="mh-top"><span class="lvl lvl-' + lvl + '">' + lvlTxt + '</span>' + (crumb ? '<span class="mh-crumb">' + esc(crumb) + ' ›</span>' : '') + '</div><h2>' + esc(title) + '</h2><div class="mh-stats">' + st.join('') + '</div></div>' +
      '<div class="mh-actions"><button type="button" class="mbtn pri" data-act="newprod">＋ Yeni Ürün</button>' +
      (canSub ? '<button type="button" class="mbtn" data-act="newsub">↳ Alt Kategori Ekle</button>' : '') +
      (edit ? '<button type="button" class="mbtn" data-act="editself">✎ ' + (lvl === 'main' ? 'Ana Kategoriyi Düzenle' : 'Alt Kategoriyi Düzenle') + '</button>' : '') +
      (conv ? '<button type="button" class="mbtn" data-act="conv">' + conv.t + '</button>' : '') + '</div>';
  }
  mnEl('menuHead').addEventListener('click', e => {
    const t = e.target.closest('[data-act]'); if(!t) return;
    if(t.dataset.act === 'newprod') openProductForm(null, headCtx.ci);
    else if(t.dataset.act === 'newsub' && headCtx.canSub) addSub(headCtx.canSub);
    else if(t.dataset.act === 'editself' && headCtx.edit) headCtx.edit();
    else if(t.dataset.act === 'conv' && headCtx.conv) headCtx.conv.fn();
  });

  // ---------- ürün listesi + toplu fiyat düzenleme ----------
  const draftOf = p => priceDraft.has(p.name) ? priceDraft.get(p.name) : null;
  function setDraft(p, val){
    if(val == null || !isFinite(val) || val < 0){ priceDraft.delete(p.name); return; }
    val = Math.round(val * 100) / 100;
    if(Math.abs(val - p.price) < 0.005) priceDraft.delete(p.name); else priceDraft.set(p.name, val);
  }
  function dirtyCount(){ let n = 0; categories.forEach(c => c.products.forEach(p => { const d = priceDraft.get(p.name); if(d != null && Math.abs(d - p.price) > 0.004) n++; })); return n; }
  function deltaHtml(p, cur){
    const diff = Math.round((cur - p.price) * 100) / 100; if(Math.abs(diff) < 0.005) return '';
    const pct = p.price ? Math.abs(diff / p.price * 100) : 0;
    return '<span class="' + (diff > 0 ? 'up' : 'down') + '">' + (diff > 0 ? '▲ +' : '▼ −') + fmtP(Math.abs(diff)) + ' <small>%' + pct.toFixed(1).replace(/\.0$/, '').replace('.', ',') + '</small></span>';
  }
  function listRow(p, k, c){
    return '<div class="prow2" data-k="' + k + '">' + visHtml(p, c.icon, 'v-row') + '<div class="pn"><b>' + esc(p.name) + '</b><span>' + esc(p.portion || '') + (p.kg ? ' · ' + esc(p.kg) : '') + '</span></div><div class="pp">' + fmtP(p.price) + '</div><div class="pa"><button class="pc-ed" title="Düzenle">✎</button><button class="pc-del" title="Sil">🗑</button></div></div>';
  }
  function priceRow(p, k, c){
    const d = draftOf(p), cur = d != null ? d : p.price;
    return '<div class="prow2 pm-row' + (d != null ? ' chg' : '') + '" data-k="' + k + '"><input type="checkbox" class="pm-chk" data-k="' + k + '"' + (priceOff.has(p.name) ? '' : ' checked') + ' title="Toplu araçlara dahil et">' + visHtml(p, c.icon, 'v-sm2') +
      '<div class="pn"><b>' + esc(p.name) + '</b><span>' + esc(p.portion || '') + '</span></div><div class="pm-old" title="Mevcut fiyat">' + fmtP(p.price) + '</div><span class="pm-arrow">→</span>' +
      '<label class="pm-in"><span>₺</span><input class="pin" data-k="' + k + '" inputmode="decimal" value="' + fmtIn(cur) + '" autocomplete="off" aria-label="' + esc(p.name) + ' yeni fiyat"></label><div class="pm-delta">' + deltaHtml(p, cur) + '</div></div>';
  }
  function syncSecChecks(){
    const grid = mnEl('productGrid');
    curSecs.forEach((s, i) => { const cb = grid.querySelector('.pm-secchk[data-s="' + i + '"]'); if(!cb) return; const on = s.rows.filter(k => !priceOff.has(curRows[k].p.name)).length; cb.checked = on > 0 && on === s.rows.length; cb.indeterminate = on > 0 && on < s.rows.length; });
  }
  function updateScope(){
    const tot = curRows.length, sel = curRows.filter(r => !priceOff.has(r.p.name)).length, a = mnEl('ptAll');
    mnEl('ptScope').textContent = sel + ' / ' + tot + ' ürün seçili';
    a.checked = tot > 0 && sel === tot; a.indeterminate = sel > 0 && sel < tot;
  }
  function updateBar(){
    const n = dirtyCount(); let inView = 0;
    curRows.forEach(r => { const d = draftOf(r.p); if(d != null && Math.abs(d - r.p.price) > 0.004) inView++; });
    mnEl('pbInfo').innerHTML = n ? '<b>' + n + '</b> üründe fiyat değişikliği bekliyor' + (n > inView ? ' <span>(' + (n - inView) + ' tanesi diğer kategorilerde)</span>' : '') + ' <span>· henüz kaydedilmedi</span>' : 'Henüz değişiklik yok — fiyatları kutulara yazın veya yukarıdaki araçları kullanın.';
    mnEl('pbSave').disabled = !n; mnEl('pbReset').disabled = !n;
    mnEl('pbSave').textContent = n ? '✔ Fiyatları Güncelle (' + n + ')' : '✔ Fiyatları Güncelle';
  }
  function renderProductGrid(){
    const grid = mnEl('productGrid'); if(!grid) return;
    const ae = document.activeElement;
    if(priceMode && ae && ae.classList && ae.classList.contains('pin') && grid.contains(ae)) return;   // fiyat yazarken (canlı eşitleme) odak kaybolmasın
    if(!categories.length){ grid.innerHTML = ''; return; }
    renderHead();
    mnEl('segList').classList.toggle('on', !priceMode); mnEl('segPrice').classList.toggle('on', priceMode);
    mnEl('priceTools').classList.toggle('show', priceMode); mnEl('priceBar').classList.toggle('show', priceMode);
    const v = curView(), q = prodSearch.toLocaleLowerCase('tr-TR'), idxs = viewIdxs(), multi = idxs.length > 1;
    curRows = []; curSecs = [];
    let h = '';
    idxs.forEach(ci => {
      const c = categories[ci], items = c.products.filter(p => !q || p.name.toLocaleLowerCase('tr-TR').includes(q));
      if(!items.length && (q || priceMode)) return;
      const sec = { ci, rows: [] }, title = v.kind === 'all' ? catLabel(c) : (c.sub || c.name);
      if(multi) h += '<div class="sec-h">' + (priceMode ? '<input type="checkbox" class="pm-secchk" data-s="' + curSecs.length + '" title="Bu bölümdeki ürünleri seç / bırak">' : '') + '<span>' + esc(title) + '</span><span class="n">' + c.products.length + ' ürün</span></div>';
      if(!items.length) h += '<div class="prod-empty sm">Bu kategoride henüz ürün yok. <a href="#" data-addto="' + ci + '">＋ Ürün ekle</a></div>';
      items.forEach(p => { const k = curRows.length; curRows.push({ p, ci }); sec.rows.push(k); h += priceMode ? priceRow(p, k, c) : listRow(p, k, c); });
      curSecs.push(sec);
    });
    if(!h) h = '<div class="prod-empty">' + (q ? 'Aramaya uygun ürün yok.' : (priceMode ? 'Fiyatı düzenlenecek ürün yok.' : 'Bu kategoride henüz ürün yok. “＋ Yeni Ürün” ile ekleyin.')) + '</div>';
    grid.innerHTML = h;
    if(priceMode){ syncSecChecks(); updateScope(); updateBar(); }
  }
  async function setPriceMode(on){
    if(!on && priceMode && dirtyCount()){
      if(!await uiConfirm(dirtyCount() + ' üründe kaydedilmemiş fiyat değişikliği var. Silinsin mi?')) return;
      priceDraft.clear();
    }
    priceMode = !!on; renderProductGrid();
  }
  async function savePrices(){
    const n = dirtyCount(); if(!n) return;
    if(!await uiConfirm(n + ' ürünün fiyatı güncellenecek ve menüde yayınlanacak. Onaylıyor musunuz?')) return;
    let changed = 0;
    const noImg = [];
    categories.forEach(c => c.products.forEach(p => { const d = priceDraft.get(p.name); if(d != null && Math.abs(d - p.price) > 0.004){ p.price = d; changed++; if(!imgOk(p.img)) noImg.push([p, c]); } }));
    priceDraft.clear(); menuRender(); saveState();
    try{ noImg.forEach(x => imgQueue('prod', x[0], x[1])); }catch(e){}
    showToast('✔ ' + changed + ' ürünün fiyatı güncellendi.', 3000);
  }
  function applyOp(op){
    const tg = curRows.filter(r => !priceOff.has(r.p.name));
    if(!tg.length){ showToast('Önce listeden en az bir ürün seçin.'); return; }
    const rs = +mnEl('ptRound').value || 0, rnd = x => rs ? Math.round(x / rs) * rs : Math.round(x * 100) / 100;
    const dir = g => { const b = document.querySelector('#priceTools [data-dirgrp="' + g + '"] button.on'); return b ? +b.dataset.dir : 1; };
    let fn;
    if(op === 'set'){
      const v = parseNum(mnEl('ptSet').value); if(!(v >= 0)){ showToast('Geçerli bir fiyat yazın (örn. 500).'); mnEl('ptSet').focus(); return; }
      fn = () => v;
    } else if(op === 'pct'){
      const v = parseNum(mnEl('ptPct').value), s = dir('pct');
      if(!(v > 0) || v > 500 || (s < 0 && v >= 100)){ showToast(s < 0 ? 'İndirim oranı 0 ile 100 arasında olmalı.' : 'Geçerli bir yüzde yazın (örn. 10).'); mnEl('ptPct').focus(); return; }
      fn = x => rnd(x * (1 + s * v / 100));
    } else {
      const v = parseNum(mnEl('ptAmt').value), s = dir('amt');
      if(!(v > 0)){ showToast('Geçerli bir tutar yazın (örn. 25).'); mnEl('ptAmt').focus(); return; }
      fn = x => rnd(x + s * v);
    }
    tg.forEach(r => { const d = draftOf(r.p), cur = d != null ? d : r.p.price; let n = fn(cur); if(!(n >= 0)) n = 0; setDraft(r.p, n); });
    renderProductGrid();
    showToast(tg.length + ' ürünün yeni fiyatı hazırlandı — onaylamak için “Fiyatları Güncelle”ye basın.', 3800);
  }

  (function wireMenuUi(){
    const grid = mnEl('productGrid');
    grid.addEventListener('click', async e => {
      const add = e.target.closest('[data-addto]'); if(add){ e.preventDefault(); openProductForm(null, +add.dataset.addto); return; }
      const row = e.target.closest('.prow2'); if(!row) return; const r = curRows[+row.dataset.k]; if(!r) return;
      if(e.target.closest('.pc-ed')) openProductForm(r.p, r.ci);
      else if(e.target.closest('.pc-del')){
        if(await uiConfirm('“' + r.p.name + '” silinsin mi?')){ const a = categories[r.ci].products; a.splice(a.indexOf(r.p), 1); priceDraft.delete(r.p.name); menuRender(); saveState(); }
      }
    });
    grid.addEventListener('input', e => {
      const inp = e.target.closest('.pin'); if(!inp) return;
      const row = inp.closest('.pm-row'), r = curRows[+inp.dataset.k]; if(!row || !r) return;
      const raw = inp.value.trim();
      if(raw === '') setDraft(r.p, null); else { const v = parseNum(raw); if(isFinite(v)) setDraft(r.p, v); else return; }
      const d = draftOf(r.p), cur = d != null ? d : r.p.price;
      row.classList.toggle('chg', d != null); row.querySelector('.pm-delta').innerHTML = deltaHtml(r.p, cur); updateBar();
    });
    grid.addEventListener('change', e => {
      const t = e.target;
      if(t.classList.contains('pm-chk')){ const r = curRows[+t.dataset.k]; if(!r) return; t.checked ? priceOff.delete(r.p.name) : priceOff.add(r.p.name); syncSecChecks(); updateScope(); }
      else if(t.classList.contains('pm-secchk')){
        const s = curSecs[+t.dataset.s]; if(!s) return;
        s.rows.forEach(k => { const nm = curRows[k].p.name; t.checked ? priceOff.delete(nm) : priceOff.add(nm); const cb = grid.querySelector('.pm-chk[data-k="' + k + '"]'); if(cb) cb.checked = t.checked; });
        t.indeterminate = false; updateScope();
      } else if(t.classList.contains('pin')){ const r = curRows[+t.dataset.k]; if(r){ const d = draftOf(r.p); t.value = fmtIn(d != null ? d : r.p.price); } }
    });
    grid.addEventListener('focusin', e => { if(e.target.classList && e.target.classList.contains('pin')) setTimeout(() => { try{ e.target.select(); }catch(_){} }, 0); });
    grid.addEventListener('keydown', e => {
      if(e.key !== 'Enter' || !e.target.classList.contains('pin')) return;
      e.preventDefault(); const all = [...grid.querySelectorAll('.pin')], i = all.indexOf(e.target); (all[i + 1] || all[i]).focus();
    });
    mnEl('segList').addEventListener('click', () => setPriceMode(false));
    mnEl('segPrice').addEventListener('click', () => setPriceMode(true));
    mnEl('pbSave').addEventListener('click', savePrices);
    mnEl('pbReset').addEventListener('click', () => { priceDraft.clear(); renderProductGrid(); showToast('Değişiklikler sıfırlandı.'); });
    mnEl('ptAll').addEventListener('change', e => { curRows.forEach(r => { e.target.checked ? priceOff.delete(r.p.name) : priceOff.add(r.p.name); }); renderProductGrid(); });
    mnEl('priceTools').addEventListener('click', e => {
      const b = e.target.closest('[data-op]'); if(b){ applyOp(b.dataset.op); return; }
      const d = e.target.closest('.seg.mini button'); if(d){ d.parentNode.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === d)); }
    });
    mnEl('priceTools').addEventListener('keydown', e => { if(e.key === 'Enter' && e.target.tagName === 'INPUT'){ const c = e.target.closest('.pt-card'); const b = c && c.querySelector('[data-op]'); if(b){ e.preventDefault(); applyOp(b.dataset.op); } } });
  })();
  menuRender();

  mnEl('btnKategoriEkle').addEventListener('click', addGroup);
  // ---- toplu fotoğraf: dosya adı = ürün / alt kategori / ana kategori adı ----
  const normTr = t => String(t).toLocaleLowerCase('tr-TR').replace(/ç/g, 'c').replace(/ğ/g, 'g').replace(/ı/g, 'i').replace(/ö/g, 'o').replace(/ş/g, 's').replace(/ü/g, 'u').replace(/[^a-z0-9]+/g, ' ').trim();
  mnEl('btnTopluFoto').addEventListener('click', () => mnEl('topluFotoInp').click());
  mnEl('topluFotoInp').addEventListener('change', async e => {
    const files = [...e.target.files]; e.target.value = ''; if(!files.length) return;
    const targets = [];
    menuGroups(categories).forEach(g => targets.push({ grp: g.name, n: normTr(g.name) }));
    categories.forEach(c => { targets.push({ o: c, n: normTr(c.sub || c.name) }); c.products.forEach(pr => targets.push({ o: pr, n: normTr(pr.name) })); });
    let ok = 0; const miss = [];
    for(const f of files){
      const fn = normTr(f.name.replace(/\.[^.]+$/, '')); if(!fn) continue;
      let t = targets.find(x => x.n === fn);
      if(!t){ const cand = targets.filter(x => x.n.length >= 4 && (fn.includes(x.n) || x.n.includes(fn))); t = cand.sort((a, b) => b.n.length - a.n.length)[0]; }
      if(!t){ miss.push(f.name); continue; }
      const d = await new Promise(r => fileToThumb(f, 360, r)); if(!d){ miss.push(f.name); continue; }
      if(t.grp){ gmSet(t.grp, { img: d }); categories.forEach(c => { if(grpName(c) === t.grp && !c.sub) c.img = d; }); } else t.o.img = d;
      ok++;
    }
    menuRender(); saveState();
    showToast(ok + ' fotoğraf eşleşti' + (miss.length ? ', eşleşmeyen: ' + miss.slice(0, 4).join(', ') + (miss.length > 4 ? '…' : '') : '.'));
  });
  mnEl('prodSearchInput').addEventListener('input', e => { prodSearch = e.target.value; renderProductGrid(); });

  // ======================================================================
  // MUTFAK GRUPLARI
  // ======================================================================
  let mutfakGruplari = [
    { name: 'Mutfak', durum: "Hazırlanıyor ve Hazırlandı" },
    { name: 'Bar', durum: "Hazırlanıyor ve Hazırlandı" },
    { name: 'Nargile', durum: "Hazırlanıyor ve Hazırlandı" }
  ];

  // ======================================================================
  // MÜŞTERİLER
  // ======================================================================
  let customers = [];
  let custSort = { key: null, dir: 1 };
  let custSearch = '';

  document.getElementById('custSearchInput').addEventListener('input', (e) => {
    custSearch = e.target.value;
    renderCustomers();
  });
  document.querySelectorAll('.dt-sort').forEach(h => {
    h.addEventListener('click', () => {
      const key = h.getAttribute('data-sort');
      custSort.dir = (custSort.key === key) ? -custSort.dir : 1;
      custSort.key = key;
      renderCustomers();
    });
  });
    
  // ======================================================================
  // ANA SAYFA — charts
  // ======================================================================
  function paletteColor(i){
    const palette = ['#1F4B8F','#0F7B8A','#B7791F','#5B6B82','#3E6FB5','#2E8B6E','#8A5A9E','#9A4A3C','#4F7F9C','#7A8798','#6B7F3A'];
    return palette[i % palette.length];
  }

  function buildLineChart(xLabels, yMax, yStep, opts){
    opts = opts || {};
    const w = 760, h = 220, padL = 40, padR = 12, padT = 10, padB = 26;
    const plotW = w - padL - padR, plotH = h - padT - padB;
    const n = xLabels.length;
    const stepX = n > 1 ? plotW / (n - 1) : 0;
    const yZero = padT + plotH;
    let grid = '', ylabels = '';
    const steps = Math.round(yMax / yStep);
    for(let s = 0; s <= steps; s++){
      const val = s * yStep;
      const y = padT + plotH - (val / yMax) * plotH;
      grid += '<line class="grid-line" x1="' + padL + '" y1="' + y + '" x2="' + (w - padR) + '" y2="' + y + '"/>';
      ylabels += '<text x="' + (padL - 8) + '" y="' + (y + 4) + '" font-size="11" text-anchor="end">' + val.toFixed(2) + '</text>';
    }
    let dots = '', xlabels = '', pts = '';
    for(let i = 0; i < n; i++){
      const x = padL + i * stepX;
      const yy = (opts.values && opts.values[i] != null) ? padT + plotH - Math.min(opts.values[i] / yMax, 1) * plotH : yZero;
      pts += x + ',' + yy + ' ';
      if(opts.dots){ dots += '<circle cx="' + x + '" cy="' + yy + '" r="3" fill="' + paletteColor(i) + '"/>'; }
      const color = (opts.xColors && opts.xColors[i]) ? opts.xColors[i] : 'var(--ink-faint)';
      xlabels += '<text x="' + x + '" y="' + (h - 6) + '" font-size="10" text-anchor="middle" fill="' + color + '">' + xLabels[i] + '</text>';
    }
    return '<svg viewBox="0 0 ' + w + ' ' + h + '" style="width:100%;height:auto;display:block;">' +
      grid +
      '<polyline points="' + pts + '" fill="none" stroke="var(--red)" stroke-width="2" opacity="0.55"/>' +
      dots + ylabels + xlabels +
      '</svg>';
  }

  function niceStep(x){ const e = Math.pow(10, Math.floor(Math.log10(x))), f = x / e; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * e; }
  function renderDailySalesChart(){
    const hours = [], vals = [];
    for(let i = 0; i <= 23; i++){ hours.push((i < 10 ? '0' + i : i) + ':00'); vals.push(0); }
    todayPays().forEach(p => { vals[new Date(p.ts).getHours()] += p.amount; });
    const mx = Math.max.apply(null, vals), step = mx > 0 ? niceStep(mx / 4) : 0.5;
    document.getElementById('dailySalesChart').innerHTML = buildLineChart(hours, step * 4, step, { dots: true, values: vals });
  }
  function renderPaymentsChart(){
    const m = {}; todayPays().forEach(p => { m[p.method] = (m[p.method] || 0) + p.amount; });
    const e = Object.entries(m), mx = Math.max(1, ...e.map(x => x[1]));
    document.getElementById('paymentsChart').innerHTML = e.length ? e.map(([k, v]) => '<div class="bar-row"><div class="bname">' + esc(k) + '</div><div class="btrack"><div class="bfill" style="width:' + (v / mx * 100) + '%"></div></div><div class="bval">' + fmtTL(v) + '</div></div>').join('') : '<p style="color:var(--ink-faint);">Bugün ödeme yok.</p>';
  }
  function renderOccupancyDonut(){
    let total = 0, occupied = 0;
    regions.forEach(r => r.tables.forEach(n => {
      total++;
      if(carts['table_' + n] && carts['table_' + n].length > 0) occupied++;
    }));
    const emptyCount = total - occupied;
    const emptyPct = total ? (emptyCount / total * 100) : 100;
    const occPct = total ? (occupied / total * 100) : 0;
    const gradient = occupied > 0
      ? 'conic-gradient(var(--red) 0% ' + occPct + '%, #CBD5E3 ' + occPct + '% 100%)'
      : 'conic-gradient(#CBD5E3 0% 100%)';
    const centerLabel = (occupied > 0 ? occPct : emptyPct).toFixed(1) + '%';
    document.getElementById('occupancyChart').innerHTML =
      '<div class="donut-wrap">' +
        '<div class="donut" style="background:' + gradient + ';"><div class="hole">' + centerLabel + '</div></div>' +
        '<div class="donut-legend">' +
          (occupied > 0 ? '<div class="lg-item"><span class="lg-dot" style="background:var(--red)"></span>Dolu</div>' : '') +
          '<div class="lg-item"><span class="lg-dot" style="background:#CBD5E3"></span>Boş</div>' +
        '</div>' +
      '</div>';
  }

  const _origRenderTableGrid = renderTableGrid;
  renderTableGrid = function(){ _origRenderTableGrid(); renderOccupancyDonut(); };

  renderDailySalesChart();
  renderPaymentsChart();
  renderOccupancyDonut();

  // ======================================================================
  // GİDER / MASRAF — data-driven, feeds the home dashboard total
  // ======================================================================
  let giderler = [];
  function renderGiderler(){
    const wrap = document.getElementById('giderList');
    wrap.innerHTML = '';
    giderler.forEach(g => {
      const row = document.createElement('div');
      row.className = 'prow';
      row.innerHTML = '<span class="pic">🧾</span><div class="pmain"><b>' + g.name + '</b><span>' + g.date + '</span></div>' +
        '<span class="pval">₺' + g.amount.toLocaleString('tr-TR', {minimumFractionDigits:2}) + '</span>';
      const d = document.createElement('span'); d.className = 'link-btn'; d.textContent = '🗑';
      d.onclick = async () => { if(await uiConfirm('Gider silinsin mi?')){ giderler.splice(giderler.indexOf(g), 1); renderGiderler(); } };
      row.appendChild(d);
      wrap.appendChild(row);
    });
    const total = giderler.reduce((s, g) => s + g.amount, 0);
    document.getElementById('giderToplam').textContent = '₺' + total.toLocaleString('tr-TR', {minimumFractionDigits:2});
    if(typeof updateHomeStats === 'function') updateHomeStats();
  }
  document.getElementById('btnGiderEkle').addEventListener('click', async () => {
    const name = await uiPrompt('Gider adı:');
    if(!name) return;
    const amount = parseFloat(await uiPrompt('Tutar (₺):', '0')) || 0;
    giderler.push({ name, amount, date: new Date().toLocaleDateString('tr-TR') });
    renderGiderler();
    showToast(name + ' eklendi.');
  });
  renderGiderler();

  // ======================================================================
  // ANA SAYFA — live totals from carts, payments and expenses
  // ======================================================================
  function computeOpenOrdersTotal(){
    return Object.keys(carts).reduce((sum, k) => sum + cartTotal(k), 0);
  }
  function updateHomeStats(){
    recomputeStats();
    try{ renderDailySalesChart(); renderPaymentsChart(); renderReports(); }catch(e){}
    try{ const cs = document.getElementById('screen-ciro'); if(cs && cs.classList.contains('show')) renderCiro(); }catch(e){}
    document.getElementById('homeSalesValue').textContent = '₺' + dailyStats.sales.toLocaleString('tr-TR', {minimumFractionDigits:2});
    document.getElementById('homeGuestValue').textContent = String(dailyStats.guests);
    document.getElementById('homeOpenOrderValue').textContent = '₺' + computeOpenOrdersTotal().toLocaleString('tr-TR', {minimumFractionDigits:2});
    const expenseTotal = giderler.filter(g => g.date === new Date().toLocaleDateString('tr-TR')).reduce((s, g) => s + g.amount, 0);
    document.getElementById('homeExpenseValue').textContent = '₺' + expenseTotal.toLocaleString('tr-TR', {minimumFractionDigits:2});
  }
  function renderGunSonu(){
    recomputeStats();
    document.getElementById('gsCashValue').textContent = '₺' + dailyStats.cashTotal.toLocaleString('tr-TR', {minimumFractionDigits:2});
    document.getElementById('gsCardValue').textContent = '₺' + dailyStats.cardTotal.toLocaleString('tr-TR', {minimumFractionDigits:2});
    document.getElementById('gsGuestValue').textContent = String(dailyStats.guests);
    document.getElementById('gsTotalValue').textContent = '₺' + dailyStats.sales.toLocaleString('tr-TR', {minimumFractionDigits:2});
    try{ renderGunSonuExtra(); }catch(e){}
  }
  updateHomeStats();
  renderGunSonu();
  let staffUsers = [], legacyOffCache = null;
  // ======================================================================
  // (kalıcı kayıt: aşağıdaki PROFESYONEL EKLER bölümünde)
  // ======================================================================
  // FIREBASE — canlı haberleşme (müşteri telefonu ⇄ garson ⇄ mutfak)
  // Aşağıdaki bilgileri Firebase Console > Proje Ayarları > Web uygulaması bölümünden doldurun.
  // Boş bırakılırsa sistem "yerel mod"da (aynı tarayıcıdaki sekmeler arasında) çalışır.
  // ======================================================================
  const FIREBASE_ADMIN_EMAIL = APP_CONFIG.adminEmail || ''; // yalnızca bu Firebase hesabı menüyü yayınlar ve personel dizinini yazar
  const FIREBASE_CONFIG = APP_CONFIG.firebase || {};
  const ADMIN_PIN = '';  // varsayılan PIN yok: ilk girişte yönetici PIN'i belirlenir

  const LocalRT = (() => {
    const K = 'posRT', L = [];
    const rd = () => { try{ return JSON.parse(localStorage.getItem(K)) || {}; }catch(e){ return {}; } };
    const get = (t, p) => { const v = p.split('/').filter(Boolean).reduce((o, k) => (o == null ? o : o[k]), t); return v === undefined ? null : v; };
    const fire = () => { const t = rd(); L.forEach(l => l.cb(get(t, l.p))); };
    const put = (p, v) => {
      const t = rd(), ks = p.split('/').filter(Boolean); let o = t;
      ks.slice(0, -1).forEach(k => { o = o[k] = o[k] || {}; });
      if(v === null) delete o[ks[ks.length - 1]]; else o[ks[ks.length - 1]] = v;
      localStorage.setItem(K, JSON.stringify(t)); fire();
    };
    window.addEventListener('storage', e => { if(e.key === window.__nsk(K)) fire(); });
    return {
      local: true,
      set: (p, v) => put(p, v),
      push: (p, v) => { const id = 'o' + Date.now() + Math.random().toString(36).slice(2, 6); put(p + '/' + id, v); return id; },
      remove: p => put(p, null),
      get: p => Promise.resolve(get(rd(), p)),
      on: (p, cb) => { L.push({ p, cb }); cb(get(rd(), p)); }
    };
  })();
  let RT = LocalRT;

  async function initRT(){
    const c = FIREBASE_CONFIG;
    if(!c.apiKey || !c.databaseURL) return;
    try{
      const B = 'https://www.gstatic.com/firebasejs/11.10.0/'; window.__fbB = B;
      const { initializeApp } = await import(B + 'firebase-app.js');
      const { getDatabase, ref, set, push, onValue, remove, get } = await import(B + 'firebase-database.js');
      const { getAuth, signInAnonymously, signInWithEmailAndPassword, signOut, createUserWithEmailAndPassword, updatePassword, reauthenticateWithCredential, EmailAuthProvider, GoogleAuthProvider, signInWithPopup, linkWithCredential, linkWithPopup, unlink, deleteUser } = await import(B + 'firebase-auth.js');
      const app = initializeApp(c), db = getDatabase(app), auth = getAuth(app); window.__fbApp = app;
      if(auth.authStateReady) await auth.authStateReady();
      if(!auth.currentUser) await signInAnonymously(auth);
      const AUTH_MSG = { 'auth/invalid-credential': 'E-posta veya şifre hatalı.', 'auth/wrong-password': 'Şifre hatalı.', 'auth/user-not-found': 'Bu e-posta ile hesap yok.', 'auth/invalid-email': 'E-posta biçimi geçersiz.', 'auth/too-many-requests': 'Çok fazla deneme. Biraz bekleyin.', 'auth/network-request-failed': 'İnternet bağlantısı yok.', 'auth/operation-not-allowed': 'Firebase’de E-posta/Şifre girişi açık değil.' };
      const _rtSeen = {};
      const rtErr = (op, p, e) => { const c = (e && e.code) || 'hata'; console.error('Firebase ' + op + ' hatası (' + p + '):', c); const k = op + p + c; if(_rtSeen[k] && Date.now() - _rtSeen[k] < 60000) return; _rtSeen[k] = Date.now();
        try{ showToast('⚠ Senkron ' + op + ' hatası: ' + p.split('/')[0] + ' (' + c + ')' + (/permission/i.test(c) ? ' — bu cihaz Firebase personel hesabıyla bağlı değil veya kurallar eşleşmiyor' : '')); }catch(_){} };
      const isAdminAcc = () => !!(auth.currentUser && !auth.currentUser.isAnonymous && (auth.currentUser.email || '').toLowerCase() === FIREBASE_ADMIN_EMAIL.toLowerCase());
      let ownerUid = null;   // Yönetici (işletme sahibi) hesabının uid'si; yalnızca giriş/oturum geri yükleme sırasında işaretlenir
      const isOwnerAcc = () => !!(ownerUid && auth.currentUser && !auth.currentUser.isAnonymous && auth.currentUser.uid === ownerUid);
      const isAdminAny = () => isAdminAcc() || isOwnerAcc();
      const staffAuth = async (needAdmin) => {
        if(auth.currentUser && !auth.currentUser.isAnonymous){
          if(!needAdmin || isAdminAny()) return true;
          try{ await signOut(auth); await signInAnonymously(auth); }catch(e){}
        }
        let err = needAdmin ? 'Devam etmek için Firebase hesabını girin.' : '';
        for(;;){
          const c = await askCred(err); if(!c) return false;
          try{
            await signInWithEmailAndPassword(auth, c.em, c.pw);
            if(needAdmin && !isAdminAcc()){ err = 'Bu hesap yönetici hesabı değil.'; try{ await signOut(auth); await signInAnonymously(auth); }catch(e){} continue; }
            return true;
          }catch(e){ err = AUTH_MSG[e.code] || ('Giriş başarısız: ' + e.code); }
        }
      };
      // ---- isim + şifre ile personel girişi (sentetik e-posta; personel e-postayı görmez) ----
      const uid = () => (auth.currentUser && !auth.currentUser.isAnonymous) ? auth.currentUser.uid : null;
      const toAnon = async () => { ownerUid = null; try{ await signOut(auth); await signInAnonymously(auth); }catch(e){} };
      const staffLogin = async (name, pw) => {
        const n = normName(name); if(!n) return { code: 'bad', known: false };
        let v = 1, known = false;
        try{ const x = await get(ref(db, 'staffVer/' + n)).then(s => s.val()); if(+x >= 1){ v = +x; known = true; } }catch(e){}
        try{
          const cr = await signInWithEmailAndPassword(auth, staffEmail(n, v), pw);
          let role = null; try{ role = await get(ref(db, 'staffRoles/' + cr.user.uid)).then(s => s.val()); }catch(e){}
          if(!role || !role.ad){ await toAnon(); return { code: 'bad', known: true }; }
          if(role.blocked === true){ await toAnon(); return { code: 'blocked' }; }
          ownerUid = role.owner === true ? cr.user.uid : null;
          return { code: 'ok', uid: cr.user.uid, role };
        }catch(e){
          const c = (e && e.code) || '';
          if(c === 'auth/too-many-requests') return { code: 'limit' };
          if(c === 'auth/network-request-failed') return { code: 'net' };
          return { code: 'bad', known };
        }
      };
      const staffLogout = () => toAnon();
      // Admin'in ilk şifresi: Google ile girmiş hesaba e-posta/şifre yöntemi eklenir (sonra isim "Admin" + şifre yeter)
      const adminSetPassword = async (pw) => {
        const u = auth.currentUser; if(!u || u.isAnonymous || !isAdminAcc()) return { code: 'bad' };
        try{ await linkWithCredential(u, EmailAuthProvider.credential(u.email, pw)); return { code: 'ok' }; }
        catch(e){
          const c = (e && e.code) || '';
          if(c === 'auth/weak-password') return { code: 'weak' };
          if(c === 'auth/requires-recent-login') return { code: 'recent' };
          if(c === 'auth/provider-already-linked' || c === 'auth/email-already-in-use' || c === 'auth/credential-already-in-use') return { code: 'has' };
          if(c === 'auth/network-request-failed') return { code: 'net' };
          if(c === 'auth/operation-not-allowed') return { code: 'off' };
          return { code: 'err' };
        }
      };
      // ---- Yönetici: kurtarma Google hesabı (şifre unutulursa Google ile girip yeni şifre belirler) ----
      const googleErr = (e) => {
        const c = (e && e.code) || '';
        if(c === 'auth/popup-closed-by-user' || c === 'auth/cancelled-popup-request') return { code: 'cancel' };
        if(c === 'auth/popup-blocked') return { code: 'popup' };
        if(c === 'auth/operation-not-allowed') return { code: 'goff' };
        if(c === 'auth/unauthorized-domain') return { code: 'domain' };
        if(c === 'auth/network-request-failed') return { code: 'net' };
        if(c === 'auth/credential-already-in-use' || c === 'auth/email-already-in-use') return { code: 'used' };
        if(c === 'auth/requires-recent-login') return { code: 'recent' };
        return { code: 'err' };
      };
      const ownerGoogleEmail = () => { const u = auth.currentUser, p = u && u.providerData.find(x => x.providerId === 'google.com'); return p ? (p.email || 'Google hesabı') : ''; };
      const ownerLinkGoogle = async () => {
        const u = auth.currentUser; if(!isOwnerAcc()) return { code: 'bad' };
        try{
          if(ownerGoogleEmail()) await unlink(u, 'google.com');
          const prov = new GoogleAuthProvider(); prov.setCustomParameters({ prompt: 'select_account' });
          await linkWithPopup(u, prov); return { code: 'ok' };
        }catch(e){ return googleErr(e); }
      };
      const ownerGoogleLogin = async () => {
        try{
          const prov = new GoogleAuthProvider(); prov.setCustomParameters({ prompt: 'select_account' });
          const cr = await signInWithPopup(auth, prov);
          if(isAdminAcc()){ await toAnon(); return { code: 'notlinked' }; }
          let role = null; try{ role = await get(ref(db, 'staffRoles/' + cr.user.uid)).then(s => s.val()); }catch(e){}
          if(!role || role.owner !== true){
            try{ if(!role && cr.user.providerData.length === 1) await deleteUser(cr.user); }catch(_){}
            await toAnon(); return { code: 'notlinked' };
          }
          if(role.blocked === true){ await toAnon(); return { code: 'blocked' }; }
          ownerUid = cr.user.uid; return { code: 'ok', uid: cr.user.uid, role };
        }catch(e){ return googleErr(e); }
      };
      const ownerResetPassword = async (pw) => {
        const u = auth.currentUser; if(!isOwnerAcc()) return { code: 'bad' };
        try{ await updatePassword(u, pw); return { code: 'ok' }; }
        catch(e){ const c = (e && e.code) || ''; return { code: c === 'auth/weak-password' ? 'weak' : c === 'auth/requires-recent-login' ? 'recent' : c === 'auth/network-request-failed' ? 'net' : 'err' }; }
      };
      // Admin girişi: isim "Admin" + Firebase admin hesabının şifresi (PIN / içe aktarma yok)
      const adminLogin = async (pw) => {
        if(!FIREBASE_ADMIN_EMAIL) return { code: 'noadmin' };
        if(!pw){   // şifre yok: Google ile doğrula (hesap e-postası Google tarafından doğrulanır, Firebase'e kullanıcı eklemek gerekmez)
          try{
            const prov = new GoogleAuthProvider(); prov.setCustomParameters({ login_hint: FIREBASE_ADMIN_EMAIL, prompt: 'select_account' });
            await signInWithPopup(auth, prov);
            if(!isAdminAcc()){ await toAnon(); return { code: 'wrong' }; }
            ownerUid = null; return { code: 'ok', uid: auth.currentUser.uid };
          }catch(e){
            const c = (e && e.code) || '';
            if(c === 'auth/popup-closed-by-user' || c === 'auth/cancelled-popup-request') return { code: 'cancel' };
            if(c === 'auth/popup-blocked') return { code: 'popup' };
            if(c === 'auth/operation-not-allowed') return { code: 'goff' };
            if(c === 'auth/unauthorized-domain') return { code: 'domain' };
            if(c === 'auth/network-request-failed') return { code: 'net' };
            return { code: 'bad' };
          }
        }
        try{
          await signInWithEmailAndPassword(auth, FIREBASE_ADMIN_EMAIL, pw);
          if(!isAdminAcc()){ await toAnon(); return { code: 'bad' }; }
          ownerUid = null; return { code: 'ok', uid: auth.currentUser.uid };
        }catch(e){
          const c = (e && e.code) || '';
          if(c === 'auth/too-many-requests') return { code: 'limit' };
          if(c === 'auth/network-request-failed') return { code: 'net' };
          if(c === 'auth/operation-not-allowed') return { code: 'off' };
          return { code: 'bad' };
        }
      };
      const changePassword = async (oldPw, newPw) => {
        const u = auth.currentUser; if(!u || u.isAnonymous || !u.email) return { code: 'bad' };
        try{ await reauthenticateWithCredential(u, EmailAuthProvider.credential(u.email, oldPw)); }
        catch(e){ const c = (e && e.code) || ''; return { code: c === 'auth/too-many-requests' ? 'limit' : c === 'auth/network-request-failed' ? 'net' : 'wrong' }; }
        try{ await updatePassword(u, newPw); return { code: 'ok' }; }
        catch(e){ return { code: (e && e.code) === 'auth/weak-password' ? 'weak' : 'err' }; }
      };
      let secApp = null;
      const createStaff = async (email, pw) => {
        if(!secApp) secApp = initializeApp(c, 'posSec');
        const a = getAuth(secApp);
        try{ const cr = await createUserWithEmailAndPassword(a, email, pw); return cr.user.uid; }
        finally{ try{ await signOut(a); }catch(_){} }
      };
      const clean = v => (v === null ? null : JSON.parse(JSON.stringify(v)));
      RT = {
        local: false, staffAuth, isAdmin: isAdminAny, isRoot: isAdminAcc, changePassword, setOwner: u => { ownerUid = u || null; }, uid, staffLogin, staffLogout, adminLogin, adminSetPassword, ownerGoogleEmail, ownerLinkGoogle, ownerGoogleLogin, ownerResetPassword, createStaff,
        set: (p, v) => set(ref(db, p), clean(v)).catch(e => { rtErr('yazma', p, e); throw e; }),
        push: (p, v) => { const r = push(ref(db, p)); set(r, clean(v)).catch(e => rtErr('yazma', p, e)); return r.key; },
        remove: p => remove(ref(db, p)).catch(e => { rtErr('silme', p, e); throw e; }),
        get: p => get(ref(db, p)).then(s => s.val()),
        on: (p, cb) => onValue(ref(db, p), s => cb(s.val()), err => rtErr('okuma', p, err))
      };
    }catch(e){ console.error('Firebase başlatılamadı, yerel moda geçildi:', e); RT = LocalRT; }
  }

  const $id = id => document.getElementById(id);
  function askCred(err){
    return new Promise(res => {
      const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 1200;
      bg.innerHTML = '<div class="modal-box"><h3 style="margin:0 0 6px">Cihaz Yetkilendirme</h3><p style="margin:0 0 8px;font-size:.82rem;color:var(--ink-faint)">Bu cihaz ilk kez personel olarak bağlanıyor. Firebase personel hesabını (e-posta/şifre) bir kez girin; cihaz hatırlar.</p>' +
        '<input type="email" id="crEm" placeholder="Firebase e-posta" autocomplete="username" style="width:100%;padding:10px;margin:4px 0"><input type="password" id="crPw" placeholder="Firebase şifre" autocomplete="current-password" style="width:100%;padding:10px;margin:4px 0">' +
        '<div style="color:var(--red);font-size:.85rem;min-height:18px">' + esc(err || '') + '</div><div style="display:flex;gap:8px"><button class="btn-save" id="crOk" style="margin:0">Bağlan</button><button class="btn-save" id="crNo" style="margin:0;background:var(--ink-faint)">Vazgeç</button></div></div>';
      document.body.appendChild(bg); const em = bg.querySelector('#crEm'), pw = bg.querySelector('#crPw'); em.focus();
      const ok = () => { if(!em.value.trim() || !pw.value) return; bg.remove(); res({ em: em.value.trim(), pw: pw.value }); };
      bg.querySelector('#crOk').onclick = ok; bg.querySelector('#crNo').onclick = () => { bg.remove(); res(null); };
      pw.onkeydown = em.onkeydown = e => { if(e.key === 'Enter') ok(); };
    });
  }
  const arr = x => Array.isArray(x) ? x.filter(Boolean) : Object.values(x || {});
  let pubData = null, staffMode = false, pubReady = false, pubTimer = 0;
  const PUB_CACHE = 'posPubCache';
  try{ const c = JSON.parse(localStorage.getItem(PUB_CACHE) || 'null'); if(c && c.categories){ pubData = c; pubReady = true; } }catch(e){}

  // ---------------- MÜŞTERİ DİJİTAL MENÜ ----------------
  let cCart = {}, cTab = 0, cSub = -1, cSubOf = [], myOrderId = null, cOpen = false;
  const qp = new URLSearchParams(location.search);
  function customerData(){
    if(pubData && pubData.categories){
      const tb = arr(pubData.tables);
      if(pubData.categories){ const cc = arr(pubData.categories).map(c => ({ name: c.name, grp: c.grp, sub: c.sub, gv: c.gv || 0, icon: c.icon || '', img: oldImg(c.img) ? '' : (c.img || ''), products: arr(c.products).map(pr => oldImg(pr.img) ? Object.assign({}, pr, { img: '' }) : pr) })); cc._gm = arr(pubData.groupMeta).filter(Boolean); return { categories: cc, tables: tb }; }
      return { categories, tables: tb }; // eski sürümden kalan yayın menüsü yok sayılır
    }
    return { categories, tables: regions.flatMap(r => r.tables.map(n => ({ n, label: tableLabels[n] || ('Masa ' + n) }))) };
  }
  function cList(){
    const d = customerData(), q = ($id('cSearch') ? $id('cSearch').value : '').trim().toLocaleLowerCase('tr-TR');
    const gs = menuGroups(d.categories); if(cTab >= gs.length) cTab = 0;
    if(q){ cSubOf = []; return d.categories.flatMap(c => c.products).filter(p => (p.name + ' ' + T(p.name)).toLocaleLowerCase('tr-TR').includes(q)); }
    const out = []; cSubOf = []; ((gs[cTab] || { subs: [] }).subs).filter(sb => cSub < 0 || sb.idx === cSub).forEach(sb => sb.cat.products.forEach(p => { out.push(p); cSubOf.push(sb.label); }));
    return out;
  }
  function isMenuOnly(){ return pubData ? pubData.menuOnly === true : ((typeof RT !== 'undefined' && RT.local) ? settings.menuOnly === true : false); }
  function cCount(){ return Object.values(cCart).reduce((s, i) => s + i.qty, 0); }
  function cTotal(){ return Object.values(cCart).reduce((s, i) => s + i.qty * i.unit, 0); }

  // ---- özel onay / giriş pencereleri (tarayıcı confirm/prompt yerine) ----
  function uiDialog(msg, withInput, def){
    return new Promise(res => {
      const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 3000;
      bg.innerHTML = '<div class="modal-box" role="dialog" aria-modal="true"><p style="margin:0 0 10px;white-space:pre-line;line-height:1.4"></p>' + (withInput ? '<input type="text" style="width:100%;padding:10px;margin:0 0 10px;box-sizing:border-box">' : '') +
        '<div style="display:flex;gap:8px"><button class="btn-save" data-r="0" style="margin:0;background:var(--ink-faint);flex:1">Vazgeç</button><button class="btn-save" data-r="1" style="margin:0;flex:1">Tamam</button></div></div>';
      bg.querySelector('p').textContent = String(msg == null ? '' : msg);
      const inp = bg.querySelector('input'); if(inp) inp.value = def == null ? '' : def;
      const done = v => { bg.remove(); res(v); };
      bg.addEventListener('click', e => { const b = e.target.closest('button[data-r]'); if(b) done(b.dataset.r === '1' ? (inp ? inp.value : true) : (inp ? null : false)); else if(e.target === bg) done(inp ? null : false); });
      bg.addEventListener('keydown', e => { if(e.key === 'Enter') done(inp ? inp.value : true); else if(e.key === 'Escape') done(inp ? null : false); });
      document.body.appendChild(bg); const f = inp || bg.querySelector('button[data-r="1"]'); setTimeout(() => f.focus(), 30);
    });
  }
  const uiConfirm = m => uiDialog(m, false), uiPrompt = (m, d) => uiDialog(m, true, d);
  // anahtarlı DOM önbelleği: kategori değişince / sepete ekleyince kartlar ve görseller yeniden oluşturulmaz (titreme ve görsel yeniden belirme biter)
  const _kc = {};
  function keyed(name, container, entries, act){
    const cache = _kc[name] || (_kc[name] = new Map());
    const nodes = entries.map(e => {
      let c = cache.get(e.key);
      if(!c || c.html !== e.html){ const t = document.createElement('template'); t.innerHTML = e.html; c = { html: e.html, node: t.content.firstElementChild }; cache.set(e.key, c); }
      if(act) act(c.node, e); return c.node;
    });
    nodes.forEach((n, i) => { if(container.children[i] !== n) container.insertBefore(n, container.children[i] || null); });
    while(container.children.length > nodes.length) container.lastElementChild.remove();
  }
  let _preDone = false;
  function preloadMenuImgs(d){
    if(_preDone) return; _preDone = true;
    const urls = []; d.categories.forEach(c => { if(/^https:/i.test(c.img || '')) urls.push(c.img); c.products.forEach(p => { if(/^https:/i.test(p.img || '')) urls.push(p.img); }); });
    (function go(){ urls.splice(0, 6).forEach(u => { const im = new Image(); im.decoding = 'async'; im.referrerPolicy = 'no-referrer'; im.src = u; }); if(urls.length) (window.requestIdleCallback || setTimeout)(go, 250); })();
  }
  const _lastHtml = {};
  function setHtml(id, html){ if(_lastHtml[id] === html && $id(id).innerHTML) return; _lastHtml[id] = html; $id(id).innerHTML = html; }
  function renderCustomer(){
    try{ refreshBrandUI(); }catch(e){}
    if(!pubReady && !staffMode){
      $id('customerView').classList.add('c-loading');
      if(!$id('cItems').dataset.sk){ $id('cItems').dataset.sk = '1'; $id('cTabs').innerHTML = ''; $id('cItems').innerHTML = Array(6).fill('<div class="c-item card c-sk"><div class="vis v-card"></div><div class="nm"><b>&nbsp;</b></div></div>').join(''); }
      return;
    }
    if(!staffMode && custGateNeeded()){ showCustGate(); return; } hideCustGate();
    $id('customerView').classList.remove('c-loading'); delete $id('cItems').dataset.sk;
    const d = customerData(), mo = isMenuOnly();
    $id('customerView').classList.toggle('menu-only', mo); renderLangChips();
    const gs = menuGroups(d.categories); if(cTab >= gs.length) cTab = 0;
    const sel = $id('cMasa'), prev = sel.value || qp.get('masa') || '';
    const opts = '<option value="">Masanızı seçin…</option>' + d.tables.map(t => '<option value="' + t.n + '">' + esc(t.label) + '</option>').join('');
    if(sel.innerHTML !== opts){ sel.innerHTML = opts; sel.value = prev; }
    keyed('tabs', $id('cTabs'), gs.map((g, i) => ({ key: 't' + cLang + g.name, on: i === cTab, html: '<div class="c-tab c-cat" data-i="' + i + '">' + catVis(g) + '<span class="lb">' + esc(T(g.name)) + '</span></div>' })), (n, e) => { n.classList.toggle('active', e.on); n.dataset.i = e.html.match(/data-i="(\d+)"/)[1]; });
    const subsOn = gs[cTab] && gs[cTab].subs.length > 1 && !($id('cSearch').value || '').trim();
    $id('cSubs').style.display = subsOn ? '' : 'none';
    keyed('subs', $id('cSubs'), subsOn ? [{ idx: -1, label: 'Tümü' }].concat(gs[cTab].subs).map(sb => ({ key: 's' + cLang + cTab + '|' + sb.idx, on: sb.idx === cSub, html: '<div class="c-tab c-subv" data-s="' + sb.idx + '">' + (sb.cat ? visHtml({ img: sb.cat.img, icon: sb.cat.icon, name: sb.cat.name }, '', 'v-sub') : '') + '<span>' + esc(T(sb.label)) + '</span></div>' })) : [], (n, e) => { n.classList.toggle('active', e.on); });
    const lst = cList();
    if(!lst.length){ $id('cItems').innerHTML = '<p style="text-align:center;color:var(--ink-faint)">' + (($id('cSearch').value || '').trim() ? 'Ürün bulunamadı.' : 'Menü hazırlanıyor…') + '</p>'; }
    else{
      const ents = [];
      lst.forEach((p, i) => {
        const q = (cCart[p.name] || {}).qty || 0;
        if(cSub < 0 && cSubOf[i] && cSubOf[i] !== cSubOf[i - 1] && subsOn) ents.push({ key: 'h' + cLang + cTab + '|' + cSubOf[i], html: '<div class="c-subttl">' + esc(T(cSubOf[i])) + '</div>' });
        const sk = custStk(p.name), ctl = mo ? '' : (sk && sk.out && sk.b) ? '<span class="c-soldout">Tükendi</span>' : q ? '<div class="qty-ctl"><button class="qbtn" data-p="' + i + '" data-d="-1">−</button><b class="qv">' + q + '</b><button class="qbtn" data-p="' + i + '" data-d="1">+</button></div>' : '<button class="qbtn" data-p="' + i + '" data-d="1">+</button>';
        ents.push({ key: 'p' + cLang + p.name, ctl, html: '<div class="c-item card' + (sk && sk.out ? ' c-out' : '') + '">' + visHtml(p, '', 'v-card') + '<div class="nm"><b>' + esc(T(p.name)) + '</b>' + (p.desc ? '<small>' + esc(T(p.desc)) + '</small>' : '') + (sk ? (sk.out ? '<span class="c-stk out">Tükendi</span>' : '<span class="c-stk low">Son ' + sk.left + ' adet</span>') : '') + '</div><div class="cfoot"><span class="pr">' + fmtTL(p.price) + '</span></div></div>' });
      });
      keyed('items', $id('cItems'), ents, (n, e) => {
        if(e.ctl === undefined || n.dataset.c === e.ctl) return;
        const f = n.querySelector('.cfoot'); while(f.children.length > 1) f.lastElementChild.remove();
        f.insertAdjacentHTML('beforeend', e.ctl); n.dataset.c = e.ctl;
      });
      preloadMenuImgs(d);
    }
    const n = cCount(), btn = $id('cSend'); if(!n) cOpen = false;
    $id('cCartList').style.display = cOpen ? 'block' : 'none'; $id('cNote').style.display = cOpen ? '' : 'none'; aiCustUI();
    $id('cCartList').innerHTML = Object.values(cCart).map(i => '<div class="c-crow"><span>' + esc(T(i.name)) + '</span><div class="qty-ctl"><button class="qbtn cq" data-n="' + esc(i.name) + '" data-d="-1">−</button><b class="qv">' + i.qty + '</b><button class="qbtn cq" data-n="' + esc(i.name) + '" data-d="1">+</button></div></div>').join('');
    if(mo){ $id('cStatus').style.display = 'none'; $id('cCartList').innerHTML = ''; }
    btn.disabled = n === 0;
    btn.textContent = !n ? 'Sepet boş' : (cOpen ? 'Siparişi Garsona Gönder · ' : '🛒 Sepeti Gör · ') + fmtTL(cTotal()) + ' (' + n + ' ürün)';
  }
  $id('cTabs').addEventListener('click', e => { const t = e.target.closest('.c-tab'); if(t){ cTab = +t.dataset.i; cSub = -1; renderCustomer(); } });
  $id('cSubs').addEventListener('click', e => { const t = e.target.closest('.c-tab'); if(t){ cSub = +t.dataset.s; renderCustomer(); } });
  $id('cItems').addEventListener('click', e => {
    if(isMenuOnly()) return;
    const b = e.target.closest('.qbtn'); if(!b) return;
    const p = cList()[+b.dataset.p]; if(!p) return;
    const cur = cCart[p.name] || { name: p.name, unit: p.price, qty: 0 };
    if(+b.dataset.d > 0){ const sk = custStk(p.name); if(sk && sk.b){ const av = sk.out ? 0 : sk.left; if(cur.qty + 1 > av){ showToast(av <= 0 ? 'Bu ürün tükendi.' : 'Stokta yalnızca ' + av + ' adet kaldı.'); return; } } }
    cur.qty += +b.dataset.d;
    if(cur.qty <= 0) delete cCart[p.name]; else cCart[p.name] = cur;
    renderCustomer();
  });
  $id('cMasa').addEventListener('change', renderCustomer);
  $id('cSearch').addEventListener('input', renderCustomer);
  $id('cCartList').addEventListener('click', e => { const b = e.target.closest('.cq'); if(!b) return; const it = cCart[b.dataset.n]; if(!it) return; if(+b.dataset.d > 0){ const sk = custStk(it.name); if(sk && sk.b){ const av = sk.out ? 0 : sk.left; if(it.qty + 1 > av){ showToast(av <= 0 ? 'Bu ürün tükendi.' : 'Stokta yalnızca ' + av + ' adet kaldı.'); return; } } } it.qty += +b.dataset.d; if(it.qty <= 0) delete cCart[b.dataset.n]; renderCustomer(); });
  const coText = {
    bekliyor: '⏳ Siparişiniz garsona iletildi, onay bekleniyor…',
    onaylandi: '✅ Siparişiniz onaylandı, hazırlanıyor 👨‍🍳',
    reddedildi: '❌ Siparişiniz alınamadı. Lütfen garsonumuzu çağırın.'
  };
  function askTable(){
    return new Promise(res => {
      const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 1300;
      bg.innerHTML = '<div class="modal-box"><h3 style="margin:0">Hangi masadasınız?</h3><div class="c-tgrid">' + customerData().tables.map(t => '<button data-n="' + esc(String(t.n)) + '">' + esc(t.label) + '</button>').join('') + '</div><button class="btn-save" id="tbNo" style="margin:0;background:var(--ink-faint)">Vazgeç</button></div>';
      document.body.appendChild(bg);
      bg.onclick = e => { const b = e.target.closest('button[data-n]'); if(b){ bg.remove(); res(b.dataset.n); } else if(e.target.id === 'tbNo' || e.target === bg){ bg.remove(); res(null); } };
    });
  }
  $id('cSend').addEventListener('click', async () => {
    if(isMenuOnly()) return;
    if(!cCount()) return;
    if(!cOpen){ cOpen = true; renderCustomer(); return; }
    let masa = $id('cMasa').value;
    if(!masa){ masa = await askTable(); if(!masa) return; $id('cMasa').value = masa; }
    const t = customerData().tables.find(x => String(x.n) === masa);
    const order = { table: masa, label: t ? t.label : 'Masa ' + masa, ts: Date.now(), status: 'bekliyor', note: $id('cNote').value.trim().slice(0, 200),
      items: Object.values(cCart).map(i => ({ name: i.name, unit: i.unit, qty: i.qty, sub: 'tam' })) };
    const btn = $id('cSend'); btn.disabled = true;
    const id = RT.push('customerOrders', order);
    myOrderId = id; cCart = {}; $id('cNote').value = '';
    const box = $id('cStatus'); box.style.display = 'block'; box.textContent = coText.bekliyor;
    RT.on('customerOrders/' + id, v => { if(v && myOrderId === id) box.textContent = coText[v.status] || coText.bekliyor; });
    renderCustomer();
  });

  // ---------------- PERSONEL GİRİŞİ ----------------
  $id('loginCancel').addEventListener('click', () => $id('loginModal').classList.remove('show'));
  $id('loginOk').addEventListener('click', () => tryLogin());
  $id('loginPass').addEventListener('keydown', e => { if(e.key === 'Enter') tryLogin(); });
  $id('loginName').addEventListener('keydown', e => { if(e.key === 'Enter') $id('loginPass').focus(); });
  $id('btnLogout').addEventListener('click', async () => { try{ if(curUser && (curUser.uid || curUser.sup) && RT.staffLogout) await RT.staffLogout(); }catch(e){} sessionStorage.removeItem('posUser'); sessionStorage.removeItem('posStaff'); sessionStorage.removeItem('posScreen'); location.reload(); });

  // ---------------- GARSON: gelen müşteri siparişleri ----------------
  let coData = {}, coSeen = new Set(), coFirst = true, kitchenData = {}, kSeen = new Set(), kFirst = true, lastPub = '';
  function beep(){ try{ const a = new (window.AudioContext || window.webkitAudioContext)(), o = a.createOscillator(), g = a.createGain(); o.connect(g); g.connect(a.destination); o.frequency.value = 880; g.gain.value = .15; o.start(); setTimeout(() => { o.stop(); a.close(); }, 350); }catch(e){} }
  const pendingCO = () => Object.entries(coData || {}).filter(([, o]) => o && o.status === 'bekliyor').sort((a, b) => a[1].ts - b[1].ts);
  const hhmm = ts => new Date(ts).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
  const byNames = cart => [...new Set((cart || []).map(i => i.by).filter(Boolean))];   // adisyona ürün giren kişiler
  function renderCO(){
    const list = pendingCO();
    const bd = $id('coBadge'); bd.textContent = list.length; bd.classList.toggle('on', list.length > 0);
    $id('coList').innerHTML = list.length ? list.map(([id, o]) =>
      '<div class="co-card"><b>' + esc(o.label) + '</b> <span style="color:var(--ink-faint);font-size:.8rem;">· ' + hhmm(o.ts) + '</span>' +
      arr(o.items).map(i => '<div>' + i.qty + '× ' + esc(i.name) + '</div>').join('') +
      (o.note ? '<div style="margin-top:6px;color:var(--ink-dim);font-size:.85rem;">📝 ' + esc(o.note) + '</div>' : '') +
      '<div class="acts"><button class="b-ok" data-id="' + id + '" data-a="ok">✔ Onayla</button><button class="b-no" data-id="' + id + '" data-a="no">✕ Reddet</button></div></div>'
    ).join('') : '<p style="color:var(--ink-faint);text-align:center;">Bekleyen müşteri siparişi yok.</p>';
  }
  $id('coList').addEventListener('click', e => {
    const b = e.target.closest('button'); if(!b) return;
    const o = coData[b.dataset.id]; if(!o || o.status !== 'bekliyor') return;
    if(b.dataset.a === 'ok') approveCO(b.dataset.id, o); else RT.set('customerOrders/' + b.dataset.id + '/status', 'reddedildi');
    setTimeout(() => { if(!pendingCO().length) $id('coModal').classList.remove('show'); }, 80);
  });
  $id('btnCO').addEventListener('click', () => { renderCO(); $id('coModal').classList.add('show'); });
  $id('coClose').addEventListener('click', () => $id('coModal').classList.remove('show'));

  // ---------------- MUTFAK ----------------
  $id('btnKitchen').addEventListener('click', () => { showScreen('mutfak'); renderKitchen(); });

  // ---------------- GARSON PANELİ BAŞLAT ----------------
  function publishPublic(){
    const tables = regions.flatMap(r => r.tables.map(n => ({ n, label: tableLabels[n] || ('Masa ' + n) })));
    const data = { categories: migrateMenuGroups(stripOldImgs(categories)).map(c => ({ name: c.name, grp: c.grp || c.name, sub: c.sub || '', gv: c.gv || 0, icon: c.icon || '', img: c.img || '', products: c.products.map(p => ({ name: p.name, icon: p.icon || '', price: p.price, desc: p.desc || '', img: p.img || '' })) })), menuVer: MENU_VER, groupMeta: groupMeta.map(m => ({ name: m.name, icon: m.icon || '', img: m.img || '', ord: typeof m.ord === 'number' ? m.ord : -1 })), tables, menuOnly: !!settings.menuOnly, custPw: settings.custPw ? custHashOf(settings.custPw) : '', wifiName: settings.wifiName || '', wifiPass: settings.wifiPass || '', wifiOn: settings.wifiOn !== false, brand: settings.brand || null, stock: (function(){ try{ return stkPublic(); }catch(e){ return null; } })(), social: (function(){ try{ return socialList(); }catch(e){ return []; } })(), trm: settings.trm || {} };
    if(!RT.local && RT.isAdmin && !RT.isAdmin()){ if(curUser && curUser.admin && Date.now() - (window.__pubWarn || 0) > 60000){ window.__pubWarn = Date.now(); showToast('Menü yayınlanamadı: çıkış yapıp isim "Yönetici" + şifre ile giriş yapın.'); } return; } // yalnızca yönetici hesabı yayınlar
    if(holdImgs) return; // güncel veri gelmeden eski yerel menüyü yayınlayıp müşteriye eski görseli gösterme
    const s = JSON.stringify(data);
    if(s !== lastPub){ lastPub = s; RT.set('public', data); }
  }
  function enterStaff(){
    if(staffMode) return;
    staffMode = true; document.body.classList.add('staff'); if(window.__staffUI) window.__staffUI.show();
    $id('rtMode').textContent = RT.local ? '● Yerel mod (Firebase ayarsız)' : '● Canlı bağlantı';
    RT.on('customerOrders', v => {
      coData = v || {};
      const pend = pendingCO(); let fresh = 0;
      pend.forEach(([id]) => { if(!coSeen.has(id)){ coSeen.add(id); fresh++; } });
      if(fresh && !coFirst){ beep(); showToast('🔔 Yeni müşteri siparişi: ' + pend[pend.length - 1][1].label); }
      if(coFirst && pend.length) showToast('🔔 ' + pend.length + ' bekleyen müşteri siparişi var.');
      coFirst = false; renderCO(); try{ renderSmKanban(); renderSmTableGrid(); renderTableGrid(); }catch(e){}
    });
    RT.on('.info/connected', v => { if(RT.local) setConn('loc'); else { setConn(v ? 'ok' : 'bad'); if(v) markSync(); } });
    RT.on('kitchen', v => {
      kitchenData = v || {};
      Object.keys(kitchenData).forEach(id => kSeen.add(id));
      kFirst = false; markSync(); renderKitchen(); try{ renderSmTableGrid(); renderTableGrid(); }catch(e){}
    });
    startStateSync(); publishPublic(); setInterval(publishPublic, 3000);
    applyPerms(); goLastScreen();
  }
  // ======================================================================
  // BÖLÜM 2 — roller/yetkiler, paket & gel-al adisyonları, mutfak grupları,
  //           müşteri yönetimi, açık hesap, fiş, logo
  // ======================================================================
  const ROLES = ['Garson', 'Kurye', 'Kasa', 'Müdür', 'Çağrı Merkezi', 'Mutfak'];
  const PERM_DEFS = [
    ['orders', 'Sipariş alma / adisyon düzenleme', 'Masa, paket ve gel-al adisyonuna ürün ekleme, not yazma, mutfağa gönderme', [1, 0, 1, 1, 1, 0]],
    ['pay', 'Ödeme alma', 'Tahsilat, hesap bölme, açık hesaba yazma', [1, 1, 1, 1, 1, 0]],
    ['discount', 'İndirim ve ikram', 'İndirim uygulama, ödenmez / ikram işaretleme', [0, 0, 1, 1, 0, 0]],
    ['cancel', 'İptal yetkisi', 'Adisyon iptali ve mutfağa gitmiş ürünü silme / azaltma', [0, 0, 1, 1, 0, 0]],
    ['move', 'Masa taşıma / birleştirme', 'Adisyonu başka masaya taşıma', [1, 0, 1, 1, 1, 0]],
    ['courier', 'Paket teslimat takibi', 'Paket ve gel-al listesini görme, "yola çıktı / hazır" işaretleme', [0, 1, 0, 1, 1, 0]],
    ['kitchen', 'Mutfak ekranı (işlem yapabilir)', '"Okudum anladım", hazır / teslim işaretleme ve sesli uyarı', [0, 0, 0, 1, 0, 1]],
    ['kitchenView', 'Mutfak ekranını görme (müdahale edemez)', 'Mutfak siparişlerini yalnızca izler; işaretleme yapamaz, uyarı sesi çıkmaz', [0, 0, 1, 1, 0, 1]],
    ['customers', 'Müşteri yönetimi', 'Müşteri ekleme, düzenleme, silme, cari tahsilat', [0, 0, 1, 1, 1, 0]],
    ['expenses', 'Gider ve zayi işlemleri', 'Gider / masraf ve zayi kaydı (canlı bağlantıda yalnızca yönetici görür)', [0, 0, 1, 1, 0, 0]],
    ['stock', 'Stok yönetimi', 'Ürün stoğunu görme, adet ekleme ve sayım yapma', [0, 0, 1, 1, 0, 0]],
    ['reports', 'Raporlar ve gün sonu', 'Ana sayfa, tüm raporlar, günü kapatma (canlı bağlantıda yalnızca yönetici görür)', [0, 0, 1, 1, 0, 0]],
    ['tables', 'Masa ve bölge düzeni', 'Bölge / masa ekleme, silme, yeniden adlandırma', [0, 0, 0, 1, 0, 0]],
    ['menu', 'Menü, ürün ve tanımlar', 'Ürün, kategori, birim, özellik, KDV, indirim, mutfak grubu', [0, 0, 0, 1, 0, 0]],
    ['users', 'Kullanıcı ve yetki yönetimi', 'Kullanıcı ekleme, şifre, yetki tablosu', [0, 0, 0, 1, 0, 0]],
    ['settings', 'Ayarlar, yedek ve dijital menü', 'Restoran ayarları, ödeme tipleri, yedekleme, QR menü', [0, 0, 0, 1, 0, 0]]
  ];
  const SCR_PERM = {
    home: 'reports', 'siparis-masa': 'orders', paketler: ['orders', 'courier'], order: ['orders', 'pay', 'courier'], mutfak: ['kitchen', 'kitchenView'],
    tables: 'tables', urunler: 'menu', birimler: 'menu', ozellikler: 'menu', kdv: 'menu', indirimler: 'menu', mutfakgruplari: 'menu', odenmezler: 'menu',
    digitalmenu: 'settings', ai: 'settings', settings: 'settings', musteriler: 'customers', gider: 'expenses', zayi: 'expenses', users: 'users', perms: 'users',
    ciro: 'reports', 'rapor-urun': 'reports', 'rapor-gunsonu': 'reports', 'rapor-vardiya': 'reports', 'rapor-istatistik': 'reports', 'rapor-fire': 'reports'
  };
  function defaultPerms(){ const p = {}; PERM_DEFS.forEach(d => { p[d[0]] = d[3].slice(); }); return p; }
  perms = defaultPerms();
  function normPerms(src){
    const p = defaultPerms();
    if(src && typeof src === 'object') Object.keys(p).forEach(k => { if(Array.isArray(src[k])) p[k] = ROLES.map((r, i) => src[k][i] ? 1 : (src[k][i] === 0 ? 0 : p[k][i])); });
    if(src && typeof src === 'object' && !Array.isArray(src.kitchenView) && Array.isArray(src.kitchen)){   // eski kayıt: mutfak izni yalnızca Müdür/Mutfak'ta işlem, diğerleri izleme
      p.kitchenView = ROLES.map((r, i) => src.kitchen[i] ? 1 : 0);
      p.kitchen = ROLES.map((r, i) => (src.kitchen[i] && (r === 'Müdür' || r === 'Mutfak')) ? 1 : 0);
    }
    return p;
  }
  const PRIV_PERMS = ['reports', 'expenses'];   // ciro / rapor / gider: canlı bağlantıda personel hesabına hiçbir zaman açılmaz
  function can(p){
    if(!curUser) return false; if(curUser.admin) return true;
    if(!RT.local && PRIV_PERMS.indexOf(p) >= 0) return false;
    const i = ROLES.indexOf(curUser.gorev); return i >= 0 && !!(perms[p] && perms[p][i]);
  }
  function canAny(need){ return !need || (Array.isArray(need) ? need.some(can) : can(need)); }
  function screenAllowed(name){ return !staffMode || canAny(SCR_PERM[name]); }
  function uname(){ return curUser ? curUser.ad : ''; }
  function regionAllowed(r){ return !curUser || curUser.admin || !curUser.bolge || curUser.bolge === '—' || curUser.bolge === r.name; }

  const roleLabel = u => u.sup ? 'Admin' : u.admin ? 'Yönetici' : u.gorev;
  function applyPerms(){
    document.querySelectorAll('.sidebar .nav-item[data-screen]').forEach(el => { el.style.display = screenAllowed(el.dataset.screen) ? '' : 'none'; });
    const coOk = can('orders'); $id('navCO').style.display = coOk ? '' : 'none';
    document.querySelectorAll('.sidebar .nav-fold').forEach(f => { f.style.display = [...f.querySelectorAll('.nav-item[data-screen]')].some(x => x.style.display !== 'none') ? '' : 'none'; });
    document.querySelectorAll('.sidebar .nav-sec').forEach(sec => {
      const vis = [...sec.querySelectorAll('.nav-item[data-screen], #navCO')].some(x => x.style.display !== 'none' && (!x.closest('.nav-fold') || x.closest('.nav-fold').style.display !== 'none'));
      sec.style.display = vis ? '' : 'none';
    });
    $id('custLockCard').style.display = can('settings') ? '' : 'none';
    { const pf = $id('setPin') && $id('setPin').closest('.field'); if(pf) pf.style.display = (curUser && curUser.admin && !curUser.owner && RT.local) ? '' : 'none';
      const op = $id('ownerPwField'); if(op) op.style.display = (curUser && (curUser.owner || curUser.sup) && !RT.local) ? '' : 'none';
      const og = $id('ownerGoogleField'); if(og){ const okg = !!(curUser && curUser.owner && !RT.local); og.style.display = okg ? '' : 'none'; if(okg){ const ge = RT.ownerGoogleEmail ? RT.ownerGoogleEmail() : ''; $id('ownerGoogleInfo').textContent = ge ? ('Bağlı hesap: ' + ge) : 'Bağlı Google hesabı yok — şifreni unutursan Admin sıfırlamak zorunda kalır.'; } }
      const of = $id('ownerAccField'); if(of) of.style.display = (curUser && curUser.sup && !RT.local) ? '' : 'none';
      const bt = $id('tabMarka'), bp = $id('tab-marka'), okb = !!(curUser && (curUser.sup || (RT.local && curUser.admin))); if(bt) bt.style.display = okb ? '' : 'none'; if(!okb && bp && bp.style.display === 'block'){ const g = document.querySelector('.tab[data-tab="genel"]'); if(g) g.click(); }
      const sf = $id('supPinField'); if(sf) sf.style.display = 'none'; }
    if(curUser){ $id('sbAv').textContent = (curUser.ad || '?').trim().charAt(0).toLocaleUpperCase('tr-TR') || '?'; $id('sbUserName').textContent = curUser.ad; $id('sbUserRole').textContent = roleLabel(curUser) + ' · ' + (RT.local ? 'Yerel mod' : 'Canlı bağlantı'); }
    try{ custLockRender(); }catch(e){}
    $id('btnCO').style.display = can('orders') ? '' : 'none';
    $id('btnKitchen').style.display = canAny(['kitchen', 'kitchenView']) ? '' : 'none';
    const kOnly = !!curUser && !curUser.admin && screenAllowed('mutfak') && !Object.keys(SCR_PERM).filter(k => k !== 'mutfak').some(screenAllowed);
    document.body.classList.toggle('kitchen-only', kOnly);
    if(kOnly) keepAwake();
    if($id('rtMode') && curUser) $id('rtMode').textContent = '👤 ' + curUser.ad + ' · ' + roleLabel(curUser) + '   ' + (RT.local ? '● Yerel mod' : '● Canlı');
  }
  // sayfa yenilenince kalınan ekrana dön (sipariş/adisyon ekranı bağlam istediği için hariç)
  function goLastScreen(){
    let n = null; try{ n = sessionStorage.getItem('posScreen'); }catch(e){}
    if(n && n !== 'order' && document.getElementById('screen-' + n) && screenAllowed(n)){ showScreen(n); if(n === 'siparis-masa'){ try{ renderSiparisMasa(); }catch(e){} } }
    else goHome();
  }
  function goHome(){
    const first = ['home', 'siparis-masa', 'paketler', 'mutfak'].find(screenAllowed);
    if(first){ showScreen(first); if(first === 'siparis-masa') renderSiparisMasa(); }
    else showToast('Bu kullanıcıya hiçbir ekran için yetki verilmemiş.');
  }
  function applyOrderPerms(){
    const key = currentCartKey, ed = can('orders');
    $id('btnToggleMenuPicker').parentElement.style.display = ed ? '' : 'none';
    $id('btnSaveOrder').style.display = ed ? '' : 'none';
    $id('btnTogglePayment').style.display = can('pay') ? '' : 'none';
    $id('btnCancelOrder').style.display = can('cancel') ? '' : 'none';
    $id('btnMoveTable').style.display = (can('move') && key.startsWith('table_')) ? '' : 'none';
    $id('btnMoveTable').parentElement.style.display = (can('cancel') || (can('move') && key.startsWith('table_'))) ? '' : 'none';
    $id('ppDiscSel').closest('.pp-split-row').style.display = can('discount') ? '' : 'none';
    $id('btnWaive').style.display = can('discount') ? '' : 'none';
    $id('guestNo').disabled = !ed;
    const isT = key.startsWith('table_');
    $id('btnRenameTable').style.display = (ed && isT) ? '' : 'none';
    $id('mpRename').style.display = (ed && isT) ? '' : 'none';
    if(!ed) $id('menuPicker').style.display = 'none';
  }
  function onScreen(n){
    $id('sidebar').classList.remove('open');
    try{ smFullApply(n); }catch(e){}
    try{ setTimeout(kAlarmSync, 0); }catch(e){}
    if(n === 'paketler') renderPaketler();
    if(n === 'perms') renderPerms();
    if(n === 'users'){ fillBolge(); renderUsers(); }
    if(n === 'mutfak') renderKitchen();
    if(n === 'mutfakgruplari') renderMutfakRows();
    if(n === 'musteriler') renderCustomers();
    if(n === 'rapor-gunsonu') renderGunSonu();
    if(n === 'ciro') renderCiro(true);
    if(n === 'rapor-vardiya' || n === 'rapor-urun' || n === 'rapor-istatistik' || n === 'rapor-fire') renderReports();
    if(n === 'siparis-masa') renderSiparisMasa();
    if(n === 'urunler') renderMenuOnlyBtn();
  }

  // ---- parola özeti (SHA-256, tarayıcıdan bağımsız) ----
  const SHA_K = [], SHA_H0 = [];
  (function(){ let n = 2, c = 0; while(c < 64){ let p = true; for(let i = 2; i * i <= n; i++) if(n % i === 0){ p = false; break; } if(p){ if(c < 8) SHA_H0[c] = (Math.sqrt(n) % 1 * 4294967296) | 0; SHA_K[c] = (Math.cbrt(n) % 1 * 4294967296) | 0; c++; } n++; } })();
  function sha256(str){
    const b = unescape(encodeURIComponent(str)), l = b.length, w = [];
    for(let i = 0; i < l; i++) w[i >> 2] = (w[i >> 2] | 0) | (b.charCodeAt(i) << (24 - (i % 4) * 8));
    w[l >> 2] = (w[l >> 2] | 0) | (0x80 << (24 - (l % 4) * 8));
    const nb = (((l + 8) >> 6) + 1) * 16;
    for(let i = 0; i < nb; i++) if(w[i] === undefined) w[i] = 0;
    w[nb - 1] = l * 8;
    let H = SHA_H0.slice();
    for(let j = 0; j < nb; j += 16){
      const W = w.slice(j, j + 16); let [a, b2, c, d, e, f, g, h] = H;
      for(let i = 0; i < 64; i++){
        if(i >= 16){ const x = W[i - 15], y = W[i - 2]; W[i] = (W[i - 16] + (((x >>> 7) | (x << 25)) ^ ((x >>> 18) | (x << 14)) ^ (x >>> 3)) + W[i - 7] + (((y >>> 17) | (y << 15)) ^ ((y >>> 19) | (y << 13)) ^ (y >>> 10))) | 0; }
        const t1 = (h + (((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + SHA_K[i] + W[i]) | 0;
        const t2 = ((((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10))) + ((a & b2) ^ (a & c) ^ (b2 & c))) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b2; b2 = a; a = (t1 + t2) | 0;
      }
      H = [(H[0] + a) | 0, (H[1] + b2) | 0, (H[2] + c) | 0, (H[3] + d) | 0, (H[4] + e) | 0, (H[5] + f) | 0, (H[6] + g) | 0, (H[7] + h) | 0];
    }
    return H.map(x => ('00000000' + (x >>> 0).toString(16)).slice(-8)).join('');
  }
  // personel hesabı: isim -> küçük harf, Türkçe karakterler ASCII, boşluk/noktalama yok; sürüm eki şifre değişince artar
  function normName(s){
    const m = { 'ç': 'c', 'ğ': 'g', 'ı': 'i', 'İ': 'i', 'ö': 'o', 'ş': 's', 'ü': 'u', 'Ç': 'c', 'Ğ': 'g', 'Ö': 'o', 'Ş': 's', 'Ü': 'u', 'I': 'i' };
    return String(s || '').replace(/[çğıİöşüÇĞÖŞÜI]/g, ch => m[ch]).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 40);
  }
  function endRestoring(){ document.documentElement.classList.remove('restoring'); }
  function staffEmail(n, v){ return n + (v > 1 ? '.' + v : '') + '@personel.pos'; }
  const pwHash = s => sha256('pos|' + s);
  const pinOK = pw => !!pw && !!settings.pin && (settings.pin === pwHash(pw) || settings.pin === pw);
  function askSecret(msg){
    return new Promise(res => {
      const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 1100;
      bg.innerHTML = '<div class="modal-box"><h3 style="margin:0 0 8px">' + esc(msg) + '</h3><input type="password" id="secIn" autocomplete="off" aria-label="PIN" style="width:100%;padding:10px;margin:8px 0"><div style="display:flex;gap:8px"><button class="btn-save" id="secOk" style="margin:0">Tamam</button><button class="btn-save" id="secNo" style="margin:0">Vazgeç</button></div></div>';
      document.body.appendChild(bg); const inp = bg.querySelector('#secIn'); inp.focus();
      const done = v => { bg.remove(); res(v); };
      bg.querySelector('#secOk').onclick = () => done(inp.value); bg.querySelector('#secNo').onclick = () => done(null);
      inp.onkeydown = e => { if(e.key === 'Enter') done(inp.value); if(e.key === 'Escape') done(null); };
    });
  }
  const pwTaken = (pw, exceptName) => pinOK(pw) || staffUsers.some(u => u.ad !== exceptName && ((u.h && u.h === pwHash(pw)) || (u.sifre && u.sifre === pw)));

  // ---- personel dizini: kullanıcılar Firebase'e yazılır, her cihazdan giriş yapılabilir ----
  // Kayıt anahtarı = şifre özeti (SHA-256). Liste halinde okunamaz; giriş sırasında yalnızca yazılan şifrenin kaydı sorgulanır.
  const SD = 'staffDir/';
  let dirReady = false, lastDirSig = '', dirWarned = false, supExists = false;
  const isHash = x => /^[0-9a-f]{64}$/.test(x || '');
  function buildDir(){
    const dir = {};
    staffUsers.forEach(u => { if(u.sifre && !u.h){ u.h = pwHash(u.sifre); } if(u.h) dir[u.h] = { ad: u.ad, gorev: u.gorev, bolge: u.bolge || '', tel: u.tel || '', email: u.email || '', blocked: !!u.blocked, admin: false }; });
    if(isHash(settings.pin)) dir[settings.pin] = { ad: 'Yönetici', gorev: 'Müdür', bolge: '', tel: '', email: '', blocked: false, admin: true };
    if(isHash(settings.supPin)) dir[settings.supPin] = { ad: 'Admin', gorev: 'Müdür', bolge: '', tel: '', email: '', blocked: false, admin: true, sup: true };
    return dir;
  }
  function syncStaffDir(){
    if(RT.local || !dirReady || !(curUser && curUser.admin) || (RT.isRoot && !RT.isRoot())) return;
    const dir = buildDir(), sig = JSON.stringify(dir); if(sig === lastDirSig) return;
    lastDirSig = sig;
    Promise.resolve().then(async () => {
      // bu cihazın bilmediği kademeyi (Admin veya Yönetici) Firebase'deki kayıttan koru
      const cur = await RT.get('staffDir'), vals = Object.values(dir);
      const hasSup = vals.some(e => e && e.sup), hasOwn = vals.some(e => e && e.admin && !e.sup);
      Object.keys(cur || {}).forEach(h => { const e = cur[h]; if(!e || dir[h]) return; if(e.sup && !hasSup) dir[h] = e; else if(e.admin && !e.sup && !hasOwn) dir[h] = e; });
      return RT.set('staffDir', dir);
    }).then(() => RT.set('staffMeta/ready', true)).catch(e => {
      lastDirSig = '';
      if(!dirWarned){ dirWarned = true; showToast('⚠ Personel listesi Firebase’e yazılamadı (' + ((e && e.code) || 'hata') + '). Firebase Rules ayarını kontrol edin.'); }
    });
  }
  async function pullStaffDir(){
    if(!RT.local && RT.isRoot && !RT.isRoot()){ dirReady = true; await pullStaffRoles(); return; }   // Yönetici hesabı staffDir'i okuyamaz; yalnızca personel kayıtlarını çeker
    try{
      const d = await RT.get('staffDir');
      if(d && typeof d === 'object' && Object.keys(d).length){
        staffUsers = Object.keys(d).filter(h => d[h] && !d[h].admin).map(h => ({ ad: d[h].ad, gorev: d[h].gorev, bolge: d[h].bolge || '', tel: d[h].tel || '', email: d[h].email || '', blocked: !!d[h].blocked, h })).concat(staffUsers.filter(u => u.uid));
        const adm = Object.keys(d).find(h => d[h] && d[h].admin && !d[h].sup); if(adm && (!isHash(settings.pin) || (curUser && curUser.sup))) settings.pin = adm;
        supExists = Object.keys(d).some(h => d[h] && d[h].sup);
        lastDirSig = JSON.stringify(buildDir());
      }
      dirReady = true; if(!(d && Object.keys(d).length)) syncStaffDir(); else Promise.resolve().then(() => RT.set('staffMeta/ready', true)).catch(() => {}); renderUsers(); saveState(); await pullStaffRoles();
    }catch(e){
      console.error('Personel listesi okunamadı:', e); dirReady = false;
      showToast('⚠ Personel listesi Firebase’den okunamadı (' + ((e && e.code) || 'hata') + '). Rules ayarını kontrol edin.');
    }
  }
  async function remoteStaff(pw){
    if(RT.local || !RT.get) return null;
    const h = pwHash(pw);
    try{ const r = await RT.get(SD + h); return r ? Object.assign({ h }, r) : null; }catch(e){ console.error(e); return 'err'; }
  }

  // ---- giriş / çıkış ----
  let loginFails = 0, loginLockUntil = 0, loginBusy = false;
  const LOGIN_GEN = 'İsim veya şifre hatalı.';
  async function tryLogin(){
    if(loginBusy) return;
    const now = Date.now(), err = $id('loginErr');
    if(now < loginLockUntil){ err.textContent = 'Çok fazla hatalı deneme. ' + Math.ceil((loginLockUntil - now) / 1000) + ' sn bekleyin.'; return; }
    const pw = $id('loginPass').value;
    let nm = $id('loginName') ? $id('loginName').value.trim() : '', nmN = normName(nm); const adminTry = !nmN || nmN === 'yonetici', supTry = nmN === 'admin';
    if(!pw && !((supTry || nmN === 'yonetici') && !RT.local)) return;
    loginBusy = true; err.textContent = '';
    try{
      let user = null, remoteErr = false, ownerExists = false, adminDone = false;
      if(supTry && !RT.local){
        adminDone = true; err.textContent = 'Kontrol ediliyor…';
        const r = RT.adminLogin ? await RT.adminLogin(pw.trim()) : { code: 'bad' }; err.textContent = '';
        if(r.code === 'ok') user = { ad: 'Admin', gorev: 'Müdür', admin: true, sup: true };
        else if(r.code === 'limit'){ err.textContent = 'Çok fazla deneme. Biraz bekleyin.'; return; }
        else if(r.code === 'net'){ err.textContent = 'İnternet bağlantısı yok.'; return; }
        else if(r.code === 'noadmin'){ err.textContent = 'config.js içinde adminEmail yok.'; return; }
        else if(r.code === 'off'){ err.textContent = 'Firebase\'de E-posta/Şifre girişi kapalı.'; return; }
        else if(r.code === 'cancel') return;
        else if(r.code === 'popup'){ err.textContent = 'Açılır pencere engellendi. İzin verip tekrar deneyin.'; return; }
        else if(r.code === 'goff'){ err.textContent = 'Firebase\'de Google girişi kapalı (Authentication → Sign-in method → Google).'; return; }
        else if(r.code === 'domain'){ err.textContent = 'Bu site adresi Firebase\'de yetkili değil (Authentication → Ayarlar → Yetkili alan adları).'; return; }
        else if(r.code === 'wrong'){ err.textContent = 'Bu Google hesabı Admin hesabı değil.'; return; }
        else if(!user){ err.textContent = pw ? 'Şifre hatalı. Admin şifresi belirlemediysen şifre alanını boş bırakıp giriş yap (Google ile doğrulanır).' : 'Google girişi başarısız, tekrar deneyin.'; return; }
      }
      if(!pw && nmN === 'yonetici' && !RT.local){
        adminDone = true; err.textContent = 'Kontrol ediliyor…';
        const r = RT.ownerGoogleLogin ? await RT.ownerGoogleLogin() : { code: 'err' }; err.textContent = '';
        if(r.code === 'ok'){
          user = { ad: r.role.ad, gorev: r.role.gorev, bolge: r.role.bolge || '', admin: true, owner: true, uid: r.uid };
          setTimeout(() => showToast('Giriş yapıldı. Yeni şifre için: Ayarlar → Şifremi değiştir (eski şifre alanı boş kalsın).'), 900);
        }
        else if(r.code === 'cancel') return;
        else { err.textContent = { notlinked: 'Bu Google hesabı bir Yönetici hesabına bağlı değil.', blocked: 'Bu kullanıcının girişi engellenmiş.', popup: 'Açılır pencere engellendi. İzin verip tekrar deneyin.', goff: 'Firebase\'de Google girişi kapalı.', domain: 'Bu site adresi Firebase\'de yetkili değil.', net: 'İnternet bağlantısı yok.' }[r.code] || 'Google girişi başarısız, tekrar deneyin.'; return; }
      }
      if(!RT.local){ try{ ownerExists = (await RT.get('staffVer/yonetici')) != null; }catch(e){} if(ownerExists && !nmN){ nm = 'Yönetici'; nmN = 'yonetici'; } }
      if(adminDone){ /* Admin girişi yukarıda işlendi */ }
      else if(adminTry && !ownerExists && pinOK(pw)) user = { ad: 'Yönetici', gorev: 'Müdür', admin: true };
      else if(RT.local){
        const mt = x => (!nmN || normName(x.ad) === nmN) && ((x.h && x.h === pwHash(pw)) || (x.sifre && x.sifre === pw));
        const u = staffUsers.find(x => !x.blocked && mt(x));
        if(u){ if(u.sifre){ u.h = pwHash(pw); delete u.sifre; } user = { ad: u.ad, gorev: u.gorev, bolge: u.bolge || '', admin: false, h: u.h }; }
        else if(staffUsers.some(x => x.blocked && mt(x))){ err.textContent = 'Bu kullanıcının girişi engellenmiş.'; return; }
      } else {
        let legacyOn = false; try{ legacyOn = (await RT.get('staffMeta/legacyOn')) === true; }catch(e){}
        let known = false;
        // 1) yeni yol: isim + şifre -> kişiye özel Firebase hesabı
        if(nmN && RT.staffLogin){
          err.textContent = 'Kontrol ediliyor…';
          const r = await RT.staffLogin(nm, pw.trim()); err.textContent = '';
          if(r.code === 'ok') user = { ad: r.role.ad, gorev: r.role.gorev, bolge: r.role.bolge || '', admin: r.role.owner === true, owner: r.role.owner === true, uid: r.uid };
          else if(r.code === 'blocked'){ err.textContent = 'Bu kullanıcının girişi engellenmiş.'; return; }
          else if(r.code === 'limit'){ err.textContent = 'Çok fazla deneme. Biraz bekleyin.'; return; }
          else if(r.code === 'net'){ err.textContent = 'İnternet bağlantısı yok.'; return; }
          else known = !!r.known;
        }
        // 2) eski yol (geçiş dönemi): yalnızca şifresi henüz taşınmamış kişiler ve yönetici PIN doğrulaması
        if(!user && nmN && !(ownerExists && nmN === 'yonetici') && (nmN === 'yonetici' || nmN === 'admin' || (legacyOn && !known))){
          const hh = pwHash(pw), mt = x => !x.uid && (!nmN || normName(x.ad) === nmN) && ((x.h && x.h === hh) || (x.sifre && x.sifre === pw));
          const u = legacyOn ? staffUsers.find(x => !x.blocked && mt(x)) : null;
          if(u){ if(u.sifre){ u.h = pwHash(pw); delete u.sifre; } user = { ad: u.ad, gorev: u.gorev, bolge: u.bolge || '', admin: false, h: u.h }; }
          else if(legacyOn && staffUsers.some(x => x.blocked && mt(x))){ err.textContent = 'Bu kullanıcının girişi engellenmiş.'; return; }
          if(!user){
            err.textContent = 'Kontrol ediliyor…';
            const okA = RT.staffAuth ? await RT.staffAuth(false) : false;
            if(!okA){ err.textContent = LOGIN_GEN; return; }
            const r = await remoteStaff(pw); err.textContent = '';
            if(r === 'err') remoteErr = true;
            else if(r){
              if(r.blocked){ err.textContent = 'Bu kullanıcının girişi engellenmiş.'; return; }
              if(r.admin && r.sup){ if(supTry){ settings.supPin = r.h; supExists = true; user = { ad: 'Admin', gorev: 'Müdür', admin: true, sup: true }; } }
              else if(r.admin){ if(adminTry){ settings.pin = r.h; user = { ad: 'Yönetici', gorev: 'Müdür', admin: true }; } }
              else if(legacyOn && !r.admin && (!nmN || normName(r.ad) === nmN)) user = { ad: r.ad, gorev: r.gorev, bolge: r.bolge || '', admin: false, h: r.h };
            }
          }
        }
      }
      let firstOk = !user && adminTry && !settings.pin && !remoteErr && !ownerExists && RT.local;
      if(firstOk && !RT.local){
        // dizin daha önce kurulduysa (bayrak var) yanlış şifre sayılır; ilk kurulum yalnızca bayrak yokken sunulur
        let rdy = 'err'; try{ rdy = await RT.get('staffMeta/ready'); }catch(e){}
        if(rdy !== null) firstOk = false;
      }
      if(firstOk){
        if(pw.length < 4){ err.textContent = 'İlk kurulum: en az 4 haneli bir PIN yazın.'; return; }
        if(!RT.local){
          err.textContent = 'Firebase kontrol ediliyor…';
          const okA = RT.staffAuth ? await RT.staffAuth(true) : false; err.textContent = '';
          if(!okA) return;
          let d = null; try{ d = await RT.get('staffDir'); }catch(e){ err.textContent = 'Firebase okunamadı. Rules ayarını kontrol edin.'; return; }
          if(d && Object.keys(d).length){ err.textContent = LOGIN_GEN; return; }
        }
        if(!await uiConfirm('İlk kurulum: yazdığınız şifre yönetici PIN\'i olarak kaydedilsin mi?')) return;
        settings.pin = pwHash(pw); user = { ad: 'Yönetici', gorev: 'Müdür', admin: true };
      }
      if(user && user.admin && settings.pin === pw) settings.pin = pwHash(pw);
      if(!user){
        if(remoteErr){ err.textContent = 'Sunucuya ulaşılamadı. İnterneti kontrol edin.'; return; }
        loginFails++; if(loginFails >= 5){ loginLockUntil = Date.now() + 30000; loginFails = 0; err.textContent = 'Çok fazla hatalı deneme. 30 sn bekleyin.'; }
        else err.textContent = LOGIN_GEN;
        return;
      }
      loginFails = 0; curUser = user; sessionStorage.setItem('posUser', JSON.stringify(user)); sessionStorage.removeItem('posScreen');
      $id('loginModal').classList.remove('show'); $id('loginPass').value = ''; if($id('loginName')) $id('loginName').value = ''; enterStaff(); saveState();
    } finally { loginBusy = false; }
  }
  // kişiye özel hesapla girenin kaydı silinir/engellenirse oturum anında kapanır
  function watchRole(){
    if(!curUser || !curUser.uid || RT.local) return;
    RT.on('staffRoles/' + curUser.uid, v => {
      if(!v || v.blocked === true || (curUser && curUser.owner && v.owner !== true)){ try{ RT.staffLogout && RT.staffLogout(); }catch(e){} sessionStorage.removeItem('posUser'); showToast('Erişiminiz kapatıldı.'); setTimeout(() => location.reload(), 800); }
      else if(curUser){ curUser.gorev = v.gorev; curUser.bolge = v.bolge || ''; }
    });
  }
  async function restoreSession(){
    try{
      const u = JSON.parse(sessionStorage.getItem('posUser') || 'null'); if(!u) return;
      if(u.sup && !RT.local && !(RT.isRoot && RT.isRoot())){ sessionStorage.removeItem('posUser'); return; }
      if(!u.admin || u.owner){
        if(u.uid){
          if(RT.local || !RT.uid || RT.uid() !== u.uid){ sessionStorage.removeItem('posUser'); return; }
          let r = null; try{ r = await RT.get('staffRoles/' + u.uid); }catch(e){}
          if(!r || r.blocked === true){ sessionStorage.removeItem('posUser'); try{ RT.staffLogout && RT.staffLogout(); }catch(e){} return; }
          u.ad = r.ad; u.gorev = r.gorev; u.bolge = r.bolge || '';
          if(u.owner){ if(r.owner !== true){ sessionStorage.removeItem('posUser'); try{ RT.staffLogout && RT.staffLogout(); }catch(e){} return; } RT.setOwner && RT.setOwner(u.uid); }
        } else {
          const rec = staffUsers.find(x => x.ad === u.ad || (u.h && x.h === u.h));
          if(rec){ if(rec.blocked){ sessionStorage.removeItem('posUser'); return; } u.gorev = rec.gorev; u.bolge = rec.bolge || ''; }
          else if(!RT.local && u.h){
            const r = await remoteStaff0(u.h);
            if(!r || r.blocked){ sessionStorage.removeItem('posUser'); return; }
            u.gorev = r.gorev; u.bolge = r.bolge || '';
          } else { sessionStorage.removeItem('posUser'); return; }
        }
      }
      curUser = u; enterStaff();
    }catch(e){ console.error(e); }
    finally{ if(!curUser) endRestoring(); }
  }
  async function remoteStaff0(h){ try{ return await RT.get(SD + h); }catch(e){ return null; } }

  // ---- gizli giriş: logoya 4 kez dokun ----
  let logoTaps = 0, logoTimer = 0;
  function onLogoTap(){
    logoTaps++; clearTimeout(logoTimer); logoTimer = setTimeout(() => { logoTaps = 0; }, 2500);
    if(logoTaps >= 4){ logoTaps = 0; $id('loginErr').textContent = ''; $id('loginPass').value = ''; $id('loginName').value = ''; $id('loginModal').classList.add('show'); setTimeout(() => $id('loginName').focus(), 50); }
  }
  $id('cLogo').addEventListener('click', onLogoTap);
  function renderMenuOnlyBtn(){ const b = $id('btnMenuOnly'); if(!b) return; const on = !!settings.menuOnly; b.classList.toggle('on', on); b.setAttribute('aria-checked', on); const st = $id('moState'); if(st) st.textContent = on ? 'AKTİF — QR menü yalnızca görüntüleme: sepet, sipariş ve masa seçimi yok.' : 'Kapalı — müşteriler QR menüden sipariş verebilir.'; }
  $id('btnMenuOnly').addEventListener('click', () => {
    if(!can('menu') && !can('settings')){ showToast('Yetkiniz yok.'); return; }
    settings.menuOnly = !settings.menuOnly; renderMenuOnlyBtn(); publishPublic(); saveState();
    showToast(settings.menuOnly ? 'Sadece menü modu AKTİF: müşteri sipariş veremez.' : 'Müşteri siparişi açıldı.');
  });

  // ---- logo ----
  let _lg = 0;
  function emblem(){
    const k = 'lg' + (++_lg), st = (d, t) => `<path d="${d}" pathLength="1" fill="none" stroke="#fff3d6" stroke-width="2.6" stroke-linecap="round" stroke-dasharray=".5 .5" opacity="0" filter="url(#${k}b)"><animate attributeName="stroke-dashoffset" from="1" to="0" dur="3.2s" begin="${t}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;.95;0" dur="3.2s" begin="${t}s" repeatCount="indefinite"/></path>`;
    return `<defs>
<linearGradient id="${k}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff3c4"/><stop offset=".25" stop-color="#e9bd5b"/><stop offset=".55" stop-color="#9c6b20"/><stop offset=".8" stop-color="#f3d27f"/><stop offset="1" stop-color="#b98a35"/></linearGradient>
<radialGradient id="${k}d" cx=".35" cy=".28" r=".85"><stop offset="0" stop-color="#6b4630"/><stop offset=".55" stop-color="#2d1a10"/><stop offset="1" stop-color="#150a05"/></radialGradient>
<linearGradient id="${k}c" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#d8c3a2"/><stop offset=".35" stop-color="#fffaf0"/><stop offset=".75" stop-color="#e6d3b5"/><stop offset="1" stop-color="#b79e78"/></linearGradient>
<linearGradient id="${k}h" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".5"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
<linearGradient id="${k}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".7"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
<clipPath id="${k}p"><circle cx="60" cy="60" r="54"/></clipPath>
<filter id="${k}f" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="3" stdDeviation="3" flood-color="#000" flood-opacity=".35"/></filter>
<filter id="${k}b"><feGaussianBlur stdDeviation="1.1"/></filter></defs>
<circle cx="60" cy="60" r="54" fill="none" stroke="#e9bd5b" stroke-width="1.5" opacity="0"><animate attributeName="r" values="54;66" dur="3s" repeatCount="indefinite"/><animate attributeName="opacity" values=".7;0" dur="3s" repeatCount="indefinite"/></circle>
<g filter="url(#${k}f)"><circle cx="60" cy="60" r="54" fill="url(#${k}g)"/></g>
<circle cx="60" cy="60" r="47.5" fill="url(#${k}d)"/><circle cx="60" cy="60" r="47.5" fill="none" stroke="#fff3c4" stroke-opacity=".35"/>
<ellipse cx="60" cy="93" rx="27" ry="5" fill="url(#${k}c)"/><path d="M38 64h44v7a22 21 0 0 1-44 0z" fill="url(#${k}c)"/>
<path d="M82 68h3.5a6.5 6.5 0 0 1 0 13H78" fill="none" stroke="url(#${k}c)" stroke-width="4" stroke-linecap="round"/>
<ellipse cx="60" cy="64" rx="22" ry="5" fill="#3a2113"/><ellipse cx="55" cy="63" rx="9" ry="1.6" fill="#8a5a38" opacity=".7"/>
${st('M50 58c-5-6 5-10 0-17', 0)}${st('M60 56c-5-7 5-11 0-19', 1.05)}${st('M70 58c-5-6 5-10 0-17', 2.1)}
<g clip-path="url(#${k}p)"><path d="M10 40Q60 -10 110 40Q60 22 10 40z" fill="url(#${k}h)"/><g transform="rotate(20 60 60)"><rect x="-40" y="-20" width="20" height="160" fill="url(#${k}s)"><animate attributeName="x" values="-40;150;150" keyTimes="0;.3;1" dur="5.5s" repeatCount="indefinite"/></rect></g></g>`;
  }
  // ---- sosyal medya + Wi-Fi (müşteri başlığı) — Ayarlar'dan açılıp kapatılır ----
  const SOC = [
    { k: 'instagram', t: 'Instagram', ph: 'kullanıcı adı', mk: u => 'https://www.instagram.com/' + u, i: '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle class="fl" cx="17.3" cy="6.7" r="1.1"/></svg>' },
    { k: 'tiktok', t: 'TikTok', ph: 'kullanıcı adı', mk: u => 'https://www.tiktok.com/@' + u, i: '<svg viewBox="0 0 24 24"><path d="M14 3v11.2a3.6 3.6 0 1 1-3.6-3.6"/><path d="M14 3c.3 2.6 2 4.4 4.8 4.6"/></svg>' },
    { k: 'facebook', t: 'Facebook', ph: 'sayfa adı', mk: u => 'https://www.facebook.com/' + u, i: '<svg viewBox="0 0 24 24"><path d="M15 3h-2.5A4.5 4.5 0 0 0 8 7.5V10H5v4h3v7h4v-7h3l1-4h-4V7.5c0-.3.2-.5.5-.5H15z"/></svg>' },
    { k: 'x', t: 'X (Twitter)', ph: 'kullanıcı adı', mk: u => 'https://x.com/' + u, i: '<svg viewBox="0 0 24 24"><path d="M4 4l16 16M20 4L4 20"/></svg>' },
    { k: 'youtube', t: 'YouTube', ph: 'kanal adı', mk: u => 'https://www.youtube.com/@' + u, i: '<svg viewBox="0 0 24 24"><rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path class="fl" d="M10 9.5v5l4.5-2.5z"/></svg>' },
    { k: 'whatsapp', t: 'WhatsApp', ph: 'telefon (905xxxxxxxxx)', mk: u => 'https://wa.me/' + u, i: '<svg viewBox="0 0 24 24"><path d="M3.5 20.5l1.3-4.2A8.5 8.5 0 1 1 8 19.3z"/><path d="M9 9c0 3 3 6 6 6l1-1.5-2-1-1 .7c-1-.4-1.8-1.2-2.2-2.2l.7-1-1-2z"/></svg>' },
    { k: 'maps', t: 'Konum (Harita)', ph: 'Google Haritalar bağlantısı veya adres', mk: u => 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(u), i: '<svg viewBox="0 0 24 24"><path d="M12 21s-6.5-6.2-6.5-11a6.5 6.5 0 0 1 13 0c0 4.8-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.4"/></svg>' },
    { k: 'web', t: 'Web sitesi', ph: 'www.siteniz.com', mk: u => 'https://' + u, i: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/></svg>' }
  ];
  const socDef = k => SOC.find(d => d.k === k) || {};
  function socUrl(d, v){
    v = String(v || '').trim(); if(!v) return '';
    if(/^https?:\/\//i.test(v)) return v;
    if(d.k === 'whatsapp'){ let n = v.replace(/\D/g, ''); if(n.slice(0, 2) === '00') n = n.slice(2); else if(/^0\d{10}$/.test(n)) n = '90' + n.slice(1); else if(/^5\d{9}$/.test(n)) n = '90' + n; return n ? d.mk(n) : ''; }
    if(d.k === 'maps') return d.mk(v);
    if(d.k === 'web') return d.mk(v.replace(/^\/+/, ''));
    const u = v.replace(/^@+/, '').replace(/[^\w.\-]/g, ''); return u ? d.mk(u) : '';
  }
  function socialList(){ const st = settings.social || {}; return SOC.map(d => { const x = st[d.k] || {}; return (x.on && x.v) ? { k: d.k, t: d.t, u: socUrl(d, x.v) } : null; }).filter(x => x && x.u); }
  function pubSocial(){ const pd = getPub(); return pd ? arr(pd.social) : socialList(); }
  function wifiInfo(){ const pd = getPub(), src = pd || settings, on = pd ? pd.wifiOn !== false : settings.wifiOn !== false; return { on: on && !!src.wifiPass, pw: src.wifiPass || '', nm: src.wifiName || '' }; }
  const escA = x => String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  function renderSocial(){
    const el = $id('cSocial'); if(!el) return;
    let h = pubSocial().filter(x => x && /^https?:\/\//i.test(x.u || '')).map(x => '<a href="' + escA(x.u) + '" target="_blank" rel="noopener noreferrer" aria-label="' + escA(x.t) + '" title="' + escA(x.t) + '">' + (socDef(x.k).i || '') + '</a>').join('');
    if(wifiInfo().on) h += '<button type="button" id="cWifi" aria-label="Wi-Fi" title="Wi-Fi"><svg viewBox="0 0 24 24"><path d="M2.5 9a14 14 0 0 1 19 0"/><path d="M5.8 12.6a9.3 9.3 0 0 1 12.4 0"/><path d="M9 16a4.6 4.6 0 0 1 6 0"/><circle class="fl" cx="12" cy="19.2" r="1.3"/></svg></button>';
    el.innerHTML = h; const b = $id('cWifi'); if(b) b.addEventListener('click', showWifiCard);
  }
  function copyText(pw, done, fail){
    const fb = () => { const ta = document.createElement('textarea'); ta.value = pw; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); let ok = false; try{ ok = document.execCommand('copy'); }catch(e){} ta.remove(); ok ? done() : fail(); };
    if(navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(pw).then(done, fb); else fb();
  }
  function showWifiCard(){
    const w = wifiInfo(); if(!w.on) return;
    const bg = document.createElement('div'); bg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:3000;display:flex;align-items:center;justify-content:center;padding:20px';
    const box = document.createElement('div'); box.setAttribute('role', 'dialog'); box.style.cssText = 'background:var(--panel,#fff);color:var(--ink,#26221f);border-radius:18px;padding:22px;max-width:340px;width:100%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.35)';
    box.innerHTML = '<div style="font-size:30px">📶</div><div style="font-weight:700;font-size:17px;margin:6px 0 2px">Wi-Fi</div>' + (w.nm ? '<div style="color:var(--ink-dim,#6b6560);font-size:14px">' + escA(w.nm) + '</div>' : '') +
      '<div style="margin:14px 0;padding:12px;border:1px dashed var(--line,#ddd);border-radius:12px;font:600 20px/1.3 monospace;letter-spacing:.5px;word-break:break-all;user-select:all">' + escA(w.pw) + '</div>' +
      '<button type="button" id="wfCopy" style="width:100%;padding:12px;border:0;border-radius:12px;background:' + (getComputedStyle($id('customerView')).getPropertyValue('--red').trim() || '#cf2e2e') + ';color:#fff;font:600 15px inherit;cursor:pointer">Şifreyi kopyala</button>' +
      '<button type="button" id="wfClose" style="width:100%;padding:10px;margin-top:8px;border:0;background:transparent;color:var(--ink-dim,#6b6560);font:inherit;cursor:pointer">Kapat</button>';
    bg.appendChild(box); document.body.appendChild(bg);
    const close = () => bg.remove(); bg.addEventListener('click', e => { if(e.target === bg) close(); }); box.querySelector('#wfClose').addEventListener('click', close);
    const cb = box.querySelector('#wfCopy');
    cb.addEventListener('click', () => copyText(w.pw, () => { cb.textContent = '✓ Kopyalandı'; setTimeout(() => { cb.textContent = 'Şifreyi kopyala'; }, 2500); }, () => { cb.textContent = 'Şifreyi seçip kopyalayın'; }));
  }
  // ---- Ayarlar ekranı: sosyal medya / Wi-Fi anahtarları ----
  function applySocialUI(){
    const box = $id('socRows'); if(!box) return; const st = settings.social || {};
    box.querySelectorAll('[data-soc-v]').forEach(inp => { if(document.activeElement !== inp) inp.value = (st[inp.dataset.socV] || {}).v || ''; });
    box.querySelectorAll('[data-soc-t]').forEach(t => { const on = !!(st[t.dataset.socT] || {}).on; t.classList.toggle('on', on); t.classList.toggle('off', !on); t.setAttribute('aria-checked', on); });
    const w = $id('wifiOnTgl'); if(w){ const on = settings.wifiOn !== false; w.classList.toggle('on', on); w.classList.toggle('off', !on); w.setAttribute('aria-checked', on); }
  }
  (function(){
    const flip = t => { const on = !t.classList.contains('on'); t.classList.toggle('on', on); t.classList.toggle('off', !on); t.setAttribute('aria-checked', on); };
    const box = $id('socRows'); if(box) box.addEventListener('click', e => { const t = e.target.closest('[data-soc-t]'); if(t) flip(t); });
    const w = $id('wifiOnTgl'); if(w) w.addEventListener('click', () => flip(w));
    const save = msg => () => { readSettings(); saveState(); showToast(msg); };
    const b1 = $id('btnWifiSave'), b2 = $id('btnSocSave');
    if(b1) b1.addEventListener('click', save('Wi-Fi güncellendi.')); if(b2) b2.addEventListener('click', save('Sosyal medya güncellendi.'));
  })();
  // ---- marka: renk yardımcıları ----
  const hxC = c => { c = String(c || '').replace('#', ''); if(c.length === 3) c = c.split('').map(x => x + x).join(''); return [0, 2, 4].map(i => parseInt(c.substr(i, 2), 16) || 0); };
  const toHexC = a => '#' + a.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
  const mixC = (a, b, t) => { const x = hxC(a), y = hxC(b); return toHexC(x.map((v, i) => v + (y[i] - v) * t)); };
  const lumC = c => { const [r, g, b] = hxC(c); return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255; };
  const distC = (a, b) => { const x = hxC(a), y = hxC(b); return Math.sqrt(x.reduce((s, v, i) => s + (v - y[i]) * (v - y[i]), 0)); };
  const isHexC = c => /^#[0-9a-f]{6}$/i.test(String(c || ''));
  const accentFix = a => { let c = a, n = 0; while(lumC(c) > .5 && n++ < 8) c = mixC(c, '#000000', .15); return c; };
  const BR_FONTS = [
    { k: 'auto', t: 'Zarif (varsayılan)', f: 'Cormorant Garamond,Playfair Display,Georgia,serif', f2: 'Montserrat,Helvetica Neue,Arial,sans-serif', up: 1 },
    { k: 'playfair', t: 'Klasik serif (Playfair)', f: 'Playfair Display,Georgia,serif', f2: 'Montserrat,Arial,sans-serif', up: 1 },
    { k: 'cinzel', t: 'Roma harfleri (Cinzel)', f: 'Cinzel,Georgia,serif', f2: 'Cinzel,Georgia,serif', up: 1 },
    { k: 'montserrat', t: 'Modern (Montserrat)', f: 'Montserrat,Helvetica Neue,Arial,sans-serif', f2: 'Montserrat,Arial,sans-serif', up: 1 },
    { k: 'poppins', t: 'Yuvarlak modern (Poppins)', f: 'Poppins,Arial,sans-serif', f2: 'Poppins,Arial,sans-serif', up: 1 },
    { k: 'oswald', t: 'İnce uzun (Oswald)', f: 'Oswald,Arial Narrow,sans-serif', f2: 'Oswald,Arial Narrow,sans-serif', up: 1 },
    { k: 'pacifico', t: 'El yazısı (Pacifico)', f: 'Pacifico,cursive', f2: 'Pacifico,cursive', up: 0 },
    { k: 'lobster', t: 'El yazısı (Lobster)', f: 'Lobster,cursive', f2: 'Lobster,cursive', up: 0 },
    { k: 'dancing', t: 'İmza (Dancing Script)', f: 'Dancing Script,cursive', f2: 'Dancing Script,cursive', up: 0 }
  ];
  const RINGS = '<circle cx="70" cy="70" r="60" fill="none" stroke="url(#lgR)" stroke-width="2.2"/><circle cx="70" cy="70" r="51" fill="none" stroke="url(#lgR)" stroke-width="1.4" stroke-dasharray="1.5 6" stroke-linecap="round" opacity=".75"/>';
  const CUP_EMBLEM = RINGS + '<path d="M70 14l2.6 6.6 6.6 2.6-6.6 2.6L70 32.4l-2.6-6.6-6.6-2.6 6.6-2.6z" fill="url(#lgR)"/><path d="M50 66h40v9a20 20 0 0 1-40 0z" fill="url(#lgR)"/><path d="M90 70h4a7 7 0 0 1 0 14h-5" fill="none" stroke="url(#lgR)" stroke-width="4" stroke-linecap="round"/><path d="M44 102h52" stroke="url(#lgR)" stroke-width="4" stroke-linecap="round"/><path d="M60 58q-4-5 0-10M70 58q-4-5 0-10M80 58q-4-5 0-10" fill="none" stroke="url(#lgR)" stroke-width="2.6" stroke-linecap="round"/>';
  const BR_DEF = { mode: 'text', l1: '', l2: '', font: 'auto', w: '700', 'case': 'auto', cstyle: 'auto', color: '#d9a441', color2: '#8a5a12', spread: true, rule: true, align: 'start', emblem: 'auto', imgScale: 100, shape: 'none', bg: 'none', bgColor: '#ffffff', iconBg: '#0F1A2C', accentAuto: true, accent: '#cf2e2e' };
  const getPub = () => { try{ return pubData; }catch(e){ return null; } };
  const getStaff = () => { try{ return staffMode; }catch(e){ return false; } };
  const IMG_OK = /^data:image\/(png|webp|jpeg|gif);base64,[A-Za-z0-9+\/=]+$/;
  // etkin marka: Ayarlar'da kaydedilmişse o, yoksa config.js
  function brandEff(ov){
    const cfg = (window.APP_CONFIG && APP_CONFIG.brand) || {}, pd = getPub();
    const o = ov || ((getStaff() && settings.brand) ? settings.brand : (pd && pd.brand) ? pd.brand : settings.brand) || null;
    const r = { name: cfg.name || '', cfgEmblem: cfg.emblem || '', custom: !!o, mode: 'text', l1: cfg.line1 || cfg.name || '', l2: cfg.line2 || '', font: 'auto', w: '700', 'case': 'auto', cstyle: 'auto', align: 'start', emblem: 'auto', shape: 'none', bg: 'none', bgColor: '#ffffff', iconBg: '#0F1A2C', color: null, color2: null, spread: null, rule: true, imgScale: 100, img: '', emblemImg: '', ac: null, pal: [] };
    if(o){
      r.mode = o.mode === 'img' ? 'img' : 'text';
      if(o.l1 != null && String(o.l1).trim() !== ''){ r.l1 = String(o.l1); r.l2 = String(o.l2 || ''); }
      ['font', 'w', 'case', 'cstyle', 'align', 'emblem', 'shape', 'bg'].forEach(k => { if(o[k]) r[k] = String(o[k]); });
      ['color', 'color2', 'bgColor', 'iconBg'].forEach(k => { if(isHexC(o[k])) r[k] = o[k]; });
      if(o.spread != null) r.spread = !!o.spread; if(o.rule != null) r.rule = !!o.rule;
      if(o.imgScale) r.imgScale = Math.max(40, Math.min(100, +o.imgScale || 100));
      if(o.img && IMG_OK.test(o.img)) r.img = o.img; if(o.emblemImg && IMG_OK.test(o.emblemImg)) r.emblemImg = o.emblemImg;
      r.pal = Array.isArray(o.pal) ? o.pal.filter(isHexC).slice(0, 6) : [];
      r.ac = o.accentAuto === false ? (isHexC(o.accent) ? o.accent : null) : (r.mode === 'img' ? (isHexC(o.ac) ? o.ac : null) : r.color);
      if(r.mode === 'img' && !r.img) r.mode = 'text';
    }
    return r;
  }
  function applyAccent(){
    const cv = $id('customerView'); if(!cv) return; const a = brandEff().ac;
    if(a){ const c = accentFix(a); cv.style.setProperty('--red', c); cv.style.setProperty('--red-dark', mixC(c, '#000000', .2)); cv.style.setProperty('--soc-b1', mixC(c, '#000000', .5)); cv.style.setProperty('--soc-b2', mixC(c, '#000000', .72)); cv.style.setProperty('--soc-ic', mixC(c, '#ffffff', .62)); cv.style.setProperty('--soc-bd', mixC(c, '#ffffff', .4)); }
    else ['--red', '--red-dark', '--soc-b1', '--soc-b2', '--soc-ic', '--soc-bd'].forEach(k => cv.style.removeProperty(k));
  }
  // ---- işletmeye özel logo: config.js içinde APP_CONFIG.brand.logo = { full: '<svg…>', mark: '<svg…>' } verilmişse o kullanılır ----
  const cfgLogo = (b, ov, mode) => { if(ov || b.custom) return ''; const L = (window.APP_CONFIG && APP_CONFIG.brand && APP_CONFIG.brand.logo) || null, s = L && (mode === 'mark' ? L.mark : L.full); return (typeof s === 'string' && /^<svg[\s>]/.test(s)) ? s : ''; };
  function logoSVG(mode, ov){
    const b = brandEff(ov), ea = x => String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const cl = cfgLogo(b, ov, mode); if(cl) return cl;
    const fx = BR_FONTS.find(f => f.k === b.font) || BR_FONTS[0], lab = ea(b.name || b.l1), c1 = b.color || '#d9a441';
    const st = b.cstyle === 'solid' ? [c1, c1, c1] : b.cstyle === 'two' ? [c1, mixC(c1, b.color2 || '#8a5a12', .5), b.color2 || '#8a5a12'] : (b.color ? [mixC(c1, '#ffffff', .38), c1, mixC(c1, '#000000', .3)] : ['#f4d98c', '#d9a441', '#b57d1e']);
    const D = '<linearGradient id="lgR" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="140"><stop offset="0" stop-color="' + st[0] + '"/><stop offset=".55" stop-color="' + st[1] + '"/><stop offset="1" stop-color="' + st[2] + '"/></linearGradient>';
    const bgc = b.bg === 'white' ? '#ffffff' : b.bg === 'dark' ? '#0F1A2C' : b.bg === 'custom' ? b.bgColor : '';
    const X = '<svg xmlns="http://www.w3.org/2000/svg" ';
    if(b.mode === 'img'){
      if(mode === 'mark') return X + 'viewBox="0 0 100 100" role="img" aria-label="' + lab + '"><rect width="100" height="100" rx="24" fill="' + (bgc || '#ffffff') + '"/><image href="' + b.img + '" x="10" y="10" width="80" height="80" preserveAspectRatio="xMidYMid meet"/></svg>';
      const s = b.imgScale / 100, bw = 410 * s, bh = 140 * s, bx = (410 - bw) / 2, by = (140 - bh) / 2, pad = bgc ? 8 * s : 0; let defs = '', body = '';
      if(b.shape === 'circle'){ const r = 70 * s; defs = '<clipPath id="lgC"><circle cx="205" cy="70" r="' + r + '"/></clipPath>'; body = (bgc ? '<circle cx="205" cy="70" r="' + r + '" fill="' + bgc + '"/>' : '') + '<image href="' + b.img + '" x="' + (205 - r) + '" y="' + (70 - r) + '" width="' + 2 * r + '" height="' + 2 * r + '" clip-path="url(#lgC)" preserveAspectRatio="xMidYMid slice"/>'; }
      else { const rx = b.shape === 'round' ? 18 * s : 0; defs = '<clipPath id="lgC"><rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + bh + '" rx="' + rx + '"/></clipPath>'; body = (bgc ? '<rect x="' + bx + '" y="' + by + '" width="' + bw + '" height="' + bh + '" rx="' + rx + '" fill="' + bgc + '"/>' : '') + '<image href="' + b.img + '" x="' + (bx + pad) + '" y="' + (by + pad) + '" width="' + (bw - 2 * pad) + '" height="' + (bh - 2 * pad) + '" clip-path="url(#lgC)" preserveAspectRatio="xMidYMid meet"/>'; }
      return X + 'viewBox="0 0 410 140" role="img" aria-label="' + lab + '"><defs>' + defs + '</defs>' + body + '</svg>';
    }
    const cs = b.case === 'auto' ? (fx.up ? 'upper' : 'none') : b.case, tr = t => { t = String(t); return cs === 'upper' ? t.toLocaleUpperCase('tr-TR') : cs === 'lower' ? t.toLocaleLowerCase('tr-TR') : cs === 'title' ? t.toLocaleLowerCase('tr-TR').replace(/(^|\s)(\S)/g, (m, a, c) => a + c.toLocaleUpperCase('tr-TR')) : t; };
    const l1 = tr(b.l1), l2 = tr(b.l2), init = ea(String(b.l1).charAt(0).toLocaleUpperCase('tr-TR')), hasE = b.emblem !== 'none';
    let E = '';
    if(b.emblem === 'cup') E = CUP_EMBLEM;
    else if(b.emblem === 'letter') E = RINGS + '<text x="70" y="92" text-anchor="middle" font-family="' + fx.f + '" font-size="66" font-weight="700" fill="url(#lgR)">' + init + '</text>';
    else if(b.emblem === 'img' && b.emblemImg) E = RINGS + '<clipPath id="lgCe"><circle cx="70" cy="70" r="46"/></clipPath><image href="' + b.emblemImg + '" x="24" y="24" width="92" height="92" clip-path="url(#lgCe)" preserveAspectRatio="xMidYMid slice"/>';
    else E = b.cfgEmblem || CUP_EMBLEM;
    if(mode === 'mark'){
      const inner = hasE ? '<g transform="translate(50 50) scale(.62) translate(-70 -70)">' + E + '</g>' : '<text x="50" y="68" text-anchor="middle" font-family="' + fx.f + '" font-size="54" font-weight="700" fill="url(#lgR)">' + init + '</text>';
      return X + 'viewBox="0 0 100 100" role="img" aria-label="' + lab + '"><rect width="100" height="100" rx="24" fill="' + b.iconBg + '"/><defs>' + D + '</defs>' + inner + '</svg>';
    }
    const mid = !hasE && b.align === 'middle', vw = hasE ? 410 : 252, x0 = hasE ? 164 : (mid ? 126 : 10), W = 232, stretch = b.spread == null ? !!fx.up : b.spread, an = mid ? ' text-anchor="middle"' : '';
    const f1 = Math.max(26, Math.min(66, Math.floor(W / Math.max(l1.length, 1) / (fx.up ? .8 : .52)))), tl1 = (stretch && l1.length <= 6) ? ' textLength="' + W + '" lengthAdjust="spacing"' : '';
    const f2 = Math.max(12, Math.min(fx.up ? 21 : 30, Math.floor(W / Math.max(l2.length, 1) / (fx.up ? .95 : .52)))), tl2 = (stretch && l2.length <= 6) ? ' textLength="' + W + '" lengthAdjust="spacing"' : '';
    let t = '<text x="' + x0 + '" y="' + (l2 ? 84 : 92) + '"' + an + ' font-family="' + fx.f + '" font-size="' + f1 + '" font-weight="' + b.w + '"' + tl1 + ' fill="url(#lgR)">' + ea(l1) + '</text>';
    if(l2){ if(b.rule) t += '<path d="M' + (mid ? x0 - W / 2 : x0) + ' 97h' + W + '" stroke="url(#lgR)" stroke-width="1.2" opacity=".6"/>'; t += '<text x="' + x0 + '" y="124"' + an + ' font-family="' + fx.f2 + '" font-size="' + f2 + '" font-weight="500"' + tl2 + ' fill="url(#lgR)">' + ea(l2) + '</text>'; }
    return X + 'viewBox="0 0 ' + vw + ' 140" role="img" aria-label="' + lab + '"><defs>' + D + '</defs>' + (hasE ? E : '') + t + '</svg>';
  }
  // ---- Ayarlar > Marka & Logo ----
  const BRC = [['mode', 'brMode', 's'], ['l1', 'brL1', 's'], ['l2', 'brL2', 's'], ['font', 'brFont', 's'], ['w', 'brW', 's'], ['case', 'brCase', 's'], ['cstyle', 'brCStyle', 's'], ['color', 'brColor', 's'], ['color2', 'brColor2', 's'], ['spread', 'brSpread', 'b'], ['rule', 'brRule', 'b'], ['align', 'brAlign', 's'], ['emblem', 'brEmblem', 's'], ['imgScale', 'brScale', 'n'], ['shape', 'brShape', 's'], ['bg', 'brBg', 's'], ['bgColor', 'brBgColor', 's'], ['iconBg', 'brIconBg', 's'], ['accentAuto', 'brAccAuto', 'b'], ['accent', 'brAccent', 's']];
  const BR_PRESETS = [
    { t: '✨ Altın klasik', v: { mode: 'text', font: 'auto', w: '700', cstyle: 'auto', color: '#d9a441', emblem: 'auto', spread: true, rule: true, iconBg: '#0F1A2C', accentAuto: true } },
    { t: '⚫ Siyah modern', v: { mode: 'text', font: 'montserrat', w: '700', cstyle: 'solid', color: '#1a1a1a', emblem: 'none', align: 'start', spread: true, rule: true, iconBg: '#ffffff', accentAuto: true } },
    { t: '🌿 Doğal yeşil', v: { mode: 'text', font: 'playfair', w: '700', cstyle: 'auto', color: '#2f7d4f', emblem: 'cup', spread: true, rule: true, iconBg: '#f3f7f1', accentAuto: true } },
    { t: '🔥 Canlı kırmızı', v: { mode: 'text', font: 'poppins', w: '700', cstyle: 'solid', color: '#d62828', emblem: 'cup', spread: true, rule: true, iconBg: '#ffffff', accentAuto: true } },
    { t: '🌊 Okyanus mavisi', v: { mode: 'text', font: 'cinzel', w: '700', cstyle: 'two', color: '#2a8fd6', color2: '#0b3c5d', emblem: 'letter', spread: true, rule: true, iconBg: '#0b2239', accentAuto: true } },
    { t: '✍️ El yazısı', v: { mode: 'text', font: 'pacifico', w: '500', 'case': 'none', cstyle: 'solid', color: '#c2185b', emblem: 'none', align: 'middle', spread: false, rule: false, iconBg: '#fff0f5', accentAuto: true } }
  ];
  let brandDirty = false, brImg = { data: '', ac: '', pal: [] }, brEmb = '';
  const setT = (id, on) => { const t = $id(id); if(!t) return; t.classList.toggle('on', !!on); t.classList.toggle('off', !on); t.setAttribute('aria-checked', !!on); };
  function brandDraft(){
    const d = {}; BRC.forEach(([k, id, t]) => { const el = $id(id); if(!el) return; d[k] = t === 'b' ? el.classList.contains('on') : t === 'n' ? (+el.value || 100) : el.value; });
    d.l1 = String(d.l1 || '').trim(); d.l2 = String(d.l2 || '').trim(); d.img = brImg.data; d.ac = brImg.ac; d.pal = brImg.pal; d.emblemImg = brEmb; return d;
  }
  function readBrand(){ if(!brandDirty || !$id('brMode')) return; settings.brand = brandDraft(); }
  function brandPreview(){
    const L = $id('brPrevL'); if(!L) return; const d = brandDraft(), e = brandEff(d), sv = logoSVG('full', d), sm = logoSVG('mark', d), u = (x, k) => x.replace(/lgR|lgC/g, m => m + k), show = (id, on) => { const el = $id(id); if(el) el.style.display = on ? '' : 'none'; };
    L.innerHTML = u(sv, 'pl'); $id('brPrevD').innerHTML = u(sv, 'pd'); $id('brPrevI').innerHTML = u(sm, 'pi');
    const ac = e.ac ? accentFix(e.ac) : '#cf2e2e'; $id('brPrevBtn').style.background = ac; $id('brPrevBtn').style.color = lumC(ac) > .6 ? '#111' : '#fff';
    $id('brAccSw').innerHTML = e.ac ? 'Menü rengi: <b style="display:inline-block;width:14px;height:14px;border-radius:50%;vertical-align:-2px;background:' + ac + '"></b> ' + ac : 'Menü rengi: varsayılan';
    const img = d.mode === 'img'; show('brTextBox', !img); show('brImgBox', img); show('brColor2Row', d.cstyle === 'two'); show('brEmbImgRow', d.emblem === 'img'); show('brBgColorRow', d.bg === 'custom'); show('brAccRow', !d.accentAuto); show('brAlignRow', d.emblem === 'none');
    const pal = brImg.pal || []; $id('brPal').innerHTML = pal.map(c => '<button type="button" class="brChip" data-c="' + c + '" title="' + c + '" style="background:' + c + '"></button>').join('') + (pal.length ? '<span style="font-size:.78rem;color:var(--ink-faint)">logodaki renkler — dokunup menü rengi yap</span>' : '');
  }
  function fillBrand(o){
    BRC.forEach(([k, id, t]) => { if(o[k] == null) return; const el = $id(id); if(!el) return; if(t === 'b') setT(id, !!o[k]); else el.value = o[k]; });
    if(o.img !== undefined) brImg = { data: IMG_OK.test(o.img || '') ? o.img : '', ac: isHexC(o.ac) ? o.ac : '', pal: Array.isArray(o.pal) ? o.pal.filter(isHexC).slice(0, 6) : [] };
    if(o.emblemImg !== undefined) brEmb = IMG_OK.test(o.emblemImg || '') ? o.emblemImg : '';
    $id('brImgInfo').textContent = brImg.data ? '✓ Görsel yüklendi' : 'Henüz görsel yüklenmedi'; $id('brEmbInfo').textContent = brEmb ? '✓ Simge görseli yüklendi' : 'Henüz simge görseli yok'; brandPreview();
  }
  function applyBrandUI(force){
    if(!$id('brMode') || (brandDirty && !force)) return; const cfg = (window.APP_CONFIG && APP_CONFIG.brand) || {}, o = settings.brand || {};
    const d = Object.assign({}, BR_DEF, { l1: cfg.line1 || '', l2: cfg.line2 || '' }); BRC.forEach(([k]) => { if(o[k] != null) d[k] = o[k]; });
    const act = document.activeElement; if(act && act.id && BRC.some(c => c[1] === act.id)) delete d[BRC.find(c => c[1] === act.id)[0]];
    d.img = o.img || ''; d.ac = o.ac || ''; d.pal = o.pal || []; d.emblemImg = o.emblemImg || ''; fillBrand(d);
  }
  function brandColors(x, w, h){
    const d = x.getImageData(0, 0, w, h).data, bins = {};
    for(let i = 0; i < d.length; i += 4){
      if(d[i + 3] < 128) continue; const r = d[i], g = d[i + 1], b = d[i + 2], mx = Math.max(r, g, b), mn = Math.min(r, g, b);
      if(mn > 232 || mx < 40) continue; const k = (r >> 4) + ',' + (g >> 4) + ',' + (b >> 4), o = bins[k] || (bins[k] = { n: 0, c: 0, r: 0, g: 0, b: 0 });
      o.n += (mx - mn) < 25 ? .15 : 1; o.c++; o.r += r; o.g += g; o.b += b;
    }
    const list = Object.keys(bins).map(k => bins[k]).sort((a, b) => b.n - a.n).map(o => toHexC([o.r / o.c, o.g / o.c, o.b / o.c])), pal = [];
    for(const c of list){ if(pal.every(p => distC(p, c) > 70)) pal.push(c); if(pal.length >= 5) break; } return pal;
  }
  function brandLoadImage(file, maxW, maxH, maxLen, cb){
    const r = new FileReader(); r.onerror = () => cb('', []);
    r.onload = () => { const im = new Image(); im.onerror = () => cb('', []); im.onload = () => {
      let w = im.naturalWidth || 300, h = im.naturalHeight || 100, sc = Math.min(1, maxW / w, maxH / h); w = Math.max(1, Math.round(w * sc)); h = Math.max(1, Math.round(h * sc));
      let url = '', c, x, tries = 0;
      do{ c = document.createElement('canvas'); c.width = w; c.height = h; x = c.getContext('2d'); x.drawImage(im, 0, 0, w, h);
        url = c.toDataURL('image/webp', .9); if(!/^data:image\/webp/.test(url)) url = c.toDataURL('image/png');
        if(url.length > maxLen){ w = Math.max(1, Math.round(w * .7)); h = Math.max(1, Math.round(h * .7)); } else break; } while(++tries < 5);
      if(url.length > maxLen * 1.4){ cb('', []); return; }
      let pal = []; try{ pal = brandColors(x, w, h); }catch(e){} cb(url, pal); };
      im.src = r.result; };
    r.readAsDataURL(file);
  }
  (function(){
    if(!$id('brMode')) return;
    const stl = document.createElement('style'); stl.textContent = '.brSec{border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin-bottom:12px}.brSec h4{margin:0 0 6px;font-size:.92rem}.brSec p{margin:0 0 6px;font-size:.78rem;color:var(--ink-faint)}.brIn{width:100%;padding:9px;margin-top:6px;border:1px solid var(--line);border-radius:8px;background:var(--panel);color:inherit;font:inherit;box-sizing:border-box}.brRow{display:flex;align-items:center;gap:10px;margin-top:8px;flex-wrap:wrap}.brChip{width:30px;height:30px;border-radius:50%;border:2px solid var(--line);cursor:pointer;padding:0}.brPre{border:1px solid var(--line);border-radius:12px;padding:10px;max-width:320px;margin-top:8px}.brPre svg{width:100%;height:auto;display:block}#brPrevI svg{width:72px;height:72px}.brPB{border:1px solid var(--line);border-radius:999px;padding:7px 12px;background:var(--panel);color:inherit;font:inherit;font-size:.85rem;cursor:pointer}';
    document.head.appendChild(stl);
    $id('brFont').innerHTML = BR_FONTS.map(f => '<option value="' + f.k + '">' + f.t + '</option>').join('');
    $id('brPresets').innerHTML = BR_PRESETS.map((p, i) => '<button type="button" class="brPB" data-p="' + i + '">' + p.t + '</button>').join('');
    const dirty = () => { brandDirty = true; brandPreview(); };
    BRC.forEach(([k, id, t]) => { const el = $id(id); if(!el) return; if(t === 'b') el.addEventListener('click', () => { setT(id, !el.classList.contains('on')); dirty(); }); else { el.addEventListener('input', dirty); el.addEventListener('change', dirty); } });
    $id('brFont').addEventListener('change', () => { const f = BR_FONTS.find(x => x.k === $id('brFont').value) || BR_FONTS[0]; setT('brSpread', !!f.up); $id('brCase').value = 'auto'; dirty(); });
    $id('brPresets').addEventListener('click', e => { const b = e.target.closest('[data-p]'); if(!b) return; fillBrand(Object.assign({ align: 'start', 'case': 'auto' }, BR_PRESETS[+b.dataset.p].v)); dirty(); });
    $id('brPal').addEventListener('click', e => { const b = e.target.closest('[data-c]'); if(!b) return; $id('brAccent').value = b.dataset.c; setT('brAccAuto', false); dirty(); });
    $id('brFile').addEventListener('change', e => { const f = e.target.files && e.target.files[0]; if(!f) return; $id('brImgInfo').textContent = 'İşleniyor…';
      brandLoadImage(f, 480, 180, 140000, (url, pal) => { if(!url){ $id('brImgInfo').textContent = 'Görsel okunamadı veya çok büyük. Daha küçük bir PNG/JPG deneyin.'; return; } brImg = { data: url, ac: pal[0] || '', pal }; $id('brImgInfo').textContent = '✓ Görsel yüklendi' + (pal[0] ? ' · logo rengi bulundu: ' + pal[0] : ''); dirty(); }); });
    $id('brEmbFile').addEventListener('change', e => { const f = e.target.files && e.target.files[0]; if(!f) return; $id('brEmbInfo').textContent = 'İşleniyor…';
      brandLoadImage(f, 160, 160, 60000, url => { if(!url){ $id('brEmbInfo').textContent = 'Simge okunamadı veya çok büyük.'; return; } brEmb = url; $id('brEmbInfo').textContent = '✓ Simge görseli yüklendi'; dirty(); }); });
    const brOK = () => !!(curUser && (curUser.sup || (RT.local && curUser.admin)));
    $id('btnBrandSave').addEventListener('click', () => { if(!brOK()) return; brandDirty = true; readBrand(); saveState(); renderLogos(); showToast('Logo ve marka güncellendi.'); });
    $id('btnBrandReset').addEventListener('click', () => { if(!brOK()) return; delete settings.brand; brandDirty = false; brImg = { data: '', ac: '', pal: [] }; brEmb = ''; applyBrandUI(true); saveState(); renderLogos(); showToast('Varsayılan logoya dönüldü.'); });
    $id('btnBrandExp').addEventListener('click', () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(brandDraft())], { type: 'application/json' })); a.download = 'marka-ayarlari.json'; document.body.appendChild(a); a.click(); a.remove(); });
    $id('btnBrandImp').addEventListener('click', () => $id('brImpFile').click());
    $id('brImpFile').addEventListener('change', e => { const f = e.target.files && e.target.files[0]; if(!f) return; const r = new FileReader(); r.onload = () => { try{ const o = JSON.parse(r.result); if(!o || typeof o !== 'object') throw 0; fillBrand(o); dirty(); showToast('Marka ayarları yüklendi. "Güncelle"ye basın.'); }catch(x){ showToast('Dosya okunamadı.'); } }; r.readAsText(f); e.target.value = ''; });
  })();
  let _bSig = '';
  function refreshBrandUI(){ const pd = getPub(), sig = JSON.stringify([pd && pd.brand, pd && pd.social, pd && pd.wifiOn, pd && pd.wifiPass]); if(sig === _bSig) return; _bSig = sig; renderLogos(); }
  function renderLogos(){ try{ applyAccent(); }catch(e){}
    $id('cLogo').innerHTML = logoSVG('full'); $id('sbLogo').innerHTML = logoSVG('full').replace(/lgR/g, 'lgRsb'); renderSocial();
    const fav = logoSVG('mark');
    $id('favi').href = 'data:image/svg+xml,' + encodeURIComponent(fav);
  }

  // ---- genel form penceresi ----
  function openForm(o){
    const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 1000;
    const box = document.createElement('div'); box.className = 'modal-box ff';
    let h = '<h3 style="margin:0 0 4px">' + esc(o.title) + '</h3>' + (o.sub ? '<p style="margin:0 0 6px;color:var(--ink-faint);font-size:.85rem">' + esc(o.sub) + '</p>' : '');
    o.fields.forEach(f => {
      const v = f.value == null ? '' : f.value;
      h += '<div class="ffr"><label>' + esc(f.label || '') + '</label>';
      if(f.type === 'select') h += '<select id="ff_' + f.id + '">' + f.options.map(op => { const ov = typeof op === 'object' ? op.v : op, ot = typeof op === 'object' ? op.t : op; return '<option value="' + esc(ov) + '"' + (String(ov) === String(v) ? ' selected' : '') + '>' + esc(ot) + '</option>'; }).join('') + '</select>';
      else if(f.type === 'textarea') h += '<textarea id="ff_' + f.id + '" rows="2">' + esc(v) + '</textarea>';
      else if(f.type === 'file') h += '<div class="ffimg"><div id="ffp_' + f.id + '"></div><input type="file" accept="image/*" id="ff_' + f.id + '" style="max-width:210px"><button type="button" class="ffrm" data-rm="' + f.id + '">Görseli kaldır</button></div>';
      else if(f.type === 'checkbox') h += '<label class="ffc"><input type="checkbox" id="ff_' + f.id + '"' + (v ? ' checked' : '') + '> ' + esc(f.text || '') + '</label>';
      else if(f.type === 'checks') h += '<div class="ffchk">' + (f.options.length ? f.options.map(op => '<label class="ffc"><input type="checkbox" data-ck="' + f.id + '" value="' + esc(op) + '"' + ((v || []).indexOf(op) >= 0 ? ' checked' : '') + '> ' + esc(op) + '</label>').join('') : '<span style="color:var(--ink-faint);font-size:.85rem">Tanımlı seçenek yok (Tanımlamalar > Özellikler).</span>') + '</div>';
      else h += '<input id="ff_' + f.id + '" type="' + (f.type || 'text') + '" value="' + esc(v) + '"' + (f.step ? ' step="' + f.step + '"' : '') + (f.list ? ' list="ffl_' + f.id + '"' : '') + (f.placeholder ? ' placeholder="' + esc(f.placeholder) + '"' : '') + ' autocomplete="off">' + (f.list ? '<datalist id="ffl_' + f.id + '">' + f.list.map(x => '<option value="' + esc(x) + '">').join('') + '</datalist>' : '');
      h += '</div>';
    });
    h += '<div class="fferr" id="ffErr"></div><div style="display:flex;gap:8px"><button class="btn-save" id="ffOk" style="margin:0">' + esc(o.okText || 'Kaydet') + '</button><button class="btn-save" id="ffNo" style="margin:0;background:var(--ink-faint)">Vazgeç</button></div>';
    box.innerHTML = h; bg.appendChild(box); document.body.appendChild(bg);
    const files = {};
    o.fields.filter(f => f.type === 'file').forEach(f => {
      files[f.id] = f.value || '';
      const draw = () => { const pv = box.querySelector('#ffp_' + f.id); pv.innerHTML = visHtml({ img: files[f.id], icon: f.icon, name: f.name }, '', 'ffprev'); };
      draw();
      box.querySelector('#ff_' + f.id).addEventListener('change', e => { const fl = e.target.files[0]; if(!fl) return; fileToThumb(fl, 360, d => { if(d){ files[f.id] = d; draw(); } else box.querySelector('#ffErr').textContent = 'Görsel okunamadı.'; }); });
      box.querySelector('[data-rm="' + f.id + '"]').onclick = () => { files[f.id] = ''; box.querySelector('#ff_' + f.id).value = ''; draw(); };
    });
    const get = () => {
      const r = {};
      o.fields.forEach(f => {
        if(f.type === 'file'){ r[f.id] = files[f.id]; return; }
        if(f.type === 'checks') r[f.id] = [...box.querySelectorAll('[data-ck="' + f.id + '"]:checked')].map(x => x.value);
        else if(f.type === 'checkbox') r[f.id] = box.querySelector('#ff_' + f.id).checked;
        else { const el = box.querySelector('#ff_' + f.id); r[f.id] = f.type === 'number' ? parseFloat(String(el.value).replace(',', '.')) : el.value.trim(); }
      });
      return r;
    };
    const close = () => bg.remove();
    box.querySelector('#ffNo').onclick = close;
    box.querySelector('#ffOk').onclick = () => { const err = o.onOk(get()); if(err){ box.querySelector('#ffErr').textContent = err; return; } close(); };
    bg.addEventListener('mousedown', e => { if(e.target === bg) close(); });
    if(o.onField) o.fields.forEach(f => { const el = box.querySelector('#ff_' + f.id); if(el) el.addEventListener('input', () => o.onField(f.id, get(), (id, val) => { const t = box.querySelector('#ff_' + id); if(t) t.value = val; })); });
    box.addEventListener('keydown', e => { if(e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.type !== 'checkbox'){ e.preventDefault(); box.querySelector('#ffOk').click(); } });
    const first = box.querySelector('input:not([type=checkbox]),select,textarea'); if(first) setTimeout(() => first.focus(), 50);
  }

  // ---- KDV / birim / mutfak grubu yardımcıları ----
  // görsel bağlantısı: boş -> '', http -> https, şemasız -> https:// eklenir, geçersiz -> null
  function normImgUrl(u){
    u = String(u || '').trim(); if(!u) return '';
    if(/^http:\/\//i.test(u)) u = 'https://' + u.slice(7); else if(!/^https:\/\//i.test(u)) u = 'https://' + u.replace(/^\/+/, '');
    try{ const x = new URL(u); return /\./.test(x.hostname) ? x.href : null; }catch(e){ return null; }
  }
  const parseRate = s => parseFloat(String(s).replace(/[^\d.,]/g, '').replace(',', '.')) || 0;
  function defKdvName(){ const r = (lists.kdv || []).find(x => /varsayılan/i.test(x.val || '') && !/değil/i.test(x.val || '')); return r ? r.name : ((lists.kdv || [])[0] || { name: '%10' }).name; }
  function defGroup(){ return (mutfakGruplari[0] || { name: 'Mutfak' }).name; }
  function findProd(name){ for(const c of categories){ const p = c.products.find(x => x.name === name); if(p) return p; } return null; }
  function grpOf(name){ const p = findProd(name), g = p && p.kg; return (g && mutfakGruplari.some(x => x.name === g)) ? g : defGroup(); }
  function kdvRateOf(name){ const p = findProd(name); return parseRate((p && p.kdv) || defKdvName()); }
  function orderLabel(key){
    if(key.startsWith('table_')){ const n = +key.slice(6); return tname(n); }
    const o = extOrders[key]; return o ? ((o.type === 'paket' ? 'Paket' : 'Gel-Al') + ' · ' + o.name) : key;
  }

  // ---- ürün formu ----
  function openProductForm(p, ci){
    const kdvNames = (lists.kdv || []).map(r => r.name), birimNames = (lists.birimler || []).map(r => r.name);
    if(!kdvNames.length) kdvNames.push('%10'); if(!birimNames.length) birimNames.push('Adet');
    openForm({
      title: p ? 'Ürünü Düzenle' : 'Yeni Ürün',
      fields: [
        { id: 'name', label: 'Ürün adı', value: p ? p.name : '' },
        { id: 'portion', label: 'Porsiyon', value: p ? p.portion : 'Tam' },
        { id: 'price', label: 'Fiyat (₺, KDV dahil)', type: 'number', step: '0.01', value: p ? p.price : '' },
        { id: 'cat', label: 'Kategori (Ana › Alt)', type: 'select', options: categories.map((c, i) => ({ v: i, t: catLabel(c) })), value: ci },
        { id: 'birim', label: 'Birim', type: 'select', options: birimNames, value: (p && p.birim) || birimNames[0] },
        { id: 'kg', label: 'Departman (sipariş hangi ekrana düşsün: Mutfak, Bar, Nargile…)', type: 'select', options: mutfakGruplari.map(g => g.name), value: (p && p.kg) || defGroup() },
        { id: 'desc', label: 'Açıklama (QR menüde görünür)', value: p ? (p.desc || '') : '' },
        { id: 'imgf', label: 'Ürün fotoğrafı (yükle)', type: 'file', value: p && imgOk(p.img) ? p.img : '', icon: p ? p.icon : '', name: p ? p.name : '' }
      ],
      onOk(v){
        if(!v.name) return 'Ürün adı gerekli.';
        if(!(v.price >= 0)) return 'Geçerli bir fiyat girin.';
        if(categories.some(c => c.products.some(x => x !== p && x.name.toLowerCase() === v.name.toLowerCase()))) return 'Aynı adlı bir ürün zaten var.';
        const ni = +v.cat, obj = p || {};
        Object.assign(obj, { name: v.name, portion: v.portion || 'Tam', price: Math.round(v.price * 100) / 100, kdv: (p && p.kdv) || defKdvName(), birim: v.birim, kg: v.kg, desc: (v.desc || '').trim(), img: v.imgf || '', icon: (p && p.icon) || '' });
        if(!p){ categories[ni].products.push(obj); showAllProds = false; }
        else if(ni !== ci){ const a = categories[ci].products; a.splice(a.indexOf(p), 1); categories[ni].products.push(obj); }
        activeCatIndex = ni; activeGrp = null; if(categories[ni]) openGrps.add(categories[ni].grp || categories[ni].name); renderCatList(); renderProductGrid(); saveState(); showToast(v.name + ' kaydedildi.'); try{ imgQueue('prod', obj, categories[ni]); }catch(e){}
      }
    });
  }

  // ---- mutfak grupları ----
  function renderMutfakRows(){
    const wrap = $id('mutfakRows'); wrap.innerHTML = '';
    mutfakGruplari.forEach((g, idx) => {
      const cnt = categories.reduce((s, c) => s + c.products.filter(p => (p.kg || defGroup()) === g.name).length, 0);
      const row = document.createElement('div'); row.className = 'dt-row';
      row.innerHTML = '<div class="dt-col" style="flex:2;font-weight:700;">' + esc(g.name) + '</div><div class="dt-col" style="flex:2;"><span class="badge">' + cnt + ' ürün</span></div>' +
        '<div class="dt-col dt-actions" style="flex:1;justify-content:flex-end;"><span class="link-btn" data-act="edit">Düzenle</span><span class="link-btn" data-act="del">Sil</span></div>';
      row.querySelector('[data-act="edit"]').addEventListener('click', () => {
        openForm({ title: 'Mutfak Grubu', fields: [{ id: 'n', label: 'Grup adı', value: g.name }], onOk(v){
          if(!v.n) return 'Ad gerekli.'; if(mutfakGruplari.some(x => x !== g && x.name.toLowerCase() === v.n.toLowerCase())) return 'Bu ad zaten var.';
          categories.forEach(c => c.products.forEach(p => { if(p.kg === g.name) p.kg = v.n; })); g.name = v.n; renderMutfakRows(); saveState();
        } });
      });
      row.querySelector('[data-act="del"]').addEventListener('click', async () => {
        if(mutfakGruplari.length <= 1){ showToast('En az bir mutfak grubu kalmalı.'); return; }
        if(!await uiConfirm('"' + g.name + '" silinsin mi? Ürünleri "' + mutfakGruplari[idx === 0 ? 1 : 0].name + '" grubuna aktarılacak.')) return;
        const to = mutfakGruplari[idx === 0 ? 1 : 0].name;
        categories.forEach(c => c.products.forEach(p => { if(p.kg === g.name) p.kg = to; }));
        mutfakGruplari.splice(idx, 1); renderMutfakRows(); saveState(); showToast('Grup silindi.');
      });
      wrap.appendChild(row);
    });
  }
  $id('btnYeniMutfakGrubu').addEventListener('click', () => openForm({ title: 'Yeni Mutfak Grubu', sub: 'Örn: Bar, Sıcak Mutfak, Tatlı', fields: [{ id: 'n', label: 'Grup adı' }], onOk(v){
    if(!v.n) return 'Ad gerekli.'; if(mutfakGruplari.some(x => x.name.toLowerCase() === v.n.toLowerCase())) return 'Bu ad zaten var.';
    mutfakGruplari.push({ name: v.n, durum: 'Hazırlanıyor ve Hazırlandı' }); renderMutfakRows(); saveState(); showToast('Grup eklendi: ' + v.n);
  } }));

  // ---- mutfak ekranı ----
  let kGrp = '';
  function sendToKitchen(){
    const key = currentCartKey, by = {};
    carts[key].forEach(i => {
      const n = i.qty - (i.sent || 0);
      if(n > 0){ const g = grpOf(i.name); (by[g] = by[g] || []).push({ name: i.name, qty: n, note: i.note || '' }); }
      i.sent = i.qty;
    });
    const gs = Object.keys(by); if(!gs.length) return;
    const label = orderLabel(key);
    gs.forEach(g => RT.push('kitchen', { table: key, label, grp: g, items: by[g], ts: Date.now(), status: 'hazirlaniyor', src: 'garson', by: uname() }));
    showToast('Yeni ürünler mutfağa iletildi' + (gs.length > 1 ? ' (' + gs.length + ' gruba ayrıldı).' : '.'));
  }
  const isUnread = k => !!k && k.status === 'hazirlaniyor' && !k.ack;
  function renderKitchen(){
    const list = Object.entries(kitchenData || {}).filter(([, k]) => k).sort((a, b) => a[1].ts - b[1].ts);
    const open = list.filter(([, k]) => k.status === 'hazirlaniyor').length;
    const kb = $id('kBadge'); if(kb){ kb.textContent = open; kb.classList.toggle('on', open > 0); }
    const names = mutfakGruplari.map(g => g.name);
    $id('kTabs').innerHTML = ['Tümü'].concat(names).map(n => '<div class="region-tab' + ((n === 'Tümü' ? '' : n) === kGrp ? ' active' : '') + '" data-g="' + esc(n === 'Tümü' ? '' : n) + '">' + esc(n) + '</div>').join('');
    const f = list.filter(([, k]) => !kGrp || (k.grp || defGroup()) === kGrp), kc = can('kitchen');
    const nUn = f.filter(([, k]) => isUnread(k)).length;
    $id('kitchenList').innerHTML = f.length ? (kc && nUn ? '<div class="k-alert">🔔 ' + nUn + ' yeni sipariş — "Okudum Anladım" a basana kadar uyarı sesi devam eder</div>' : '') + f.map(([id, k]) => {
      const un = isUnread(k), who = k.src === 'müşteri' ? 'Müşteri (QR)' : (k.by || 'Personel');
      const acts = !kc ? '<div class="k-st">' + (un ? '⏳ Henüz okunmadı' : k.status === 'hazir' ? '✔ Hazır' : '👁 Okundu · hazırlanıyor') + '</div>'
        : '<div class="acts">' + (un ? '<button class="b-read" data-id="' + id + '" data-a="ack">👁 Okudum Anladım</button>' : k.status === 'hazir' ? '<button class="b-no" data-id="' + id + '" data-a="del">Teslim Edildi</button>' : '<button class="b-ok" data-id="' + id + '" data-a="ready">✔ Hazır</button>') + '</div>';
      return '<div class="k-card ' + (k.status === 'hazir' ? 'hazir ' : '') + (un ? 'new' : '') + '"><b>' + esc(k.label) + '</b> <span class="tag">' + esc(k.grp || '') + '</span> <span class="tag who">👤 ' + esc(who) + '</span><span style="float:right;color:var(--ink-faint);font-size:.8rem;">' + hhmm(k.ts) + '</span>' +
        arr(k.items).map(i => '<div style="font-size:1.05rem;margin-top:4px;">' + i.qty + '× ' + esc(i.name) + (i.note ? '<div style="font-size:.82rem;color:var(--red);">📝 ' + esc(i.note) + '</div>' : '') + '</div>').join('') +
        (k.note ? '<div style="margin-top:6px;color:var(--ink-dim);font-size:.85rem;">📝 ' + esc(k.note) + '</div>' : '') + acts + '</div>';
    }).join('') : '<p style="color:var(--ink-faint);">Bekleyen mutfak siparişi yok.</p>';
    kAlarmSync();
  }
  $id('kTabs').addEventListener('click', e => { const t = e.target.closest('.region-tab'); if(!t) return; kGrp = t.dataset.g; renderKitchen(); });
  $id('kitchenList').addEventListener('click', e => {
    const b = e.target.closest('button'); if(!b || !can('kitchen')) return;
    const id = b.dataset.id, a = b.dataset.a, safe = p => { try{ Promise.resolve(p).catch(() => {}); }catch(_){} };
    if(a === 'ack'){
      const ts = Date.now(); if(kitchenData[id]){ kitchenData[id].ack = ts; kitchenData[id].ackBy = uname(); }
      safe(RT.set('kitchen/' + id + '/ack', ts)); safe(RT.set('kitchen/' + id + '/ackBy', uname())); renderKitchen(); return;
    }
    if(a === 'ready') safe(RT.set('kitchen/' + id + '/status', 'hazir')); else if(a === 'del') safe(RT.remove('kitchen/' + id));
  });
  function approveCO(id, o){
    const key = 'table_' + o.table;
    if(!carts[key]) carts[key] = [];
    const by = {};
    arr(o.items).forEach(it => {
      const ex = carts[key].find(i => i.name === it.name && i.unit === it.unit && !i.note && i.by === 'Müşteri (QR)');
      if(ex){ ex.qty += it.qty; ex.sent = (ex.sent || 0) + it.qty; }
      else carts[key].push({ name: it.name, sub: it.sub || 'tam', unit: it.unit, qty: it.qty, sent: it.qty, by: 'Müşteri (QR)', at: Date.now() });
      const g = grpOf(it.name); (by[g] = by[g] || []).push({ name: it.name, qty: it.qty });
    });
    Object.keys(by).forEach(g => RT.push('kitchen', { table: key, label: o.label, grp: g, items: by[g], note: o.note || '', ts: Date.now(), status: 'hazirlaniyor', src: 'müşteri', by: uname() }));
    RT.set('customerOrders/' + id + '/status', 'onaylandi');
    renderTableGrid(); renderSiparisMasa(); updateHomeStats(); saveState();
    showToast(o.label + ' siparişi onaylandı, mutfağa iletildi.');
  }

  // ---- sipariş kanbanı (masa + paket + gel-al) ----
  function renderSmKanban(){
    const keys = [];
    regions.forEach(r => r.tables.forEach(n => {
      const key = 'table_' + n;
      if(carts[key] && carts[key].length){ if(!orderOpenedAt[key]) orderOpenedAt[key] = Date.now(); keys.push(key); } else delete orderOpenedAt[key];
    }));
    Object.keys(extOrders).forEach(key => {
      if(carts[key] && carts[key].length){ if(!orderOpenedAt[key]) orderOpenedAt[key] = extOrders[key].created || Date.now(); keys.push(key); }
    });
    const q = smSearch.toLowerCase();
    const filtered = keys.filter(key => { const label = orderLabel(key).toLowerCase(); return !q || label.includes(q) || String(adisyonNoByKey[key] || '').includes(q); });
    $id('smPrepHead').textContent = '👨‍🍳 Hazırlanıyor (' + filtered.length + ')';
    const body = $id('smPrepBody'); body.innerHTML = '';
    filtered.forEach(key => {
      const label = orderLabel(key), card = document.createElement('div'); card.className = 'sm-order-card';
      card.innerHTML = '<div class="oc-top"><div class="oc-avatar">' + (key.startsWith('table_') ? '🍽️' : (extOrders[key].type === 'paket' ? '📦' : '🛍️')) + '</div><div><div class="oc-name">' + esc(label) + '</div>' +
        '<div class="oc-timer" data-timer-key="' + key + '">' + fmtElapsed(Date.now() - orderOpenedAt[key]) + '</div></div><div class="oc-no">#' + (adisyonNoByKey[key] || '—') + '</div></div>' +
        (byNames(carts[key]).length ? '<div class="oc-by">👤 ' + byNames(carts[key]).map(esc).join(', ') + '</div>' : '') + '<div class="oc-total">' + fmtTL(cartTotal(key)) + '</div>';
      card.addEventListener('click', () => openOrder(key, label, key.startsWith('table_') ? 'siparis-masa' : 'paketler'));
      body.appendChild(card);
    });
    const w = (typeof pendingCO === 'function') ? pendingCO() : [];
    $id('smWaitHead').textContent = '🕐 Bekleyen Müşteri Siparişleri (' + w.length + ')';
    const wb = $id('smWaitBody');
    wb.innerHTML = w.map(([id, o]) => '<div class="sm-order-card"><div class="oc-name">' + esc(o.label) + '</div><div class="oc-timer">' + arr(o.items).map(i => i.qty + '× ' + esc(i.name)).join(', ') + '</div></div>').join('');
    wb.onclick = () => { renderCO(); $id('coModal').classList.add('show'); };
  }

  // ---- paket / gel-al: her sipariş kendi adisyonu ----
  let pkTab = 'paket';
  function renderPaketler(){
    const el = $id('pkList'); if(!el) return;
    $id('pkTabPaket').classList.toggle('active', pkTab === 'paket'); $id('pkTabGelal').classList.toggle('active', pkTab === 'gelal');
    const rows = Object.entries(extOrders).filter(([, o]) => o.type === pkTab).sort((a, b) => a[1].created - b[1].created);
    $id('pkTabPaket').textContent = '📦 Paket (' + Object.values(extOrders).filter(o => o.type === 'paket').length + ')';
    $id('pkTabGelal').textContent = '🛍️ Gel-Al (' + Object.values(extOrders).filter(o => o.type === 'gelal').length + ')';
    const act = can('orders') || can('courier');
    el.innerHTML = rows.length ? rows.map(([k, o]) => {
      const items = carts[k] || [], cnt = items.reduce((s, i) => s + i.qty, 0);
      const st = o.st === 'yolda' ? '🛵 Yolda' + (o.courier ? ' · ' + esc(o.courier) : '') : o.st === 'hazir' ? '✔ Hazır' : '👨‍🍳 Hazırlanıyor';
      const nx = !act ? '' : o.type === 'paket' ? (o.st === 'yolda' ? '' : '<span class="link-btn" data-pk="next" data-k="' + k + '">🛵 Yola Çıktı</span>') : (o.st === 'hazir' ? '' : '<span class="link-btn" data-pk="next" data-k="' + k + '">✔ Hazır</span>');
      return '<div class="prow" style="flex-wrap:wrap;gap:6px;"><span class="pic">' + (o.type === 'paket' ? '📦' : '🛍️') + '</span><div class="pmain" style="min-width:170px;flex:1;"><b>' + esc(o.name) + '</b><span>' + esc(o.phone || '') + (o.address ? ' · ' + esc(o.address) : '') + '</span><span>' + cnt + ' ürün · ' + hhmm(o.created) + ' · ' + st + '</span></div>' +
        '<span class="pval">' + money(remainingForKey(k)) + '</span><span class="link-btn" data-pk="open" data-k="' + k + '">Aç</span>' + nx + '<span class="link-btn" data-pk="del" data-k="' + k + '">🗑</span></div>';
    }).join('') : '<p style="color:var(--ink-faint);padding:12px;">Açık ' + (pkTab === 'paket' ? 'paket' : 'gel-al') + ' siparişi yok.</p>';
    $id('btnYeniExt').style.display = can('orders') ? '' : 'none';
  }
  $id('pkTabPaket').addEventListener('click', () => { pkTab = 'paket'; renderPaketler(); });
  $id('pkTabGelal').addEventListener('click', () => { pkTab = 'gelal'; renderPaketler(); });
  function dropExt(key){ delete carts[key]; delete extOrders[key]; [paidByKey, paymentHistoryByKey, discountByKey, guestsByKey, orderOpenedAt, adisyonNoByKey].forEach(o => delete o[key]); }
  $id('pkList').addEventListener('click', async e => {
    const b = e.target.closest('[data-pk]'); if(!b) return;
    const k = b.dataset.k, o = extOrders[k]; if(!o) return;
    if(b.dataset.pk === 'open') openOrder(k, orderLabel(k), 'paketler');
    else if(b.dataset.pk === 'next'){ o.st = o.type === 'paket' ? 'yolda' : 'hazir'; if(o.type === 'paket') o.courier = uname(); renderPaketler(); saveState(); }
    else if(b.dataset.pk === 'del'){
      if((carts[k] || []).length && !can('cancel')){ showToast('Ürünlü siparişi iptal etme yetkiniz yok.'); return; }
      if((paidByKey[k] || 0) > 0){ showToast('Ödeme alınmış sipariş iptal edilemez.'); return; }
      if(!await uiConfirm('Bu sipariş silinsin mi?')) return;
      dropExt(k); renderPaketler(); renderSiparisMasa(); updateHomeStats(); saveState();
    }
  });
  $id('btnYeniExt').addEventListener('click', () => {
    openForm({
      title: 'Yeni Sipariş', sub: 'Her sipariş ayrı bir adisyon açar.',
      fields: [
        { id: 'type', label: 'Tip', type: 'select', options: [{ v: 'paket', t: '📦 Paket' }, { v: 'gelal', t: '🛍️ Gel-Al' }], value: pkTab },
        { id: 'name', label: 'Müşteri adı', list: customers.map(c => c.name) },
        { id: 'phone', label: 'Telefon', placeholder: '05xx xxx xx xx' },
        { id: 'address', label: 'Adres (paket için)', type: 'textarea' }
      ],
      onField(id, v, set){
        if(id === 'name'){ const c = customers.find(x => x.name.toLowerCase() === v.name.toLowerCase()); if(c){ if(!v.phone && c.phone && c.phone !== '—') set('phone', c.phone); if(!v.address && c.address && c.address !== '—') set('address', c.address); } }
      },
      onOk(v){
        if(!v.name) return 'Müşteri adı gerekli.';
        if(v.type === 'paket' && (!v.phone || !v.address)) return 'Paket için telefon ve adres gerekli.';
        const key = v.type + '_' + (++extSeq);
        extOrders[key] = { type: v.type, name: v.name, phone: v.phone, address: v.type === 'paket' ? v.address : '', st: 'hazirlaniyor', created: Date.now(), by: uname() };
        carts[key] = []; pkTab = v.type;
        if(v.phone && !customers.some(c => c.phone === v.phone)){
          customers.push({ no: customers.length ? Math.max.apply(null, customers.map(c => c.no)) + 1 : 1, name: v.name, phone: v.phone, address: v.address || '—', acikHesap: false, balance: 0 });
        }
        openOrder(key, orderLabel(key), 'paketler'); openMenuPicker(); saveState();
      }
    });
  });

  // ---- sipariş satırı notları (Özellikler) ----
  function editNote(item){
    setTimeout(() => { try{ aiAttachNoteBtn('ff_extra'); }catch(e){} }, 0);
    const cart = carts[currentCartKey];
    if((item.sent || 0) >= item.qty){ showToast('Bu satır mutfağa gönderildi. Not için ürünü yeniden ekleyip o satıra not yazın.'); return; }
    const opts = (lists.ozellikler || []).map(r => r.name), cur = (item.note || '').split(',').map(s => s.trim()).filter(Boolean);
    openForm({
      title: item.name + ' — Not / Özellik',
      fields: [{ id: 'sel', label: 'Özellikler', type: 'checks', options: opts, value: cur }, { id: 'extra', label: 'Ek not', value: cur.filter(x => opts.indexOf(x) < 0).join(', ') }],
      onOk(v){
        const note = v.sel.concat(v.extra ? [v.extra] : []).join(', ');
        if((item.sent || 0) > 0){
          const rest = item.qty - item.sent; item.qty = item.sent;
          cart.push({ name: item.name, sub: item.sub, unit: item.unit, qty: rest, note, sent: 0, by: item.by || '', at: item.at || Date.now() });
        } else item.note = note;
        afterOrderChange();
      }
    });
  }
  function itemChange(item, nq){
    if(!can('orders')){ showToast('Adisyonu düzenleme yetkiniz yok.'); return false; }
    if(nq < (item.sent || 0) && !can('cancel')){ showToast('Mutfağa gönderilmiş ürünü azaltmak / silmek için iptal yetkisi gerekir.'); return false; }
    return true;
  }

  // ---- ödeme: tahsilat / açık hesap / ikram ----
  var ensurePayTypes = function(){
    ['Nakit', 'Açık Hesap'].forEach(n => { if(!payTypes.some(p => p.name === n)) payTypes.push({ name: n, on: n === 'Nakit' }); });
  };
  $id('ppMethods').addEventListener('click', e => {
    const btn = e.target.closest('.pp-method'); if(!btn) return;
    if(!can('pay')){ showToast('Ödeme alma yetkiniz yok.'); return; }
    const method = btn.getAttribute('data-method'), amount = payAmount(); if(!amount) return;
    if(method === 'Açık Hesap'){
      const cs = customers.filter(c => c.acikHesap);
      if(!cs.length){ showToast('Açık hesaplı müşteri yok. Müşteriler ekranında bir müşteriyi açık hesap olarak işaretleyin.'); return; }
      openForm({ title: 'Açık Hesaba Yaz — ' + money(amount), fields: [{ id: 'c', label: 'Müşteri', type: 'select', options: cs.map(c => ({ v: c.no, t: c.name + ' (bakiye ' + money(c.balance) + ')' })) }],
        onOk(v){ const c = customers.find(x => x.no === +v.c); if(!c) return 'Müşteri seçin.'; c.balance = Math.round((c.balance + amount) * 100) / 100; settle('Açık Hesap', amount, { label: 'Açık Hesap · ' + c.name }); } });
      return;
    }
    settle(method, amount, {});
  });
  function payAmount(){
    const key = currentCartKey, remaining = remainingForKey(key); if(remaining <= 0) return 0;
    let amount = parseFloat(String($id('ppAmountInput').value).replace(',', '.'));
    if(!(amount > 0)){ showToast('Geçerli bir tutar girin.'); return 0; }
    return Math.round(Math.min(amount, remaining) * 100) / 100;
  }
  function settle(method, amount, o){
    const key = currentCartKey, title = orderLabel(key);
    paidByKey[key] = Math.round(((paidByKey[key] || 0) + amount) * 100) / 100;
    (paymentHistoryByKey[key] = paymentHistoryByKey[key] || []).push({ method: o.label || method, amount, waive: !!o.waive });
    if(o.waive) logPriv('waiveLog', { ts: Date.now(), amount, reason: o.reason, label: title, user: uname() });
    else logPriv('payLog', { ts: Date.now(), amount, method, label: title, user: uname() });
    const nr = remainingForKey(key);
    if(nr <= 0.005) finalizeOrder(key, (o.waive ? 'İkram' : method) + ' ile ' + money(amount) + ' — ödeme tamamlandı.');
    else { updateHomeStats(); renderGunSonu(); renderOrderLines(); renderPaymentPanel(); showToast((o.waive ? 'İkram' : method) + ' ile ' + money(amount) + ' işlendi. Kalan: ' + money(nr)); }
    saveState();
  }
  function finalizeOrder(key, msg){
    const hist = paymentHistoryByKey[key] || [], wv = hist.filter(h => h.waive).reduce((s, h) => s + h.amount, 0);
    logPriv('saleLog', { ts: Date.now(), label: orderLabel(key), total: cartTotal(key), gross: grossTotal(key), waived: wv, guests: Math.max(1, parseInt(guestsByKey[key]) || 1), user: uname(),
      items: carts[key].map(i => ({ name: i.name, qty: i.qty, unit: i.unit, by: i.by || '', kdv: kdvRateOf(i.name) })) });
    carts[key] = [];
    if(key.startsWith('table_')) delete tableGuest[+key.slice(6)];
    [orderOpenedAt, adisyonNoByKey, paidByKey, paymentHistoryByKey, discountByKey, guestsByKey].forEach(o => delete o[key]);
    closeMenuPicker(); mpDraft = [];
    const back = currentBackScreen;
    renderOrderLines(); renderTableGrid(); renderSiparisMasa(); updateHomeStats(); renderGunSonu();
    $id('paymentPanel').style.display = 'none';
    if(extOrders[key]){ delete carts[key]; delete extOrders[key]; }
    showToast(msg + ' Adisyon kapatıldı.'); showScreen(back); saveState();
  }
  $id('btnWaive').addEventListener('click', () => {
    if(!can('discount')){ showToast('İkram yetkiniz yok.'); return; }
    const amount = payAmount(); if(!amount) return;
    const reasons = (lists.odenmezler || []).map(r => r.name); if(!reasons.length) reasons.push('İkram');
    openForm({ title: 'Ödenmez / İkram — ' + money(amount), sub: 'Bu tutar tahsil edilmez; raporda ikram olarak görünür.', fields: [{ id: 'r', label: 'Gerekçe', type: 'select', options: reasons }],
      okText: 'İkram Et', onOk(v){ settle('İkram', amount, { waive: true, reason: v.r, label: 'İkram · ' + v.r }); } });
  });

  // ---- müşteriler ----
  function renderCustomers(){
    const q = custSearch.toLowerCase();
    let rows = customers.filter(c => String(c.name).toLowerCase().includes(q) || String(c.phone).toLowerCase().includes(q));
    if(custSort.key) rows = rows.slice().sort((a, b) => { let av = a[custSort.key], bv = b[custSort.key]; if(custSort.key === 'name'){ av = av.toLowerCase(); bv = bv.toLowerCase(); } return av > bv ? custSort.dir : av < bv ? -custSort.dir : 0; });
    const wrap = $id('custRows'); wrap.innerHTML = '';
    const ed = can('customers');
    rows.forEach(c => {
      const row = document.createElement('div'); row.className = 'dt-row';
      row.innerHTML = '<div class="dt-col" style="flex:0.6;">' + c.no + '</div><div class="dt-col" style="flex:1.6;font-weight:700;">' + esc(c.name) + '</div><div class="dt-col" style="flex:1.4;">' + esc(c.phone) + '</div><div class="dt-col" style="flex:1.6;">' + esc(c.address) + '</div>' +
        '<div class="dt-col" style="flex:1.2;">' + (c.acikHesap ? '<span class="badge">Evet</span>' : '—') + '</div><div class="dt-col" style="flex:1;text-align:right;font-weight:700;">' + money(c.balance) + '</div>' +
        '<div class="dt-col dt-actions" style="flex:1.4;justify-content:flex-end;gap:10px;">' + (ed ? '<span class="link-btn" data-c="edit" data-no="' + c.no + '">Düzenle</span>' + (c.balance > 0 ? '<span class="link-btn" data-c="col" data-no="' + c.no + '">Tahsilat</span>' : '') + '<span class="link-btn" data-c="del" data-no="' + c.no + '">Sil</span>' : '') + '</div>';
      wrap.appendChild(row);
    });
    $id('custSummary').innerHTML = 'Müşteri Sayısı : ' + customers.length + '&nbsp;&nbsp;&nbsp;Toplam Bakiye : ' + money(customers.reduce((s, c) => s + c.balance, 0));
    $id('btnMusteriEkle').style.display = ed ? '' : 'none';
  }
  function openCustomerForm(c){
    openForm({
      title: c ? 'Müşteriyi Düzenle' : 'Yeni Müşteri',
      fields: [
        { id: 'name', label: 'Ad Soyad', value: c ? c.name : '' }, { id: 'phone', label: 'Telefon', value: c && c.phone !== '—' ? c.phone : '' },
        { id: 'address', label: 'Adres', type: 'textarea', value: c && c.address !== '—' ? c.address : '' },
        { id: 'ah', label: 'Açık hesap', type: 'checkbox', text: 'Açık hesap (veresiye) müşterisi', value: c ? c.acikHesap : false },
        { id: 'bal', label: 'Bakiye / borç (₺)', type: 'number', step: '0.01', value: c ? c.balance : 0 }
      ],
      onOk(v){
        if(!v.name) return 'Ad Soyad gerekli.';
        if(v.phone && customers.some(x => x !== c && x.phone === v.phone)) return 'Bu telefon başka bir müşteride kayıtlı.';
        const bal = isNaN(v.bal) ? 0 : Math.round(v.bal * 100) / 100;
        if(c) Object.assign(c, { name: v.name, phone: v.phone || '—', address: v.address || '—', acikHesap: v.ah, balance: bal });
        else customers.push({ no: customers.length ? Math.max.apply(null, customers.map(x => x.no)) + 1 : 1, name: v.name, phone: v.phone || '—', address: v.address || '—', acikHesap: v.ah, balance: bal });
        renderCustomers(); saveState(); showToast('Müşteri kaydedildi.');
      }
    });
  }
  $id('btnMusteriEkle').addEventListener('click', () => openCustomerForm(null));
  $id('custRows').addEventListener('click', async e => {
    const b = e.target.closest('[data-c]'); if(!b || !can('customers')) return;
    const c = customers.find(x => x.no === +b.dataset.no); if(!c) return;
    if(b.dataset.c === 'edit') openCustomerForm(c);
    else if(b.dataset.c === 'del'){ if(await uiConfirm('"' + c.name + '" silinsin mi?' + (c.balance ? ' Müşterinin ' + money(c.balance) + ' bakiyesi var!' : ''))){ customers.splice(customers.indexOf(c), 1); renderCustomers(); saveState(); } }
    else if(b.dataset.c === 'col') openForm({ title: 'Tahsilat — ' + c.name, sub: 'Bakiye: ' + money(c.balance), fields: [{ id: 'a', label: 'Tutar (₺)', type: 'number', step: '0.01', value: c.balance }, { id: 'm', label: 'Ödeme şekli', type: 'select', options: ['Nakit', 'Kredi Kartı'] }],
      onOk(v){ if(!(v.a > 0)) return 'Geçerli tutar girin.'; if(v.a > c.balance + 0.005) return 'Tutar bakiyeden fazla olamaz.'; c.balance = Math.round((c.balance - v.a) * 100) / 100; logPriv('colLog', { ts: Date.now(), amount: v.a, method: v.m, cust: c.name, user: uname() }); renderCustomers(); renderGunSonu(); saveState(); showToast('Tahsilat alındı.'); } });
  });

  // ---- kullanıcılar ----
  // ---- kişiye özel Firebase hesabı yönetimi (yalnızca yönetici Firebase oturumuyla) ----
  const fbErr = e => ({ 'auth/weak-password': 'Şifre en az 6 karakter olmalı (Firebase şartı).', 'auth/operation-not-allowed': 'Firebase’de E-posta/Şifre girişi kapalı.', 'auth/network-request-failed': 'İnternet bağlantısı yok.', 'auth/invalid-email': 'İsim e-postaya çevrilemedi, farklı bir isim deneyin.', 'auth/too-many-requests': 'Çok fazla deneme, biraz bekleyin.' }[(e && e.code) || ''] || ('Hata: ' + ((e && e.code) || (e && e.message) || 'bilinmiyor')));
  async function fbCreateStaff(u, pw){
    if(!(RT.isAdmin && RT.isAdmin()) || !RT.createStaff){ showToast('Önce yönetici Firebase hesabıyla bağlanın (yönetici olarak çıkış-giriş yapıp Firebase hesabını girin).'); return false; }
    const n = normName(u.ad); if(!n){ showToast('İsim en az bir harf veya rakam içermeli.'); return false; }
    let cur = 0; try{ cur = +(await RT.get('staffVer/' + n)) || 0; }catch(e){ showToast('Firebase okunamadı: ' + fbErr(e)); return false; }
    let v = cur + 1, nid = null, tries = 0;
    while(!nid && tries++ < 6){
      try{ nid = await RT.createStaff(staffEmail(n, v), pw); }
      catch(e){ if(e && e.code === 'auth/email-already-in-use'){ v++; continue; } showToast(fbErr(e)); return false; }
    }
    if(!nid){ showToast('Hesap açılamadı, tekrar deneyin.'); return false; }
    try{
      await RT.set('staffRoles/' + nid, { ad: u.ad, gorev: u.gorev, bolge: (u.bolge && u.bolge !== '—') ? u.bolge : '', blocked: !!u.blocked, v });
      await RT.set('staffVer/' + n, v);
      if(u.uid && u.uid !== nid) await RT.remove('staffRoles/' + u.uid);
    }catch(e){ try{ await RT.remove('staffRoles/' + nid); }catch(_){} showToast('Kayıt yazılamadı: ' + fbErr(e) + ' (Rules yayınlandı mı?)'); return false; }
    u.uid = nid; u.v = v; delete u.h; delete u.sifre;
    return true;
  }
  async function pullStaffRoles(){
    if(RT.local || !(RT.isAdmin && RT.isAdmin())) return;
    try{
      const r = await RT.get('staffRoles') || {};
      Object.keys(r).forEach(id => {
        const x = r[id]; if(!x || !x.ad || x.owner === true) return;
        let u = staffUsers.find(s => s.uid === id) || staffUsers.find(s => normName(s.ad) === normName(x.ad));
        if(!u){ u = { ad: x.ad, tel: '', email: '' }; staffUsers.push(u); }
        Object.assign(u, { uid: id, v: x.v || 1, ad: x.ad, gorev: x.gorev, bolge: x.bolge || '', blocked: x.blocked === true }); delete u.h; delete u.sifre;
      });
      staffUsers = staffUsers.filter(u => u.uid ? !!r[u.uid] : !staffUsers.some(o => o.uid && normName(o.ad) === normName(u.ad)));
      renderUsers(); saveState();
    }catch(e){ console.error('staffRoles okunamadı:', e); }
  }
  function fillBolge(){ const cur = $id('selBolge').value; $id('selBolge').innerHTML = '<option>—</option>' + regions.map(r => '<option>' + esc(r.name) + '</option>').join(''); if(cur) $id('selBolge').value = cur; }
  function renderUsers(){
    $id('usersList').innerHTML = staffUsers.map((u, i) => '<div class="prow" style="flex-wrap:wrap;gap:4px;"><span class="pic">👤</span><div class="pmain" style="flex:1;min-width:150px;"><b>' + esc(u.ad) + (u.blocked ? ' <span class="badge">Engelli</span>' : '') + (!RT.local && !u.uid ? ' <span class="badge">Eski giriş</span>' : '') + '</b><span>' + esc(u.gorev) + (u.bolge && u.bolge !== '—' ? ' · ' + esc(u.bolge) : '') + (u.tel ? ' · ' + esc(u.tel) : '') + '</span></div>' +
      '<span class="link-btn" data-ua="role" data-i="' + i + '">Görev</span><span class="link-btn" data-ua="pw" data-i="' + i + '">Şifre</span><span class="link-btn" data-ua="blk" data-i="' + i + '">' + (u.blocked ? 'Engeli kaldır' : 'Engelle') + '</span><span class="link-btn" data-ua="del" data-i="' + i + '">🗑</span></div>').join('') ||
      '<p style="color:var(--ink-faint);padding:8px;">Kullanıcı yok.</p>';
  }
  $id('usersList').addEventListener('click', async e => {
    const b = e.target.closest('[data-ua]'); if(!b || !can('users')) return;
    const u = staffUsers[+b.dataset.i]; if(!u) return;
    const fb = !RT.local && !!RT.createStaff, minL = fb ? 6 : 4;
    if(b.dataset.ua === 'del'){ if(await uiConfirm('"' + u.ad + '" silinsin mi?')){
      if(u.uid && !RT.local){ try{ await RT.remove('staffRoles/' + u.uid); }catch(err){ showToast('Silinemedi: ' + fbErr(err)); return; } }
      staffUsers.splice(+b.dataset.i, 1); renderUsers(); saveState(); } }
    else if(b.dataset.ua === 'blk'){
      const nv = !u.blocked;
      if(u.uid && !RT.local){ try{ await RT.set('staffRoles/' + u.uid + '/blocked', nv); }catch(err){ showToast('Engelleme yazılamadı: ' + fbErr(err)); return; } }
      u.blocked = nv; renderUsers(); saveState(); }
    else if(b.dataset.ua === 'role') openForm({ title: u.ad + ' — Görev', fields: [{ id: 'g', label: 'Görev', type: 'select', options: ROLES, value: u.gorev }], onOk(v){
      u.gorev = v.g; if(u.uid && !RT.local) Promise.resolve(RT.set('staffRoles/' + u.uid + '/gorev', v.g)).catch(err => showToast('Görev yazılamadı: ' + fbErr(err)));
      renderUsers(); saveState(); } });
    else openForm({ title: u.ad + (fb && !u.uid ? ' — Şifre Belirle (geçiş)' : ' — Yeni Şifre'), fields: [{ id: 'p', label: 'Yeni şifre (en az ' + minL + ' karakter' + (fb ? ', Firebase şartı' : '') + ')', type: 'password' }], onOk(v){
      if(!v.p || v.p.length < minL) return 'Şifre en az ' + minL + ' karakter olmalı' + (fb ? ' (Firebase hesabı için gerekli).' : '.');
      if(pinOK(v.p)) return 'Şifre yönetici PIN\'i ile aynı olamaz.';
      if(fb){ fbCreateStaff(u, v.p).then(ok => { if(ok){ renderUsers(); saveState(); showToast('Şifre ayarlandı: ' + u.ad); } }); return; }
      if(pwTaken(v.p, u.ad)) return 'Bu şifre başka birinde kullanılıyor.';
      u.h = pwHash(v.p); delete u.sifre; saveState(); showToast('Şifre güncellendi.'); } });
  });
  $id('btnEkleKullanici').addEventListener('click', async () => {
    const er = $id('usrErr'), fail = m => { er.textContent = m; showToast(m); };
    er.textContent = '';
    if(!can('users')){ fail('Yetkiniz yok.'); return; }
    const gorev = $id('selGorev').value, ad = $id('inpAdSoyad').value.trim(), tel = $id('inpTelefon').value.trim(), sifre = $id('inpSifre').value.trim();
    const fb = !RT.local && !!RT.createStaff, minL = fb ? 6 : 4;
    if(!ad || !sifre){ fail('Ad Soyad ve Şifre zorunludur.'); return; }
    if(!normName(ad)){ fail('İsim en az bir harf veya rakam içermeli.'); return; }
    if(normName(ad) === 'yonetici' || normName(ad) === 'admin'){ fail('Bu isim yönetici için ayrılmış, başka bir isim yazın.'); return; }
    if(sifre.length < minL){ fail('Şifre en az ' + minL + ' karakter olmalı' + (fb ? ' (Firebase hesabı için gerekli).' : '.')); return; }
    if(staffUsers.some(u => normName(u.ad) === normName(ad))){ fail('Bu isimde bir kullanıcı var.'); return; }
    if(pinOK(sifre)){ fail('Şifre yönetici PIN\'i ile aynı olamaz.'); return; }
    if(!fb && pwTaken(sifre)){ fail('Bu şifre başka birinde kullanılıyor, farklı bir şifre seçin.'); return; }
    const nu = { ad, tel, email: $id('inpEmail').value.trim(), gorev, bolge: $id('selBolge').value, blocked: $id('tglBlocked').classList.contains('on') };
    if(fb){ const btn = $id('btnEkleKullanici'); btn.disabled = true; const ok = await fbCreateStaff(nu, sifre); btn.disabled = false; if(!ok) return; }
    else nu.h = pwHash(sifre);
    staffUsers.push(nu);
    ['inpAdSoyad', 'inpEmail', 'inpTelefon', 'inpSifre'].forEach(i => { $id(i).value = ''; });
    $id('tglBlocked').classList.remove('on'); $id('tglBlocked').classList.add('off');
    renderUsers(); saveState();
    showToast('Kullanıcı eklendi: ' + ad + (RT.local ? ' (yerel mod: yalnızca bu cihazda geçerli)' : ' — isim + şifre ile giriş yapabilir'));
  });

  // ---- yetki tablosu ----
  function renderPerms(){
    const gt = 'grid-template-columns:1fr repeat(6,62px)';
    let h = '<div class="perm-group-head" style="' + gt + '"><div>Yönetici PIN ile giren her zaman tüm yetkilere sahiptir</div>' + ROLES.map(r => '<div style="text-align:center;font-size:.7rem;">' + esc(r) + '</div>').join('') + '</div>';
    PERM_DEFS.forEach(d => {
      h += '<div class="perm-row" style="' + gt + '"><div class="desc"><b>' + esc(d[1]) + '</b><span>' + esc(d[2]) + '</span></div>' +
        ROLES.map((r, i) => '<div class="chk' + (perms[d[0]][i] ? ' on' : '') + '" data-p="' + d[0] + '" data-r="' + i + '">' + (perms[d[0]][i] ? '✓' : '') + '</div>').join('') + '</div>';
    });
    $id('permBox').innerHTML = h + '<div style="padding:14px 20px;"><span class="link-btn" id="btnPermReset">↺ Varsayılana döndür</span></div>';
  }
  $id('permBox').addEventListener('click', async e => {
    if(!can('users')) return;
    if(e.target.id === 'btnPermReset'){ if(await uiConfirm('Tüm yetkiler varsayılana dönsün mü?')){ perms = defaultPerms(); renderPerms(); applyPerms(); saveState(); } return; }
    const c = e.target.closest('.chk'); if(!c || !c.dataset.p) return;
    const p = c.dataset.p, r = +c.dataset.r; perms[p][r] = perms[p][r] ? 0 : 1; renderPerms(); applyPerms(); saveState();
  });

  // ---- fiş yazdırma ----
  function printReceipt(){
    const key = currentCartKey, cart = carts[key] || [];
    if(!cart.length){ showToast('Yazdırılacak ürün yok.'); return; }
    const g = grossTotal(key), t = cartTotal(key), paid = paidByKey[key] || 0;
    let h = '<div style="text-align:center;font-weight:700;font-size:15px;">' + esc(settings.restName) + '</div><div style="text-align:center;">' + esc(orderLabel(key)) + '</div>' +
      '<div style="text-align:center;">Adisyon #' + (adisyonNoByKey[key] || '—') + ' · ' + new Date().toLocaleString('tr-TR') + '</div>' + ((byNames(cart).length || uname()) ? '<div style="text-align:center;">Personel: ' + esc((byNames(cart).length ? byNames(cart) : [uname()]).join(', ')) + '</div>' : '') + '<hr>' +
      '<table style="width:100%;border-collapse:collapse;">' + cart.map(i => '<tr><td>' + i.qty + ' x ' + esc(i.name) + (i.note ? '<br><small>↳ ' + esc(i.note) + '</small>' : '') + (i.by && byNames(cart).length > 1 ? '<br><small>(' + esc(i.by) + ')</small>' : '') + '</td><td style="text-align:right;vertical-align:top;">' + fmtTL(i.unit * i.qty) + '</td></tr>').join('') + '</table><hr>';
    if(t !== g) h += '<div>Ara toplam: <span style="float:right">' + fmtTL(g) + '</span></div><div>İndirim: <span style="float:right">-' + fmtTL(g - t) + '</span></div>';
    h += '<div style="font-weight:700;font-size:14px;">TOPLAM <span style="float:right">' + fmtTL(t) + '</span></div>';
    if(paid > 0) h += '<div>Ödenen: <span style="float:right">' + fmtTL(paid) + '</span></div><div>Kalan: <span style="float:right">' + fmtTL(Math.max(0, t - paid)) + '</span></div>';
    h += '<hr><div style="text-align:center;">Afiyet olsun!</div><div style="text-align:center;font-size:10px;">Mali değeri yoktur</div>';
    $id('printArea').innerHTML = h; document.body.classList.add('rcpt');
    const done = () => { document.body.classList.remove('rcpt'); window.removeEventListener('afterprint', done); };
    window.addEventListener('afterprint', done); setTimeout(() => window.print(), 50); setTimeout(done, 60000);
  }

  // ---- gün sonu ek bilgileri ----
  const todayWaives = () => { const s = dayStart(); return waiveLog.filter(p => p.ts >= s); };
  const todayCols = () => { const s = dayStart(); return colLog.filter(p => p.ts >= s); };
  function todayKdv(){
    let k = 0;
    todaySales().forEach(s => { const r = s.gross > 0 ? s.total / s.gross : 1; s.items.forEach(i => { k += i.qty * i.unit * r * (i.kdv || 0) / (100 + (i.kdv || 0)); }); });
    return Math.round(k * 100) / 100;
  }
  function todayExpense(){ return giderler.filter(g => g.date === new Date().toLocaleDateString('tr-TR')).reduce((s, g) => s + g.amount, 0); }
  function renderGunSonuExtra(){
    const wv = todayWaives().reduce((s, p) => s + p.amount, 0), kdv = todayKdv(), exp = todayExpense(), col = todayCols().reduce((s, p) => s + p.amount, 0);
    $id('gsOpen').textContent = money(dailyStats.openTotal || 0); $id('gsWaive').textContent = money(wv); $id('gsKdv').textContent = money(kdv);
    $id('gsExp').textContent = money(exp); $id('gsCol').textContent = money(col); $id('gsNet').textContent = money(dailyStats.sales - (dailyStats.openTotal || 0) - exp);
    $id('repDays').innerHTML = dayReports.length ? dayReports.slice(0, 30).map(d => '<div class="prow"><span class="pic">📅</span><div class="pmain"><b>' + new Date(d.ts).toLocaleDateString('tr-TR') + ' ' + hhmm(d.ts) + '</b><span>Nakit ' + money(d.cash) + ' · Kart/Diğer ' + money(d.card) + ' · Açık hesap ' + money(d.open) + ' · ' + d.orders + ' adisyon · ' + d.guests + ' misafir · Gider ' + money(d.expense) + ' · KDV ' + money(d.kdv) + '</span></div><span class="pval">' + money(d.sales) + '</span></div>').join('') : '<p style="color:var(--ink-faint);padding:8px;">Henüz kapatılmış gün yok.</p>';
  }
  async function closeDay(){
    recomputeStats();
    const open = Object.keys(carts).filter(k => (carts[k] || []).length).length;
    if(!await uiConfirm((open ? '⚠ ' + open + ' açık adisyon var; kapanmayacak, yeni güne devredecek.\n' : '') + 'Gün kapatılsın mı? Bugünkü toplamlar arşive alınıp sıfırlanacak.')) return;
    dayReports.unshift({ ts: Date.now(), sales: dailyStats.sales, cash: dailyStats.cashTotal, card: dailyStats.cardTotal, open: dailyStats.openTotal || 0, guests: dailyStats.guests, orders: todaySales().length, expense: todayExpense(), kdv: todayKdv() });
    dayReports = dayReports.slice(0, 120); closedAt = Date.now();
    updateHomeStats(); renderGunSonu(); saveState(); showToast('Gün kapatıldı, rapor arşive alındı.');
  }
  $id('btnCloseDay').addEventListener('click', closeDay);

  // ---- mobil menü ----
  $id('btnMenu').addEventListener('click', e => { e.stopPropagation(); $id('sidebar').classList.toggle('open'); });
  document.querySelector('.main').addEventListener('click', () => $id('sidebar').classList.remove('open'));

  renderLogos();
  // ======================================================================
  // PROFESYONEL EKLER — kalıcı kayıt, canlı eşitleme, gerçek raporlar
  // ======================================================================
  const STORE_KEY = 'posAppV2', THEME_KEY = 'posTheme', DEV = 'd' + Math.random().toString(36).slice(2, 8);
  let lastSaved = '', lastSavedAt = 0, storageOK = true, warned = false;
  const LISTKEYS = ['birimler', 'ozellikler', 'kdv', 'indirimler', 'odenmezler', 'zayi'];
  function money(v){ return '₺' + v.toLocaleString('tr-TR', { minimumFractionDigits: 2 }); }

  function seedLists(){
    LISTKEYS.forEach(k => {
      lists[k] = [...document.querySelectorAll('#screen-' + k + ' .plist .prow')].map(r => ({
        name: (r.querySelector('b') || {}).textContent || '', sub: (r.querySelector('.pmain span') || {}).textContent || '', val: (r.querySelector('.pval') || {}).textContent || '' }));
    });
    lists.zayi = [];
  }
  function seedPay(){
    payTypes = [...document.querySelectorAll('#tab-odeme .toggle-row')].map(r => ({ name: r.querySelector('.pay-name').textContent.trim(), on: r.querySelector('.mini-toggle').classList.contains('on') }));
  }
  function readSettings(){
    if(!uiReady) return;
    const t = id => $id(id).textContent.trim();
    settings.restName = t('setRestName') || settings.restName;
    settings.dayStart = /^\d{1,2}:\d{2}$/.test(t('setDayStart')) ? t('setDayStart') : '05:00';
    settings.firstOrderNo = t('setFirstOrderNo') || '101';
    settings.shiftSplit = /^\d{1,2}:\d{2}$/.test(t('setShift')) ? t('setShift') : '15:00';
    settings.wifiName = t('setWifiName'); settings.wifiPass = t('setWifiPass');
    const wt = $id('wifiOnTgl'); if(wt) settings.wifiOn = wt.classList.contains('on'); try{ readBrand(); }catch(e){}
    const sr = $id('socRows'); if(sr){ const inps = sr.querySelectorAll('[data-soc-v]'); if(inps.length){ const st = {}; inps.forEach(inp => { const k = inp.dataset.socV, tg = sr.querySelector('[data-soc-t="' + k + '"]'); st[k] = { on: !!(tg && tg.classList.contains('on')), v: inp.value.trim().replace(/^@+/, '') }; }); settings.social = st; } }
  }
  function applySettings(){
    $id('setRestName').textContent = settings.restName; $id('restName').value = settings.restName;
    $id('setDayStart').textContent = settings.dayStart; $id('setFirstOrderNo').textContent = settings.firstOrderNo;
    $id('setPin').value = ''; $id('setShift').textContent = settings.shiftSplit || '15:00';
    $id('setWifiName').textContent = settings.wifiName || ''; $id('setWifiPass').textContent = settings.wifiPass || ''; try{ applySocialUI(); }catch(e){} try{ applyBrandUI(); }catch(e){}
    document.title = settings.restName || APP_CONFIG.brand.name; uiReady = true;
  }
  $id('restName').addEventListener('input', e => { $id('setRestName').textContent = e.target.value; });

  // ---- tarih / günlük hesaplar (tümü kayıtlardan türetilir, sayaç tutulmaz) ----
  function dayStart(){
    const [h, m] = (settings.dayStart || '05:00').split(':').map(Number);
    const d = new Date(); d.setHours(h || 0, m || 0, 0, 0); if(d > new Date()) d.setDate(d.getDate() - 1);
    return Math.max(d.getTime(), closedAt || 0);
  }
  function todayPays(){ const s = dayStart(); return payLog.filter(p => p && p.ts >= s); }
  function todaySales(){ const s = dayStart(); return saleLog.filter(p => p.ts >= s); }
  function recomputeStats(){
    const P = todayPays();
    dailyStats.sales = P.reduce((a, p) => a + p.amount, 0);
    dailyStats.cashTotal = P.filter(p => p.method === 'Nakit').reduce((a, p) => a + p.amount, 0);
    dailyStats.openTotal = P.filter(p => p.method === 'Açık Hesap').reduce((a, p) => a + p.amount, 0);
    dailyStats.cardTotal = dailyStats.sales - dailyStats.cashTotal - dailyStats.openTotal;
    dailyStats.guests = todaySales().reduce((a, x) => a + x.guests, 0);
  }
  function renderReports(){
    const S = todaySales(), P = todayPays();
    const m = {}; rangeSales().forEach(x => x.items.forEach(i => { const o = m[i.name] || (m[i.name] = { q: 0, t: 0 }); o.q += i.qty; o.t += i.qty * i.unit; }));
    const e = Object.entries(m).sort((a, b) => b[1].t - a[1].t), mx = Math.max(1, ...e.map(x => x[1].t));
    $id('repUrun').innerHTML = e.length ? e.map(([k, v]) => '<div class="bar-row"><div class="bname">' + esc(k) + ' ×' + v.q + '</div><div class="btrack"><div class="bfill" style="width:' + (v.t / mx * 100) + '%"></div></div><div class="bval">' + money(v.t) + '</div></div>').join('') : '<p style="color:var(--ink-faint);padding:8px;">Bugün satış yok.</p>';
    const sum = a => a.reduce((x, p) => x + p.amount, 0), mor = P.filter(p => { const d = new Date(p.ts), mn = d.getHours() * 60 + d.getMinutes(); return mn >= shiftMin('dayStart') && mn < shiftMin('shiftSplit'); });
    $id('vSabahLbl').textContent = 'Gün başlangıcı – ' + (settings.shiftSplit || '15:00'); $id('vAksamLbl').textContent = (settings.shiftSplit || '15:00') + ' – gün sonu'; $id('vSabah').textContent = money(sum(mor)); $id('vAksam').textContent = money(sum(P) - sum(mor));
    const hrs = {}; P.forEach(p => { const h = new Date(p.ts).getHours(); hrs[h] = (hrs[h] || 0) + 1; });
    const bh = Object.entries(hrs).sort((a, b) => b[1] - a[1])[0];
    $id('stHour').textContent = bh ? bh[0].padStart(2, '0') + ':00–' + String((+bh[0] + 1) % 24).padStart(2, '0') + ':00' : '—';
    const mt = {}; S.forEach(x => x.items.forEach(i => { mt[i.name] = (mt[i.name] || 0) + i.qty; })); const tp = Object.entries(mt).sort((a, b) => b[1] - a[1])[0]; $id('stTop').textContent = tp ? tp[0] : '—';
    $id('stAvg').textContent = money(S.length ? S.reduce((x, y) => x + y.total, 0) / S.length : 0);
    $id('stGuests').textContent = String(dailyStats.guests);
    const ps = {}; rangeSales().forEach(x => x.items.forEach(i => { const k = i.by || x.user || 'Belirtilmemiş', o = ps[k] || (ps[k] = { q: 0, t: 0 }); o.q += i.qty; o.t += i.qty * i.unit; }));
    const pe = Object.entries(ps).sort((a, b) => b[1].t - a[1].t), pm = Math.max(1, ...pe.map(x => x[1].t));
    $id('repUser').innerHTML = pe.length ? pe.map(([k, v]) => '<div class="bar-row"><div class="bname">👤 ' + esc(k) + ' · ' + v.q + ' ürün</div><div class="btrack"><div class="bfill" style="width:' + (v.t / pm * 100) + '%"></div></div><div class="bval">' + money(v.t) + '</div></div>').join('') : '<p style="color:var(--ink-faint);padding:8px;">Satış yok.</p>';
    renderFire(); renderCancelLog();
  }

  // ---- tanım listeleri (Birimler, KDV, İndirimler...) ve ödeme tipleri, kullanıcılar ----
  function renderLists(){
    LISTKEYS.forEach(k => {
      const pl = document.querySelector('#screen-' + k + ' .plist'); if(!pl) return;
      pl.innerHTML = (lists[k] || []).map((r, i) => '<div class="prow"><span class="pic">•</span><div class="pmain"><b>' + esc(r.name) + '</b>' + (r.sub ? '<span>' + esc(r.sub) + '</span>' : '') + '</div>' + (r.val ? '<span class="pval">' + esc(r.val) + '</span>' : '') +
        (k === 'kdv' ? '<span class="link-btn" data-l="kdv" data-i="' + i + '" data-a="s" title="Varsayılan yap">★</span>' : '') + '<span class="link-btn" data-l="' + k + '" data-i="' + i + '" data-a="e">✎</span><span class="link-btn" data-l="' + k + '" data-i="' + i + '" data-a="d">🗑</span></div>').join('') || '<p style="color:var(--ink-faint);padding:8px;">Kayıt yok.</p>';
    });
  }
  function renderPayTypes(){
    const w = $id('tab-odeme'), add = $id('btnOdemeTipiEkle');
    w.querySelectorAll('.toggle-row').forEach(r => r.remove());
    payTypes.forEach((p, i) => {
      const r = document.createElement('div'); r.className = 'toggle-row';
      r.innerHTML = '<div class="mini-toggle ' + (p.on ? 'on' : 'off') + '"><span class="k"></span></div><div class="name pay-name">' + esc(p.name) + '</div><span class="link-btn" data-pi="' + i + '" data-a="e">✎</span><span class="link-btn" data-pi="' + i + '" data-a="d">🗑</span>';
      r.querySelector('.mini-toggle').addEventListener('click', () => { p.on = !p.on; renderPayTypes(); });
      add.insertAdjacentElement('beforebegin', r);
    });
  }
  document.addEventListener('click', async e => {
    let b = e.target.closest('[data-l]');
    if(b){
      const L = lists[b.dataset.l], i = +b.dataset.i;
      if(b.dataset.a === 'd'){ if(await uiConfirm('Silinsin mi?')){ L.splice(i, 1); renderLists(); renderReports(); } }
      else if(b.dataset.a === 's'){ L.forEach((r, j) => { r.val = j === i ? 'Varsayılan' : 'Varsayılan değil'; }); renderLists(); showToast(L[i].name + ' varsayılan KDV oldu.'); }
      else { const nm = await uiPrompt('Ad:', L[i].name); if(!nm) return; L[i].name = nm.trim(); const v = await uiPrompt('Değer / not:', L[i].val || ''); if(v !== null) L[i].val = v.trim(); renderLists(); renderReports(); }
      return;
    }
    b = e.target.closest('[data-pi]');
    if(b){
      const i = +b.dataset.pi;
      if(payTypes[i] && (payTypes[i].name === 'Nakit' || payTypes[i].name === 'Açık Hesap')){ showToast('Bu sistem ödeme tipidir; yalnızca açıp kapatabilirsiniz.'); return; }
      if(b.dataset.a === 'd'){ if(payTypes.length <= 1){ showToast('En az bir ödeme tipi kalmalı.'); return; } if(await uiConfirm('Ödeme tipi silinsin mi?')){ payTypes.splice(i, 1); renderPayTypes(); } }
      else { const nm = await uiPrompt('Ödeme tipi adı:', payTypes[i].name); if(nm){ payTypes[i].name = nm.trim(); renderPayTypes(); } }
      return;
    }
    b = e.target.closest('[data-ui]');
    if(b && await uiConfirm('Kullanıcı silinsin mi?')){ staffUsers.splice(+b.dataset.ui, 1); renderUsers(); }
  });
  document.querySelectorAll('.btn-add-item').forEach(btn => btn.addEventListener('click', async () => {
    const k = btn.closest('.screen').id.replace('screen-', '');
    if(k === 'zayi'){ zayiForm(); return; }
    const nm = await uiPrompt('Ad:'); if(!nm) return;
    const v = await uiPrompt('Değer / not (isteğe bağlı):', '') || '';
    lists[k].push({ name: nm.trim(), sub: k === 'zayi' ? new Date().toLocaleDateString('tr-TR') : '', val: v.trim() });
    renderLists(); renderReports(); showToast(nm + ' eklendi.');
  }));

  // ---- indirim, masa taşıma, iptal ----
  function parseDisc(t){
    t = String(t || '').trim(); const n = parseFloat(t.replace(/[^\d,.]/g, '').replace(',', '.'));
    if(!(n > 0)) return null; return t.includes('%') ? { type: 'pct', v: Math.min(n, 100) } : { type: 'amt', v: n };
  }
  function fillDiscSel(){
    $id('ppDiscSel').innerHTML = '<option value="none">İndirim yok</option>' + (lists.indirimler || []).map((r, i) => '<option value="' + i + '">' + esc(r.name) + ' (' + esc(r.val) + ')</option>').join('') + '<option value="manual">Elle gir…</option>';
  }
  $id('btnDiscApply').addEventListener('click', async () => {
    const k = currentCartKey, v = $id('ppDiscSel').value; let d = null;
    if(v === 'manual') d = parseDisc(await uiPrompt('İndirim (örn. %10 veya 50):'));
    else if(v !== 'none') d = parseDisc((lists.indirimler[+v] || {}).val);
    if(v === 'none') delete discountByKey[k]; else if(d) discountByKey[k] = d; else { showToast('Geçerli bir indirim girilmedi.'); return; }
    afterOrderChange(); if((paidByKey[k] || 0) > 0 && remainingForKey(k) <= 0.005){ finalizeOrder(k, 'İndirim sonrası kalan tutar kalmadı.'); return; } renderPaymentPanel(); showToast(v === 'none' ? 'İndirim kaldırıldı.' : 'İndirim uygulandı. Yeni toplam: ' + money(cartTotal(k)));
  });
  $id('guestNo').addEventListener('input', e => { guestsByKey[currentCartKey] = Math.max(1, parseInt(e.target.value) || 1); });
  $id('btnCancelOrder').addEventListener('click', async () => {
    const k = currentCartKey;
    if(!(carts[k] || []).length){ showToast('Sepet zaten boş.'); return; }
    if(paidByKey[k]){ showToast('Ödeme alınmış adisyon iptal edilemez.'); return; }
    if(!await uiConfirm('Adisyon iptal edilsin mi? Tüm kalemler silinecek.')) return;
    carts[k] = []; delete discountByKey[k]; delete guestsByKey[k];
    afterOrderChange(); if(extOrders[k]) dropExt(k); showScreen(currentBackScreen); renderSiparisMasa(); showToast('Adisyon iptal edildi.');
  });
  // ---- masa müşteri adı ----
  function renameGuest(){
    const k = currentCartKey; if(!k || !k.startsWith('table_')) return;
    if(!can('orders')){ showToast('Yetkiniz yok.'); return; }
    const n = +k.slice(6);
    openForm({ title: 'Masa adı — ' + (tableLabels[n] || ('Masa ' + n)), sub: 'Müşteri adını yazın. Boş bırakırsanız masa kendi adına döner. Hesap kapanınca veya masa taşınınca ad otomatik sıfırlanır.',
      fields: [{ id: 'n', label: 'Müşteri adı', value: tableGuest[n] || '', placeholder: 'ör. Ahmet Bey' }],
      onOk(v){ if(v.n.length > 30) return 'En fazla 30 karakter.'; if(v.n) tableGuest[n] = v.n; else delete tableGuest[n];
        const t = orderLabel(k); $id('orderTableTitle').textContent = t; $id('mpTitle').textContent = '🍽️ ' + t;
        renderTableGrid(); renderSiparisMasa(); saveState(); } });
  }
  $id('btnRenameTable').addEventListener('click', renameGuest);
  $id('mpRename').addEventListener('click', renameGuest);

  // ---- ürün / adisyon taşıma ----
  function pickTargetTable(fromKey, cb){
    const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 1100;
    const box = document.createElement('div'); box.className = 'modal-box';
    box.innerHTML = '<div style="display:flex;align-items:center"><h3 style="margin:0;flex:1">Hangi masaya taşınsın?</h3><span id="mvX" style="cursor:pointer;font-size:20px">✕</span></div>' +
      regions.map((r, ri) => '<div class="mv-region">' + esc(r.name) + '</div><div class="mv-grid">' + r.tables.map(n => {
        const k = 'table_' + n, busy = (carts[k] || []).length > 0, self = k === fromKey;
        return '<button data-n="' + n + '" class="' + (busy ? 'busy' : '') + '"' + (self ? ' disabled' : '') + '>' + cellName(n) + '<small>' + (self ? 'Bu masa' : busy ? 'DOLU · ' + fmtTL(cartTotal(k)) : 'Boş') + '</small></button>';
      }).join('') + '</div>').join('');
    document.body.appendChild(bg); bg.appendChild(box);
    const close = () => bg.remove();
    box.querySelector('#mvX').onclick = close; bg.addEventListener('mousedown', e => { if(e.target === bg) close(); });
    box.addEventListener('click', e => { const b = e.target.closest('button[data-n]'); if(!b || b.disabled) return; close(); cb(+b.dataset.n); });
  }
  async function doMove(k, picks, t){
    const tk = 'table_' + t, srcN = +k.slice(6), tlabel = tname(t);
    const busy = (carts[tk] || []).length > 0;
    if(busy && !await uiConfirm('⚠️ DİKKAT: ' + tlabel + ' şu anda DOLU (' + fmtTL(cartTotal(tk)) + ' açık adisyon var).\n\nSeçilen ürünler bu masanın mevcut adisyonuna EKLENECEK. Devam edilsin mi?')) return;
    carts[tk] = carts[tk] || [];
    picks.forEach(p => {
      const item = p.item, qty = Math.min(p.qty, item.qty), keepSent = Math.min(item.sent || 0, item.qty - qty), movedSent = (item.sent || 0) - keepSent;
      const x = carts[tk].find(y => y.name === item.name && y.unit === item.unit && (y.note || '') === (item.note || ''));
      if(x){ x.qty += qty; x.sent = (x.sent || 0) + movedSent; } else carts[tk].push(Object.assign({}, item, { qty, sent: movedSent }));
      item.qty -= qty; item.sent = keepSent;
    });
    carts[k] = carts[k].filter(i => i.qty > 0);
    if(!orderOpenedAt[tk]) orderOpenedAt[tk] = orderOpenedAt[k] || Date.now();
    if(!carts[k].length){
      paidByKey[tk] = (paidByKey[tk] || 0) + (paidByKey[k] || 0);
      paymentHistoryByKey[tk] = (paymentHistoryByKey[tk] || []).concat(paymentHistoryByKey[k] || []);
      [paidByKey, paymentHistoryByKey, discountByKey, orderOpenedAt, adisyonNoByKey, guestsByKey].forEach(o => delete o[k]);
      delete tableGuest[srcN]; // eski masa kendi adına döner
    }
    mvSel.clear();
    const moved = picks.reduce((s, p) => s + Math.min(p.qty, 1e9), 0);
    if(!carts[k].length){ openOrder(tk, orderLabel(tk), currentBackScreen); } else { renderOrderLines(); }
    afterOrderChange(); showToast('Ürünler ' + tlabel + ' masasına taşındı' + (busy ? ' (dolu masaya eklendi).' : '.'));
  }
  $id('btnMoveTable').addEventListener('click', () => openMoveDialog(null));

  // ---- dijital menü: gerçek QR ----
  function renderDigitalMenu(){
    const sel = $id('qrMasa'), cur = sel.value, tb = regions.flatMap(r => r.tables);
    sel.innerHTML = tb.map(n => '<option value="' + n + '">' + esc(tableLabels[n] || 'Masa ' + n) + '</option>').join('');
    if(cur) sel.value = cur;
    const url = location.href.split('#')[0].split('?')[0] + '?' + (window.__cfgId ? 'i=' + window.__cfgId + '&' : '') + 'masa=' + sel.value;
    $id('qrLink').textContent = (location.protocol === 'file:' ? '⚠ Dosya bilgisayardan açık: QR’ın telefonda çalışması için siteyi internete yükleyin. ' : '') + url;
    $id('qrOut').innerHTML = '';
    if(window.QRCode && sel.value) new QRCode($id('qrOut'), { text: url, width: 180, height: 180 });
    $id('dmCats').innerHTML = categories.map(c => '<div class="prow"><span class="pic">' + esc(c.icon || '🍴') + '</span><div class="pmain"><b>' + esc(c.name) + '</b><span>' + c.products.length + ' ürün</span></div><span class="pval tag">Yayında</span></div>').join('');
  }
  $id('qrMasa').addEventListener('change', renderDigitalMenu);

  // ---- müşteri listesi dışa aktarma ----
  function downloadNow(name, text, type){
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + text], { type: type || 'text/csv' }));
    a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }
  // ---- CSV indirme: önce önizleme, onaydan sonra indir ----
  function csvParse(text){
    const first = (text.split('\n')[0] || '');
    const d = (first.indexOf('";"') > -1 || (first.indexOf(';') > -1 && first.indexOf('","') < 0)) ? ';' : ',';
    const rows = []; let row = [], cur = '', q = false;
    for(let k = 0; k < text.length; k++){
      const ch = text[k];
      if(q){ if(ch === '"'){ if(text[k + 1] === '"'){ cur += '"'; k++; } else q = false; } else cur += ch; }
      else if(ch === '"') q = true;
      else if(ch === d){ row.push(cur); cur = ''; }
      else if(ch === '\n'){ row.push(cur); rows.push(row); row = []; cur = ''; }
      else if(ch !== '\r') cur += ch;
    }
    if(cur !== '' || row.length){ row.push(cur); rows.push(row); }
    return rows.filter(r => r.some(c => c !== ''));
  }
  function csvPreview(name, text, type){
    const old = document.getElementById('csvPv'); if(old) old.remove();
    const rows = csvParse(text), head = rows[0] || [], body = rows.slice(1), MAX = 100;
    const bg = document.createElement('div'); bg.id = 'csvPv'; bg.className = 'csvpv-bg';
    bg.setAttribute('role', 'dialog'); bg.setAttribute('aria-modal', 'true'); bg.setAttribute('aria-label', 'İndirme önizlemesi');
    const card = document.createElement('div'); card.className = 'csvpv';
    const h = document.createElement('div'); h.className = 'csvpv-h';
    const t = document.createElement('h2'); t.textContent = 'İndirme önizlemesi';
    const sub = document.createElement('p');
    sub.textContent = name + ' · ' + body.length + ' satır · ' + head.length + ' sütun';
    h.append(t, sub);
    const wrap = document.createElement('div'); wrap.className = 'csvpv-t';
    if(body.length){
      const tb = document.createElement('table'), th = document.createElement('thead'), tr = document.createElement('tr');
      head.forEach(c => { const x = document.createElement('th'); x.textContent = c; tr.appendChild(x); });
      th.appendChild(tr); tb.appendChild(th);
      const bd = document.createElement('tbody');
      body.slice(0, MAX).forEach(r => { const y = document.createElement('tr'); head.forEach((_, c) => { const x = document.createElement('td'); x.textContent = r[c] == null ? '' : r[c]; y.appendChild(x); }); bd.appendChild(y); });
      tb.appendChild(bd); wrap.appendChild(tb);
    } else {
      const e = document.createElement('div'); e.className = 'csvpv-e'; e.textContent = 'Bu rapor için seçili aralıkta satır yok. Dosya yalnızca başlıkları içerecek.'; wrap.appendChild(e);
    }
    const note = document.createElement('div'); note.className = 'csvpv-n';
    note.textContent = body.length > MAX ? 'İlk ' + MAX + ' satır gösteriliyor; dosyaya ' + body.length + ' satırın tamamı yazılır.' : '';
    const bar = document.createElement('div'); bar.className = 'csvpv-b';
    const no = document.createElement('button'); no.type = 'button'; no.className = 'csvpv-no'; no.textContent = 'Vazgeç';
    const ok = document.createElement('button'); ok.type = 'button'; ok.className = 'csvpv-ok'; ok.textContent = 'CSV\u2019yi indir';
    bar.append(no, ok);
    card.append(h, wrap, note, bar); bg.appendChild(card); document.body.appendChild(bg);
    const close = () => { bg.remove(); document.removeEventListener('keydown', onKey); };
    const onKey = ev => { if(ev.key === 'Escape') close(); };
    document.addEventListener('keydown', onKey);
    no.addEventListener('click', close);
    bg.addEventListener('click', ev => { if(ev.target === bg) close(); });
    ok.addEventListener('click', () => { close(); downloadNow(name, text, type); if(typeof showToast === 'function') showToast(name + ' indirildi.'); });
    ok.focus();
  }
  function downloadFile(name, text, type){
    if(/\.csv$/i.test(name)) csvPreview(name, text, type); else downloadNow(name, text, type);
  }
  $id('btnMusteriIndir').addEventListener('click', () => downloadFile('musteriler.csv',
    ['No;Ad Soyad;Telefon;Adres;Açık Hesap;Bakiye'].concat(customers.map(c => [c.no, c.name, c.phone, c.address, c.acikHesap ? 'Evet' : 'Hayır', c.balance].join(';'))).join('\n')));

  // ---- durum kaydı, yedek, canlı eşitleme ----
  // ---- yönetici özel verisi: ciro / ödeme / gider / rapor kayıtları ----
  // Firebase modunda bu veriler 'state' içine KONMAZ. Yalnızca yönetici cihazında ve yalnızca yönetici hesabının okuyabildiği 'adminState' yolunda tutulur.
  // Personel cihazları satış/ödeme kaydını 'inbox' kutusuna bırakır (yazılır, okunamaz); yönetici cihazı alıp kendi kaydına işler.
  const PRIV_KEYS = ['saleLog', 'payLog', 'giderler', 'dayReports', 'closedAt', 'colLog', 'waiveLog', 'cancelLog'];
  const adminDev = () => RT.local || !!(RT.isAdmin && RT.isAdmin());
  let adminReady = false, lastPriv = '', lastPrivAt = 0;
  function privGet(k){ return ({ saleLog, payLog, giderler, dayReports, colLog, waiveLog, cancelLog })[k]; }
  function privSet(k, v){
    if(Array.isArray(v)) v = v.filter(x => x != null);
    switch(k){
      case 'saleLog': saleLog = v; break; case 'payLog': payLog = v; break; case 'giderler': giderler = v; break; case 'dayReports': dayReports = v; break;
      case 'colLog': colLog = v; break; case 'waiveLog': waiveLog = v; break; case 'cancelLog': cancelLog = v; break; case 'closedAt': closedAt = v; break;
    }
  }
  function privObj(){ const o = {}; PRIV_KEYS.forEach(k => { o[k] = k === 'closedAt' ? closedAt : privGet(k); }); return o; }
  function logPriv(k, e){
    if(adminDev()){ if(k === 'cancelLog') cancelLog.unshift(e); else privGet(k).push(e); return; }
    try{ RT.push('inbox', { k, v: JSON.parse(JSON.stringify(e)), ts: Date.now() }); }catch(_){}
  }
  function mergeInbox(v){
    if(!v || !adminDev()) return;
    const ids = Object.keys(v), touched = new Set();
    ids.forEach(id => {
      const e = v[id]; if(!e || typeof e !== 'object' || !e.v || ['saleLog', 'payLog', 'waiveLog', 'colLog', 'cancelLog'].indexOf(e.k) < 0) return;
      const a = privGet(e.k); if(a.some(x => x && x.iid === id)) return;
      a.push(Object.assign({}, e.v, { iid: id })); touched.add(e.k);
    });
    if(touched.size){
      touched.forEach(k => privGet(k).sort((a, b) => k === 'cancelLog' ? (b.ts || 0) - (a.ts || 0) : (a.ts || 0) - (b.ts || 0)));
      try{ updateHomeStats(); renderGunSonu(); }catch(e){}
      lastSaved = ''; saveState();
    }
    ids.forEach(id => { try{ Promise.resolve(RT.remove('inbox/' + id)).catch(() => {}); }catch(_){} });
  }
  function snapshot(){
    readSettings();
    return { carts, tableLabels, tableGuest, regions, nextTableNo, orderOpenedAt, categories, groupMeta, menuVer: MENU_VER, paidByKey, paymentHistoryByKey, customers, giderler, mutfakGruplari, adisyonSeq, adisyonNoByKey,
      lists, payTypes, payLog, saleLog, closedAt, guestsByKey, discountByKey, extOrders, extSeq, perms, waiveLog, colLog, dayReports, cancelLog, settings: Object.assign({}, settings, { pin: undefined, supPin: undefined }) };
  }
  const localExtra = () => ({ staffUsers, pin: settings.pin });
  function fullStr(){ return JSON.stringify(Object.assign({}, snapshot(), localExtra())); }
  function updateSysStatus(){
    const el = document.getElementById('sysStatus'); if(!el) return;
    el.textContent = (storageOK ? '✔ Tarayıcıya otomatik kayıt çalışıyor' : '✖ Kayıt YAPILAMIYOR (tarayıcı depolaması kapalı) — Yedeği İndir kullanın') + ' · ' + (RT.local ? 'Yerel mod (Firebase ayarlı değil: diğer cihazlarla canlı eşleşme yok)' : 'Canlı bağlantı aktif');
  }
  function saveState(){
    const full = fullStr(); if(full === lastSaved) return; lastSaved = full;
    const savedAt = Date.now(); lastSavedAt = savedAt;
    const base = Object.assign(JSON.parse(full), { savedAt, dev: DEV }), adm = adminDev();
    if(!adm) PRIV_KEYS.forEach(k => { delete base[k]; });   // personel cihazında yönetici verisi (ciro, gider…) tutulmaz
    try{ localStorage.setItem(STORE_KEY, JSON.stringify(base)); storageOK = true; }catch(e){ storageOK = false; if(!warned){ warned = true; showToast('⚠ Veriler kaydedilemiyor! Ayarlar > Yedek & Sistem’den yedek alın.'); } }
    if(!RT.local && staffMode){
      delete base.staffUsers; delete base.pin;
      const priv = {}; PRIV_KEYS.forEach(k => { if(k in base){ priv[k] = base[k]; delete base[k]; } });
      try{ RT.set('state', base); }catch(e){}
      if(adm && adminReady){ const ps = JSON.stringify(priv); if(ps !== lastPriv){ lastPriv = ps; lastPrivAt = savedAt; try{ RT.set('adminState', Object.assign(priv, { savedAt, dev: DEV })); }catch(e){} } }
    }
    try{ syncStaffDir(); }catch(e){ console.error(e); }
  }
  function applyState(s, persist){
    if(!s || typeof s !== 'object') return;
    const fill = (t, d) => { Object.keys(t).forEach(k => delete t[k]); Object.assign(t, d && typeof d === 'object' ? d : {}); };
    fill(carts, s.carts); fill(tableLabels, s.tableLabels); fill(tableGuest, s.tableGuest); fill(orderOpenedAt, s.orderOpenedAt); fill(adisyonNoByKey, s.adisyonNoByKey); fill(discountByKey, s.discountByKey); fill(guestsByKey, s.guestsByKey);
    if(Array.isArray(s.regions) && s.regions.length) regions = s.regions.filter(x => x != null);
    if(Array.isArray(s.categories) && s.categories.length) categories = s.categories.filter(x => x != null);
    stripOldImgs(categories);
    let seeded = false; if(!(s.categories && s.categories.length)){ categories = buildSeedMenu(); seeded = true; }
    groupMeta = seeded ? [] : normGM(s.groupMeta);
    if(s.nextTableNo) nextTableNo = s.nextTableNo;
    paidByKey = s.paidByKey || {}; paymentHistoryByKey = s.paymentHistoryByKey || {};
    if(Array.isArray(s.customers)) customers = s.customers.filter(x => x != null);
    if(Array.isArray(s.mutfakGruplari) && s.mutfakGruplari.length) mutfakGruplari = s.mutfakGruplari;
    if(seeded) ensureSeedGroups();
    adisyonSeq = s.adisyonSeq || 0;
    if(s.lists) LISTKEYS.forEach(k => { if(Array.isArray(s.lists[k])) lists[k] = s.lists[k]; });
    if(Array.isArray(s.payTypes) && s.payTypes.length) payTypes = s.payTypes;
    if(s.settings) Object.assign(settings, s.settings);
    if(Array.isArray(s.staffUsers)) staffUsers = s.staffUsers.filter(x => x != null);
    if(s.pin) settings.pin = s.pin;
    extOrders = (s.extOrders && typeof s.extOrders === 'object') ? s.extOrders : {}; extSeq = s.extSeq || 0;
    perms = normPerms(s.perms);
    if(adminDev()){ PRIV_KEYS.forEach(k => { if(s[k] !== undefined) privSet(k, k === 'closedAt' ? (+s[k] || 0) : (Array.isArray(s[k]) ? s[k] : [])); }); }
    else PRIV_KEYS.forEach(k => privSet(k, k === 'closedAt' ? 0 : []));
    ['paket', 'gelal'].forEach(t => {
      if(carts[t] && carts[t].length){ const key = t + '_' + (++extSeq); extOrders[key] = { type: t, name: 'Eski sipariş', phone: '', address: '', st: 'hazirlaniyor', created: Date.now(), by: '' }; carts[key] = carts[t]; }
      delete carts[t];
    });
    Object.keys(extOrders).forEach(k => { if(!carts[k]) carts[k] = []; });
    ensurePayTypes();
    regions.forEach(r => r.tables.forEach(n => { if(!carts['table_' + n]) carts['table_' + n] = []; if(!tableLabels[n]) tableLabels[n] = 'Masa ' + n; }));
    activeRegion = Math.min(activeRegion, regions.length - 1); smActiveRegion = Math.min(smActiveRegion, regions.length - 1);
    activeCatIndex = Math.min(activeCatIndex, categories.length - 1); mpActiveCat = 0;
    lastSavedAt = Math.max(lastSavedAt, s.savedAt || 0);
    uiReady = false; applySettings(); lastSaved = fullStr();
    if(persist){ try{ localStorage.setItem(STORE_KEY, JSON.stringify(Object.assign(JSON.parse(lastSaved), { savedAt: s.savedAt || Date.now(), dev: s.dev || DEV }))); }catch(e){} }
    renderAll();
    if(seeded) setTimeout(() => { lastSaved = ''; saveState(); }, 50);
  }
  function renderAll(){
    renderRegionTabs(); renderTableGrid(); renderSiparisMasa(); renderCatList(); renderProductGrid(); renderMutfakRows(); renderCustomers(); renderGiderler();
    renderLists(); renderPayTypes(); renderUsers(); if(!uiReady) applySettings(); updateHomeStats(); renderGunSonu();
    if(carts[currentCartKey] && $id('screen-order').classList.contains('show')) renderOrderLines();
    if($id('screen-digitalmenu').classList.contains('show')) renderDigitalMenu();
    try{ renderPaketler(); renderMutfakRows(); renderKitchen(); fillBolge(); renderPerms(); if(staffMode) applyPerms(); }catch(e){ console.error(e); }
    updateSysStatus(); try{ renderMenuOnlyBtn(); }catch(e){}
  }
  function startStateSync(){
    if(RT.local) return;
    holdImgs = true; renderAll();
    const rel = () => { if(!holdImgs) return; holdImgs = false; renderAll(); };
    setTimeout(rel, 2500);
    RT.on('state', v => {
      if(!v){ lastSaved = ''; saveState(); rel(); return; }
      if(v.dev !== DEV && (v.savedAt || 0) > lastSavedAt) applyState(v, true);
      rel();
    });
    if(adminDev()){
      let lastInbox = null;
      RT.on('adminState', v => {
        let apply = false;
        if(v && v.dev !== DEV && (v.savedAt || 0) > lastPrivAt){
          PRIV_KEYS.forEach(k => privSet(k, k === 'closedAt' ? (+v[k] || 0) : (Array.isArray(v[k]) ? v[k] : [])));
          lastPrivAt = v.savedAt || 0; lastPriv = JSON.stringify(privObj()); apply = true;
          try{ updateHomeStats(); renderGunSonu(); renderGiderler(); }catch(e){}
        }
        const first = !adminReady; if(first){ adminReady = true; if(!v) lastPriv = ''; }
        if(first || apply){ lastSaved = ''; saveState(); }
        if(lastInbox) mergeInbox(lastInbox);
      });
      RT.on('inbox', v => { lastInbox = v; if(adminReady) mergeInbox(v); });
    }
  }
  window.addEventListener('storage', e => { if(e.key === window.__nsk(STORE_KEY) && e.newValue){ try{ applyState(JSON.parse(e.newValue), false); }catch(err){} } });
  $id('btnBackup').addEventListener('click', () => downloadFile('pos-yedek-' + new Date().toISOString().slice(0, 10) + '.json', JSON.stringify(Object.assign(JSON.parse(fullStr()), { savedAt: Date.now() })), 'application/json'));
  $id('btnRestore').addEventListener('click', () => $id('restoreFile').click());
  $id('restoreFile').addEventListener('change', e => {
    const f = e.target.files[0]; if(!f) return;
    const r = new FileReader();
    r.onload = async () => {
      try{
        const s = JSON.parse(r.result); if(!s.carts || !s.regions) throw 0;
        if(!await uiConfirm('Mevcut veriler bu yedekle değiştirilsin mi?')) return;
        s.savedAt = Date.now(); s.dev = DEV; applyState(s, true); lastSaved = ''; saveState(); showToast('Yedek yüklendi.');
      }catch(err){ showToast('Geçersiz yedek dosyası.'); }
    };
    r.readAsText(f); e.target.value = '';
  });
  $id('btnWipe').addEventListener('click', async () => {
    if(!await uiConfirm('TÜM veriler (adisyonlar, satışlar, müşteriler, ürünler) silinecek. Emin misiniz?')) return;
    if(await uiPrompt('Onaylamak için SIL yazın') !== 'SIL') return;
    try{ localStorage.removeItem(STORE_KEY); }catch(e){}
    if(!RT.local) try{ RT.remove('state'); }catch(e){}
    location.reload();
  });

  // ---- açılış: tohum veriler → kayıtlı veri → ilk çizim ----
  seedLists(); seedPay(); ensurePayTypes();
  try{ localStorage.setItem('posProbe', '1'); localStorage.removeItem('posProbe'); }catch(e){ storageOK = false; }
  try{
    const raw = localStorage.getItem(STORE_KEY); let s = null;
    try{ s = JSON.parse(raw || 'null'); }catch(e){ if(raw) try{ localStorage.setItem(STORE_KEY + '_bozuk', raw); }catch(e2){} }
    if(s){ lastSavedAt = s.savedAt || 0; applyState(s, false); } else renderAll();
  }catch(e){ console.error(e); try{ renderAll(); }catch(e2){ console.error(e2); } }
  try{ if(localStorage.getItem(THEME_KEY) === 'dark'){ document.body.setAttribute('data-theme', 'dark'); $id('eyeIcon').textContent = '🌙'; $id('eyeLabel').textContent = 'Karanlık mod açık'; } }catch(e){}

  // ---- ek: tarayıcı alert'i yerine uygulama bildirimi; ikon butonlara otomatik erişilebilirlik etiketi ----
  window.alert = m => showToast(String(m));
  (function(){ let t = 0; const fix = () => { document.querySelectorAll('button:not([aria-label]),[role=button]:not([aria-label])').forEach(b => { const l = (b.getAttribute('title') || b.textContent || '').trim(); if(l) b.setAttribute('aria-label', l.slice(0, 40)); }); };
    new MutationObserver(() => { clearTimeout(t); t = setTimeout(fix, 300); }).observe(document.body, { childList: true, subtree: true }); fix(); })();
  setInterval(() => { if(staffMode) saveState(); }, 1500);
  window.addEventListener('beforeunload', () => { if(staffMode) saveState(); });
  document.addEventListener('visibilitychange', () => { if(staffMode) saveState(); });

  async function bootApp(){
    let liveSeen = false;
    const onPub = (v, live) => {
      if(live) liveSeen = true; else if(liveSeen || !v || !v.categories) return;
      if(JSON.stringify(v) === JSON.stringify(pubData) && pubReady) return;
      pubData = v; pubReady = true; clearTimeout(pubTimer);
      try{ if(v && v.categories) localStorage.setItem(PUB_CACHE, JSON.stringify(v)); }catch(e){}
      if(!staffMode) renderCustomer();
    };
    // menü verisi (hızlı REST) ve kayıtlı önbellek Firebase SDK'sını BEKLEMEDEN çizilir
    if(window.__pubP) window.__pubP.then(v => onPub(v, false));
    renderCustomer();
    await initRT();
    RT.on('public', v => onPub(v, true));
    if(RT.local) pubReady = true; else if(!pubReady) pubTimer = setTimeout(() => {
      if(staffMode) return;
      if(pubData){ pubReady = true; renderCustomer(); }
      else{ $id('cItems').dataset.sk = '1'; $id('cItems').innerHTML = '<p style="text-align:center;padding:40px 20px;color:var(--ink-faint)">Menü yüklenemedi. Bağlantınızı kontrol edip sayfayı yenileyin.</p>'; }
    }, 8000);
    renderCustomer();
    restoreSession();
  }
  // ======================= EKLER v3 =======================
  const _enterStaff = enterStaff;
  enterStaff = function(){
    if(staffMode) return;
    if(RT.local || !RT.staffAuth){ dirReady = true; _enterStaff(); endRestoring(); return; }
    RT.staffAuth(!!(curUser && curUser.admin)).then(async ok => {
      if(!ok){ curUser = null; sessionStorage.removeItem('posUser'); showToast('Firebase personel girişi gerekli.'); endRestoring(); return; }
      if(curUser && curUser.admin) await pullStaffDir();
      watchRole();
      if(!adminDev()){ PRIV_KEYS.forEach(k => privSet(k, k === 'closedAt' ? 0 : [])); try{ localStorage.removeItem('posCancelLog'); }catch(_){} lastSaved = ''; saveState(); }
      _enterStaff(); endRestoring();
    });
  };
  // 1) İptal: neden + yönetici PIN'i + kayıt
  const CANCEL_REASONS = ['Müşteri Vazgeçti', 'Yanlış Sipariş', 'Döküldü / Mutfak Hatası', 'Diğer'];
  if(!cancelLog.length) cancelLog = (() => { try{ return JSON.parse(localStorage.getItem('posCancelLog')) || []; }catch(e){ return []; } })();
  async function askManagerPin(){
    if(curUser && curUser.admin) return true;
    return pinOK(await askSecret('Yönetici PIN kodu:'));
  }
  $id('btnCancelOrder').addEventListener('click', async e => {
    e.stopImmediatePropagation();
    const k = currentCartKey;
    if(!(carts[k] || []).length){ showToast('Sepet zaten boş.'); return; }
    if(paidByKey[k]){ showToast('Ödeme alınmış adisyon iptal edilemez.'); return; }
    const n = parseInt(await uiPrompt('İptal nedeni:\n' + CANCEL_REASONS.map((r, i) => (i + 1) + ' - ' + r).join('\n')), 10);
    if(!(n >= 1 && n <= CANCEL_REASONS.length)) return;
    if(!(await askManagerPin())){ showToast('PIN hatalı, iptal yapılmadı.'); return; }
    logPriv('cancelLog', { ts: Date.now(), key: k, reason: CANCEL_REASONS[n - 1], total: grossTotal(k), by: uname(), items: carts[k].map(i => i.qty + '× ' + i.name) });
    if(adminDev()) try{ localStorage.setItem('posCancelLog', JSON.stringify(cancelLog.slice(0, 500))); }catch(_){}
    carts[k] = []; delete discountByKey[k]; delete guestsByKey[k];
    afterOrderChange(); if(extOrders[k]) dropExt(k); showScreen(currentBackScreen); renderSiparisMasa();
    showToast('Adisyon iptal edildi: ' + CANCEL_REASONS[n - 1]);
  }, true);

  // 2) Yemek Kartı ödeme tipi
  const _ept = ensurePayTypes;
  ensurePayTypes = function(){ _ept(); if(!payTypes.some(p => p.name === 'Yemek Kartı')) payTypes.push({ name: 'Yemek Kartı', on: true }); };
  ensurePayTypes();

  // 3) Barkod okuyucu (USB/Bluetooth klavye gibi çalışır): ürüne "barcode" alanı atanır
  let bcBuf = '', bcT = 0;
  document.addEventListener('keydown', e => {
    if(!staffMode || /INPUT|TEXTAREA|SELECT/.test((e.target.tagName || ''))) return;
    if(e.key === 'Enter'){
      const code = bcBuf; bcBuf = ''; if(code.length < 4) return;
      let hit = null; categories.forEach(c => c.products.forEach(p => { if(String(p.barcode || '') === code) hit = p; }));
      if(!hit){ showToast('Barkod bulunamadı: ' + code); return; }
      if(!currentCartKey || !$id('screen-order') || !$id('screen-order').classList.contains('show')){ showToast('Önce bir adisyon açın.'); return; }
      const c = carts[currentCartKey] = carts[currentCartKey] || [];
      const x = c.find(i => i.name === hit.name && i.unit === hit.price && (i.by || '') === uname());
      if(x) x.qty++; else c.push({ name: hit.name, unit: hit.price, qty: 1, sent: 0, by: uname(), at: Date.now() });
      afterOrderChange(); renderOrderLines(); showToast('＋ ' + hit.name);
    } else if(e.key.length === 1){ const n = Date.now(); if(n - bcT > 100) bcBuf = ''; bcT = n; bcBuf += e.key; }
  });

  // 4) Müşteri QR menüsü: Garson Çağır / Hesap İstiyorum
  const cs = null;
  if(cs){
    const bar = document.createElement('div'); bar.style.cssText = 'display:flex;gap:8px;margin:8px 0;';
    bar.innerHTML = '<button id="cCallW" class="btn-mini" style="flex:1">🙋 Garson Çağır</button><button id="cCallB" class="btn-mini" style="flex:1">🧾 Hesap İstiyorum</button>';
    cs.parentNode.insertBefore(bar, cs);
    let lastCall = 0;
    const call = t => {
      const m = $id('cMasa').value; if(!m){ alert('Önce masanızı seçin.'); return; }
      if(Date.now() - lastCall < 30000){ alert('Lütfen biraz bekleyin, çağrınız iletildi.'); return; }
      lastCall = Date.now(); RT.push('calls', { table: m, label: $id('cMasa').selectedOptions[0].text, type: t, ts: Date.now() });
      alert(t === 'hesap' ? 'Hesap talebiniz iletildi.' : 'Garson çağrınız iletildi.');
    };
    $id('cCallW').onclick = () => call('garson'); $id('cCallB').onclick = () => call('hesap');
  }
  // Garson tarafında anlık uyarı
  const seenCalls = {};
  const callTimer = setInterval(() => {
    if(!staffMode) return; clearInterval(callTimer);
    RT.on('calls', v => Object.entries(v || {}).forEach(([id, c]) => {
      if(!c || seenCalls[id] || Date.now() - c.ts > 120000) return; seenCalls[id] = 1;
      beep(); showToast((c.type === 'hesap' ? '🧾 Hesap isteniyor: ' : '🙋 Garson çağrıldı: ') + c.label);
      setTimeout(() => RT.remove('calls/' + id), 60000);
    }));
  }, 1000);

  // ======================= EKLER v4 =======================
  function shiftMin(k){ const [a, b] = (settings[k] || (k === 'dayStart' ? '05:00' : '15:00')).split(':').map(Number); return (a || 0) * 60 + (b || 0); }
  function inRange(ts, f, t){
    const a = $id(f).value ? new Date($id(f).value + 'T00:00:00').getTime() : 0, b = $id(t).value ? new Date($id(t).value + 'T23:59:59').getTime() : Infinity;
    return ts >= a && ts <= b;
  }
  function rangeSales(){ return ($id('urunFrom').value || $id('urunTo').value) ? saleLog.filter(x => inRange(x.ts, 'urunFrom', 'urunTo')) : todaySales(); }
  function fireRows(){ const r = !!($id('fireFrom').value || $id('fireTo').value); return (lists.zayi || []).filter(x => !r || (x.ts && inRange(x.ts, 'fireFrom', 'fireTo'))); }
  function renderFire(){
    const rows = fireRows(), tot = rows.reduce((a, r) => a + (parseFloat(r.qty) || 0), 0);
    $id('repFire').innerHTML = (rows.map(r => '<div class="prow"><span class="pic">🔥</span><div class="pmain"><b>' + esc(r.name) + '</b><span>' + esc(r.sub || '') + '</span></div><span class="pval">' + esc(r.val || '') + '</span></div>').join('') || '<p style="color:var(--ink-faint);padding:8px;">Bu aralıkta fire kaydı yok.</p>') +
      (rows.length ? '<div class="prow"><span class="pic">Σ</span><div class="pmain"><b>Toplam</b></div><span class="pval">' + rows.length + ' kayıt · ' + tot + '</span></div>' : '');
  }
  function renderCancelLog(){
    $id('repCancel').innerHTML = cancelLog.slice(0, 100).map(c => '<div class="prow"><span class="pic">❌</span><div class="pmain"><b>' + esc(c.reason) + ' · ' + esc(String(c.total != null ? money(+c.total) : '')) + '</b><span>' + new Date(c.ts).toLocaleString('tr-TR') + ' · ' + esc(c.by || '') + ' · ' + esc((c.items || []).join(', ')) + '</span></div></div>').join('') || '<p style="color:var(--ink-faint);padding:8px;">İptal kaydı yok.</p>';
  }
  function zayiForm(){
    const names = []; categories.forEach(c => c.products.forEach(p => names.push(p.name)));
    const units = (lists.birimler || []).map(r => r.name).concat(['Adet']).filter((x, i, a) => a.indexOf(x) === i);
    openForm({ title: 'Zayi / Fire Kaydı', fields: [
      { id: 'name', label: 'Ürün / malzeme', value: '', list: names, placeholder: 'Ürün seçin veya yazın' },
      { id: 'qty', label: 'Miktar', type: 'number', step: '0.01', value: 1 },
      { id: 'unit', label: 'Birim', type: 'select', options: units, value: 'Adet' },
      { id: 'reason', label: 'Neden', type: 'select', options: ['Düşürüldü', 'Son kullanma tarihi geçti', 'Mutfak hatası', 'Bozuldu', 'Diğer'], value: 'Düşürüldü' }
    ], onOk(v){
      if(!v.name) return 'Ürün / malzeme gerekli.';
      if(!(v.qty > 0)) return 'Miktar 0\'dan büyük olmalı.';
      lists.zayi.push({ name: v.name.trim(), qty: v.qty, ts: Date.now(), sub: new Date().toLocaleDateString('tr-TR') + ' · ' + v.reason, val: v.qty + ' ' + v.unit });
      renderLists(); renderReports(); saveState(); showToast('Zayi kaydedildi.');
    } });
  }
  function csvOf(rows){ return rows.map(r => r.map(c => { const s = String(c); return '"' + ((typeof c === 'string' && /^[=+\-@]/.test(s)) ? "'" + s : s).replace(/"/g, '""') + '"'; }).join(';')).join('\n'); }
  $id('urunCsv').addEventListener('click', () => {
    const m = {}; rangeSales().forEach(x => x.items.forEach(i => { const o = m[i.name] || (m[i.name] = { q: 0, t: 0 }); o.q += i.qty; o.t += i.qty * i.unit; }));
    downloadFile('urun-satis.csv', csvOf([['Ürün', 'Adet', 'Tutar']].concat(Object.entries(m).sort((a, b) => b[1].t - a[1].t).map(([k, v]) => [k, v.q, v.t.toFixed(2)]))));
  });
  $id('fireCsv').addEventListener('click', () => downloadFile('fire.csv', csvOf([['Ürün', 'Miktar', 'Tarih / Neden']].concat(fireRows().map(r => [r.name, r.val || '', r.sub || ''])))));
  $id('btnGsCsv').addEventListener('click', () => downloadFile('gun-sonu.csv', csvOf([['Kalem', 'Değer']].concat([...document.querySelectorAll('#screen-rapor-gunsonu .panel-card:first-child .prow')].map(r => [r.querySelector('b').textContent, r.querySelector('.pval').textContent])))));
  ['urunFrom', 'urunTo'].forEach(i => $id(i).addEventListener('change', () => renderReports()));
  ['fireFrom', 'fireTo'].forEach(i => $id(i).addEventListener('change', renderFire));
  $id('btnOwnerPw').addEventListener('click', async () => {
    if(!(curUser && curUser.owner) || RT.local || !RT.changePassword){ showToast('Bu işlem yalnızca Yönetici hesabı içindir.'); return; }
    const o = $id('ownerOldPw').value, n = $id('ownerNewPw').value.trim();
    const isSup = !!(curUser && curUser.sup), isOwn = !!(curUser && curUser.owner);
    if(!o && !isSup && !isOwn){ showToast('Eski şifreyi yazın.'); return; }
    if(n.length < 6 || /\s/.test(n)){ showToast('Yeni şifre en az 6 karakter olmalı, boşluk içermemeli.'); return; }
    if(n === o){ showToast('Yeni şifre eskisinden farklı olmalı.'); return; }
    const btn = $id('btnOwnerPw'); btn.disabled = true;
    try{
      const r = (!o && isSup && RT.adminSetPassword) ? await RT.adminSetPassword(n) : (!o && isOwn && RT.ownerResetPassword) ? await RT.ownerResetPassword(n) : await RT.changePassword(o, n);
      if(r.code === 'ok'){ $id('ownerOldPw').value = ''; $id('ownerNewPw').value = ''; showToast('Şifreniz değiştirildi.'); }
      else showToast({ wrong: 'Eski şifre hatalı.', weak: 'Yeni şifre çok zayıf (en az 6 karakter).', limit: 'Çok fazla deneme, biraz bekleyin.', net: 'İnternet bağlantısı yok.', recent: 'Güvenlik için çıkış yapıp şifresiz (Google ile) tekrar girin, sonra deneyin.', has: 'Zaten bir şifre var; eski şifreyi de yazın.', off: 'Firebase\'de E-posta/Şifre girişi kapalı.' }[r.code] || 'Şifre değiştirilemedi, tekrar deneyin.');
    } finally { btn.disabled = false; }
  });
  $id('btnOwnerGoogle').addEventListener('click', async () => {
    if(!(curUser && curUser.owner) || RT.local || !RT.ownerLinkGoogle){ showToast('Bu işlem şu an yapılamıyor.'); return; }
    const had = RT.ownerGoogleEmail ? RT.ownerGoogleEmail() : '';
    if(had && !await uiConfirm('Şu an bağlı hesap: ' + had + '\nDeğiştirilecek. Yeni hesabı seçmeden pencereyi kapatmayın. Devam edilsin mi?')) return;
    const btn = $id('btnOwnerGoogle'); btn.disabled = true;
    try{
      const r = await RT.ownerLinkGoogle();
      if(r.code !== 'cancel') showToast({ ok: 'Google hesabı bağlandı.', popup: 'Açılır pencere engellendi. İzin verip tekrar deneyin.', goff: 'Firebase\'de Google girişi kapalı.', domain: 'Bu site adresi Firebase\'de yetkili değil.', net: 'İnternet bağlantısı yok.', used: 'Bu Google hesabı başka bir hesaba bağlı, farklı bir hesap seçin.', recent: 'Güvenlik için çıkış yapıp tekrar girin, sonra deneyin.' }[r.code] || 'Google hesabı bağlanamadı, tekrar deneyin.');
      applyPerms();
    } finally { btn.disabled = false; }
  });
  $id('btnOwnerAcc').addEventListener('click', async () => {
    if(!(curUser && curUser.sup) || RT.local || !(RT.isRoot && RT.isRoot()) || !RT.createStaff){ showToast('Bu işlem şu an yapılamıyor.'); return; }
    const pw = $id('setOwnerPw').value.trim();
    if(pw.length < 6 || /\s/.test(pw)){ showToast('Şifre en az 6 karakter olmalı, boşluk içermemeli.'); return; }
    const btn = $id('btnOwnerAcc'); btn.disabled = true;
    try{
      let cur = 0; try{ cur = +(await RT.get('staffVer/yonetici')) || 0; }catch(e){ showToast('Firebase okunamadı: ' + fbErr(e)); return; }
      let v = cur + 1, nid = null, tries = 0;
      while(!nid && tries++ < 6){
        try{ nid = await RT.createStaff(staffEmail('yonetici', v), pw); }
        catch(e){ if(e && e.code === 'auth/email-already-in-use'){ v++; continue; } showToast(fbErr(e)); return; }
      }
      if(!nid){ showToast('Hesap açılamadı, tekrar deneyin.'); return; }
      try{
        await RT.set('staffRoles/' + nid, { ad: 'Yönetici', gorev: 'Müdür', bolge: '', owner: true, v });
        await RT.set('staffVer/yonetici', v);
      }catch(e){ try{ await RT.remove('staffRoles/' + nid); }catch(_){} showToast('Kayıt yazılamadı: ' + fbErr(e) + ' (Rules yayınlandı mı?)'); return; }
      try{ const all = await RT.get('staffRoles') || {}; for(const k of Object.keys(all)){ if(k !== nid && all[k] && all[k].owner === true) await RT.remove('staffRoles/' + k); } }catch(e){ console.error(e); }
      $id('setOwnerPw').value = ''; showToast('Yönetici hesabı hazır. Giriş: isim "Yönetici" + yeni şifre.');
    } finally { btn.disabled = false; }
  });
  $id('btnGuncelle').addEventListener('click', () => {
    if(!(curUser && curUser.admin) || curUser.owner){ if($id('setPin').value.trim() || ($id('setSupPin') && $id('setSupPin').value.trim())) showToast('PIN değiştirilemez. Yönetici şifresi için "Şifremi değiştir" alanını kullanın.'); return; }
    const p = $id('setPin').value.trim(), sp = $id('setSupPin') ? $id('setSupPin').value.trim() : '';
    if(!p && !sp) return;
    const chk = (x, min) => {
      if(x.length < min || /\s/.test(x)){ showToast('PIN en az ' + min + ' karakter olmalı, boşluk içermemeli.'); return false; }
      if(staffUsers.some(u => (u.h && u.h === pwHash(x)) || (u.sifre && u.sifre === x))){ showToast('Bu şifre bir personelde kullanılıyor, farklı bir PIN seçin.'); return false; }
      return true;
    };
    if(p && !chk(p, 4)) return;
    if(sp){
      if(RT.local || !(curUser.sup || (!supExists && !isHash(settings.supPin)))){ showToast('Bu işlem için yetkiniz yok.'); return; }
      if(!chk(sp, 6)) return;
      if(sp === p || pwHash(sp) === settings.pin){ showToast('Admin PIN\'i Yönetici PIN\'inden farklı olmalı.'); return; }
    }
    if(p){
      if(settings.supPin && pwHash(p) === settings.supPin){ showToast('Bu PIN kullanılamaz, farklı bir PIN seçin.'); return; }
      settings.pin = pwHash(p);
    }
    if(sp){ settings.supPin = pwHash(sp); supExists = true; }
    $id('setPin').value = ''; if($id('setSupPin')) $id('setSupPin').value = '';
    saveState(); lastDirSig = ''; try{ syncStaffDir(); }catch(e){ console.error(e); } applyPerms(); showToast((p && sp) ? 'PIN\'ler güncellendi.' : sp ? 'Admin PIN güncellendi.' : 'PIN güncellendi.');
  });
  $id('btnBackup').addEventListener('click', () => { settings.lastBackup = Date.now(); });
  setInterval(() => { if(staffMode && curUser && curUser.admin && !window._bkWarned && Date.now() - (settings.lastBackup || 0) > 7 * 864e5){ window._bkWarned = 1; showToast('⚠ Son yedek 7 günden eski. Ayarlar > Yedek & Sistem\'den yedek indirin.'); } }, 60000);
  renderReports();

  // erişilebilirlik: klavye, rol ve etiketler
  (function(){
    const SEL = '.nav-item,.sub-item,.sm-switch-btn,.tab,.link-btn,.eye-toggle,.sm-ic,.mp-chip,.cat-item,.plain-table-cell,.sm-pill,.c-tab', L = { '✎': 'Düzenle', '🗑': 'Sil', '↻': 'Yenile', '★': 'Varsayılan yap' };
    let q = 0;
    function fix(){
      q = 0;
      document.querySelectorAll(SEL).forEach(el => {
        if(!el.hasAttribute('role')) el.setAttribute('role', 'button');
        if(!el.hasAttribute('tabindex')) el.tabIndex = 0;
        if(!el.hasAttribute('aria-label')){ const t = el.title || L[el.textContent.trim()]; if(t) el.setAttribute('aria-label', t); }
      });
      document.querySelectorAll('[contenteditable="true"]').forEach(el => {
        if(el.hasAttribute('role')) return; el.setAttribute('role', 'textbox');
        const lb = el.parentNode && el.parentNode.querySelector('label'); el.setAttribute('aria-label', lb ? lb.textContent : (el.className.includes('pay-name') ? 'Ödeme tipi adı' : 'Düzenlenebilir alan'));
      });
    }
    new MutationObserver(() => { if(!q) q = requestAnimationFrame(fix); }).observe(document.body, { childList: true, subtree: true });
    document.addEventListener('keydown', e => {
      if((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches(SEL) && !/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)){ e.preventDefault(); e.target.click(); }
    });
    fix();
  })();

  // ======================= EKLER v5 =======================
  // ---- masa rengi: boş = beyaz, sipariş bekleyen = kırmızı, siparişi alınmış / verilmiş = yeşil ----
  function tableState(n){
    const cart = carts['table_' + n] || [];
    let pend = false; try{ pend = pendingCO().some(([, o]) => String(o.table) === String(n)); }catch(e){}
    if(pend) return 'blink';   // müşteriden geldi, onay bekliyor: kırmızı yanıp söner
    if(!cart.length) return 'free';
    if(cart.some(i => (i.qty || 0) > (i.sent || 0))) return 'wait';
    const kOpen = Object.values(kitchenData || {}).some(k => k && k.table === 'table_' + n && (k.status === 'hazirlaniyor' || k.status === 'hazir'));
    return kOpen ? 'wait' : 'ok';   // mutfakta teslim edilmemiş sipariş varsa kırmızı sabit, teslim edilince yeşil
  }

  // ---- bağlantı durumu ve gerçek yenileme ----
  var connState = 'unk', lastSyncAt = 0;
  function setConn(st){ connState = st; const d = $id('smConnDot'); if(d) d.className = 'cdot ' + (st === 'ok' ? 'ok' : st === 'bad' ? 'bad' : st === 'loc' ? 'loc' : ''); }
  function markSync(){ lastSyncAt = Date.now(); }
  window.addEventListener('offline', () => setConn('bad'));
  async function refreshNow(){
    const btns = [$id('smIconRefresh'), $id('btnRefresh')].filter(Boolean);
    btns.forEach(b => { b.classList.remove('spin'); void b.offsetWidth; b.classList.add('spin'); });
    let ok = true;
    try{
      if(!RT.local){
        const [st, co, kt] = await Promise.all([RT.get('state'), RT.get('customerOrders'), RT.get('kitchen')]);
        if(st && st.dev !== DEV && (st.savedAt || 0) > lastSavedAt) applyState(st, true);
        coData = co || {}; kitchenData = kt || {}; markSync(); setConn('ok');
      }
    }catch(e){ ok = false; setConn('bad'); console.error(e); }
    try{ renderAll(); renderCO(); renderSmKanban(); renderKitchen(); }catch(e){ console.error(e); }
    setTimeout(() => btns.forEach(b => b.classList.remove('spin')), 800);
    showToast(ok ? (RT.local ? 'Yenilendi (yerel mod).' : '✓ Canlı veriler güncellendi · ' + new Date().toLocaleTimeString('tr-TR')) : '⚠ Sunucuya ulaşılamadı. İnternet bağlantısını kontrol edin.');
    return ok;
  }
  function showConnInfo(){
    const info = RT.local ? ['#e0a340', 'Yerel mod', 'Firebase ayarlı değil; sistem yalnızca bu cihazda çalışıyor.']
      : connState === 'ok' ? ['#2e9d57', 'Canlı bağlantı', 'Siparişler ve mutfak diğer cihazlarla anlık eşleşiyor.']
      : connState === 'bad' ? ['#d93025', 'Bağlantı yok', 'İnternet gelince sistem kendiliğinden yeniden bağlanır. "Şimdi Yenile" ile elle de deneyebilirsiniz.']
      : ['#9a9a9a', 'Bağlanıyor…', 'Sunucuyla bağlantı kuruluyor.'];
    const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 1100;
    bg.innerHTML = '<div class="modal-box"><div style="display:flex;align-items:center;gap:10px;"><span style="width:14px;height:14px;border-radius:50%;background:' + info[0] + ';display:inline-block"></span><h3 style="margin:0;flex:1">' + info[1] + '</h3></div>' +
      '<p style="color:var(--ink-dim);margin:10px 0">' + info[2] + '</p>' +
      '<p style="color:var(--ink-faint);font-size:.85rem;margin:0 0 12px">Son veri: ' + (lastSyncAt ? new Date(lastSyncAt).toLocaleTimeString('tr-TR') : '—') + '</p>' +
      '<div style="display:flex;gap:8px"><button class="btn-save" id="ciGo" style="margin:0">↻ Şimdi Yenile</button><button class="btn-save" id="ciNo" style="margin:0;background:var(--ink-faint)">Kapat</button></div></div>';
    document.body.appendChild(bg);
    bg.querySelector('#ciNo').onclick = () => bg.remove(); bg.addEventListener('mousedown', e => { if(e.target === bg) bg.remove(); });
    bg.querySelector('#ciGo').onclick = async () => { bg.remove(); await refreshNow(); };
  }

  // ---- PC'de tam ekran masa görünümü (ayar hatırlanır) ----
  const SM_SIZES = [140, 180, 230, 300, 380];
  let smFullPref = false, smSize = 2, smFsTried = false;
  try{ smFullPref = localStorage.getItem('posSmFull') === '1'; const v = parseInt(localStorage.getItem('posSmSize')); if(!isNaN(v)) smSize = Math.min(4, Math.max(0, v)); }catch(e){}
  let smScreen = 'siparis-masa';
  function smFullApply(name){
    if(name) smScreen = name;
    const on = smFullPref && smScreen === 'siparis-masa' && window.innerWidth > 860;
    document.body.classList.toggle('sm-full', on);
    document.body.style.setProperty('--tsz', SM_SIZES[smSize] + 'px');
    document.body.style.setProperty('--tsh', Math.round(SM_SIZES[smSize] * 0.62) + 'px');
    const b = $id('smIconFull'); if(b) b.classList.toggle('on', smFullPref);
  }
  function smSave(){ try{ localStorage.setItem('posSmFull', smFullPref ? '1' : '0'); localStorage.setItem('posSmSize', String(smSize)); }catch(e){} }
  $id('smIconFull').addEventListener('click', () => {
    smFullPref = !smFullPref; smSave(); smFullApply();
    try{
      if(smFullPref && document.documentElement.requestFullscreen && !document.fullscreenElement) document.documentElement.requestFullscreen().catch(() => {});
      else if(!smFullPref && document.fullscreenElement) document.exitFullscreen();
    }catch(e){}
    if(smFullPref && window.innerWidth <= 860) showToast('Tam ekran masa düzeni bilgisayar / geniş ekran içindir.');
  });
  $id('smSzMinus').addEventListener('click', () => { smSize = Math.max(0, smSize - 1); smSave(); smFullApply(); });
  $id('smSzPlus').addEventListener('click', () => { smSize = Math.min(4, smSize + 1); smSave(); smFullApply(); });
  window.addEventListener('resize', () => smFullApply());
  document.addEventListener('pointerdown', () => {   // kayıtlı tercih açıksa ilk dokunuşta tarayıcı tam ekranına da geç
    if(smFullPref && !smFsTried && document.body.classList.contains('sm-full') && !document.fullscreenElement){ smFsTried = true; try{ document.documentElement.requestFullscreen().catch(() => {}); }catch(e){} }
  }, true);

  // ---- masa / ürün taşıma ----
  function openMoveDialog(pre){
    const k = currentCartKey;
    if(!can('move') || !k.startsWith('table_')){ showToast('Yalnız masa adisyonları taşınabilir.'); return; }
    const cart = (carts[k] || []).filter(i => i.qty > 0);
    if(!cart.length){ showToast('Taşınacak ürün yok.'); return; }
    let mode = pre ? 'pick' : 'all';
    const q = cart.map(i => (pre && i === pre) ? i.qty : 0);
    const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 1100;
    const box = document.createElement('div'); box.className = 'modal-box'; bg.appendChild(box);
    function draw(){
      const st = box.querySelector('.mvd-list') ? box.querySelector('.mvd-list').scrollTop : 0;
      const total = mode === 'all' ? cart.reduce((a, i) => a + i.qty, 0) : q.reduce((a, x) => a + x, 0);
      box.innerHTML = '<div class="mvd-top"><h3>⇄ ' + esc(orderLabel(k)) + ' · Taşı</h3><span id="mvdX">✕</span></div>' +
        '<div class="mvd-seg"><button data-m="all" class="' + (mode === 'all' ? 'on' : '') + '">Tüm adisyon</button><button data-m="pick" class="' + (mode === 'pick' ? 'on' : '') + '">Ürün seç</button></div>' +
        '<div class="mvd-list">' + cart.map((i, ix) => '<div class="mvd-row' + ((mode === 'all' || q[ix] > 0) ? ' sel' : '') + '"><div class="nm"><b>' + esc(i.name) + '</b><small>adisyonda ' + i.qty + (i.by ? ' · ' + esc(i.by) : '') + '</small></div>' +
          (mode === 'all' ? '<span class="mvd-q">' + i.qty + '</span>' : '<div class="qty-ctl"><button class="qbtn" data-ix="' + ix + '" data-d="-1">−</button><b class="qv">' + q[ix] + '</b><button class="qbtn" data-ix="' + ix + '" data-d="1">+</button></div>') + '</div>').join('') + '</div>' +
        '<button class="btn-save mvd-go" id="mvdGo"' + (total ? '' : ' disabled') + '>' + (total ? total + ' ürün · Masa Seç →' : 'Taşınacak ürünü seçin') + '</button>';
      const l = box.querySelector('.mvd-list'); if(l) l.scrollTop = st;
    }
    box.addEventListener('click', e => {
      if(e.target.closest('#mvdX')){ bg.remove(); return; }
      const m = e.target.closest('.mvd-seg button'); if(m){ mode = m.dataset.m; draw(); return; }
      const qb = e.target.closest('.qbtn[data-ix]'); if(qb){ const ix = +qb.dataset.ix; q[ix] = Math.max(0, Math.min(cart[ix].qty, q[ix] + (+qb.dataset.d))); draw(); return; }
      if(e.target.closest('#mvdGo')){
        const picks = cart.map((i, ix) => ({ item: i, qty: mode === 'all' ? i.qty : q[ix] })).filter(p => p.qty > 0);
        if(!picks.length) return; bg.remove(); pickTargetTable(k, t => doMove(k, picks, t));
      }
    });
    bg.addEventListener('mousedown', e => { if(e.target === bg) bg.remove(); });
    document.body.appendChild(bg); draw();
  }

  // ---- ödeme: hızlı tutar düğmeleri ----
  function ppSetAmount(v){ $id('ppAmountInput').value = (Math.max(0, Math.round(v * 100) / 100)).toFixed(2); }
  $id('ppAll').addEventListener('click', () => ppSetAmount(remainingForKey(currentCartKey)));
  $id('ppHalf').addEventListener('click', () => ppSetAmount(remainingForKey(currentCartKey) / 2));
  const ppStep = d => { const el = $id('ppSplitCount'); const n = Math.max(1, (parseInt(el.value) || 1) + d); el.value = n; ppSetAmount(remainingForKey(currentCartKey) / n); };
  $id('ppSplitMinus').addEventListener('click', () => ppStep(-1));
  $id('ppSplitPlus').addEventListener('click', () => ppStep(1));

  // ---- mutfak: okudum anladım bitene kadar uyarı sesi (en yüksek sesle başlar, azalarak sürer) ----
  const KAlarm = (() => {
    let ctx = null, timer = 0, vol = 1, last = 0;
    const MIN = 0.2, STEP = 0.8, EVERY = 1600;
    function unlock(){ try{ if(!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)(); if(ctx.state === 'suspended') ctx.resume(); }catch(e){} return ctx; }
    function tone(v){
      const c = unlock(); if(!c) return;
      [[0, 880], [0.3, 1175]].forEach(([d, f]) => {
        const o = c.createOscillator(), g = c.createGain(), t = c.currentTime + d;
        o.type = 'square'; o.frequency.value = f; o.connect(g); g.connect(c.destination);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(Math.max(0.02, v), t + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.26);
        o.start(t); o.stop(t + 0.28);
      });
    }
    function tick(){ tone(vol); try{ if(navigator.vibrate) navigator.vibrate([250, 120, 250]); }catch(e){} vol = Math.max(MIN, vol * STEP); }
    function set(n){
      if(n > 0){
        if(!timer){ vol = 1; tick(); timer = setInterval(tick, EVERY); }
        else if(n > last) vol = 1;
      } else if(timer){ clearInterval(timer); timer = 0; }
      last = n;
    }
    return { set, unlock };
  })();
  document.addEventListener('pointerdown', () => KAlarm.unlock(), true);
  function kAlarmSync(){
    try{
      const scr = $id('screen-mutfak'), on = staffMode && can('kitchen') && scr && scr.classList.contains('show');
      const n = on ? Object.values(kitchenData || {}).filter(k => isUnread(k) && (!kGrp || (k.grp || defGroup()) === kGrp)).length : 0;
      KAlarm.set(n);
    }catch(e){ /* sayfa yüklenirken alarm henüz hazır değil */ }
  }
  let wakeLock = null;
  async function keepAwake(){ try{ if('wakeLock' in navigator && !wakeLock){ wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => { wakeLock = null; }); } }catch(e){} }
  document.addEventListener('visibilitychange', () => { if(document.visibilityState === 'visible' && document.body.classList.contains('kitchen-only')) keepAwake(); });
  // =====================================================================
  // YAPAY ZEKÂ — Firebase AI Logic (Gemini Developer API)
  // =====================================================================
  var cLang = ''; try{ cLang = localStorage.getItem('cLang') || ''; }catch(e){}
  var AI_LANGS = { en: 'İngilizce', de: 'Almanca', ru: 'Rusça', ar: 'Arapça', fr: 'Fransızca' };
  var APPCHECK_SITE_KEY = '6Lf9ieotAAAAACBfihhPp2eobnFTq1ZfvPfO-g_V';   // reCAPTCHA SITE (herkese açık) anahtarı
  var APPCHECK_ENTERPRISE = false;   // Firebase App Check'te sağlayıcı 'reCAPTCHA Enterprise' ise true yapın; 'reCAPTCHA v3' ise false kalsın
  var AI_MODELS = ['gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-3.8-flash'], AIM = { ai: null, gm: null, i: 0, text: null, json: null }, aiChatN = 0, aiChatHist = [], _trC = {};

  function aiBuild(){
    AIM.text = AIM.gm(AIM.ai, { model: AI_MODELS[AIM.i] });
    AIM.json = AIM.gm(AIM.ai, { model: AI_MODELS[AIM.i], generationConfig: { responseMimeType: 'application/json' } });
  }
  async function aiInit(){
    if(AIM.text) return;
    if(!window.__fbApp) throw new Error('Firebase bağlantısı yok. İnternetinizi ve Firebase ayarını kontrol edin.');
    if(APPCHECK_SITE_KEY && !window.__acInit){
      const AC = await import(window.__fbB + 'firebase-app-check.js');
      AC.initializeAppCheck(window.__fbApp, { provider: APPCHECK_ENTERPRISE ? new AC.ReCaptchaEnterpriseProvider(APPCHECK_SITE_KEY) : new AC.ReCaptchaV3Provider(APPCHECK_SITE_KEY), isTokenAutoRefreshEnabled: true }); window.__acInit = true;
    }
    const { getAI, getGenerativeModel, GoogleAIBackend } = await import(window.__fbB + 'firebase-ai.js');
    AIM.ai = getAI(window.__fbApp, { backend: new GoogleAIBackend() }); AIM.gm = getGenerativeModel; aiBuild();
  }
  // 404: model kapatılmış -> sonraki modele geç. 500/503 (yoğunluk): kısa beklemeyle 2 kez tekrar dene, olmazsa sonraki modele geç
  async function aiGen(kind, c){
    await aiInit(); let tries = 0;
    for(;;){
      try{ return (await AIM[kind].generateContent(c)).response.text(); }
      catch(e){
        const m = String((e && e.message) || e), last = AIM.i >= AI_MODELS.length - 1;
        if((/404|not.?found|no longer available|not supported/i.test(m) || /429|quota|resource.?exhausted/i.test(m)) && !last){ AIM.i++; aiBuild(); tries = 0; continue; }
        if(/\[\s*(500|502|503|504)\s*\]|high demand|overload|unavailable|try again later/i.test(m)){
          if(tries < 1){ await new Promise(r => setTimeout(r, 2000)); tries++; continue; }
          if(!last){ AIM.i++; aiBuild(); tries = 0; continue; }
        }
        throw e;
      }
    }
  }
  async function aiAsk(prompt, parts){ return (await aiGen('text', parts ? [prompt].concat(parts) : prompt)).trim(); }
  async function aiJSON(prompt, parts){ return JSON.parse((await aiGen('json', parts ? [prompt].concat(parts) : prompt)).replace(/```json|```/g, '').trim()); }
  function aiErr(e){
    const m = String(((e && e.code) ? e.code + ' ' : '') + ((e && e.message) || e || '')).replace(/https?:\/\/\S+/g, '').replace(/\s+/g, ' ');
    if(/app.?check/i.test(m)) return 'App Check doğrulaması başarısız. Firebase Console > App Check kaydını yapıp dosyadaki APPCHECK_SITE_KEY alanını doldurun.';
    if(/dynamically imported|importing a module|module script/i.test(m)) return 'Yapay zekâ modülü yüklenemedi (SDK dosyası açılamadı).';
    if(/\[\s*(500|502|503|504)\s*\]|high demand|overload|unavailable/i.test(m)) return 'Yapay zekâ şu an çok yoğun (Google tarafında geçici). Birkaç dakika sonra tekrar deneyin.';
    if(/404|not.?found|no longer available/i.test(m)) return 'Yapay zekâ modeli bulunamadı veya kapatılmış. Ayrıntı: ' + m.slice(0, 200);
    if(/api.?not.?enabled|403|permission|api.?key|forbidden/i.test(m)) return 'Yapay zekâ erişimi reddedildi. Firebase Console > AI Logic bölümünü etkinleştirdiniz mi? (' + m.slice(0, 120) + ')';
    if(/quota|429|resource.?exhausted/i.test(m)) return 'Yapay zekânın ücretsiz kotası doldu (dakikalık veya günlük). Birkaç dakika sonra tekrar deneyin; günlük kota yaklaşık sabah 10:00\'da (Türkiye saati) yenilenir.';
    if(navigator.onLine === false) return 'İnternet bağlantısı yok.';
    return 'Yapay zekâ hatası: ' + m.slice(0, 260);
  }
  function aiShowErr(msg){
    const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 1400;
    bg.innerHTML = '<div class="modal-box"><h3 style="margin:0 0 6px">⚠ Yapay zekâ</h3><p style="margin:0 0 10px;font-size:.92rem;line-height:1.45;word-break:break-word"></p><button class="btn-save" style="margin:0">Tamam</button></div>';
    bg.querySelector('p').textContent = msg; bg.querySelector('button').onclick = () => bg.remove(); document.body.appendChild(bg);
  }
  async function aiRun(btn, fn){
    const t = btn.textContent; btn.disabled = true; btn.textContent = '⏳ Düşünüyor…';
    try{ return await fn(); }
    catch(e){ console.error('AI', e); aiShowErr(aiErr(e)); }
    finally{ btn.disabled = false; btn.textContent = t; }
  }
  function aiRefreshUI(){
    const el = $id('aiStatus'); if(el) el.textContent = window.__fbApp ? '● Firebase bağlı — yapay zekâ kullanıma hazır (model: ' + AI_MODELS[AIM.i] + ')' : '● Yerel mod: yapay zekâ için Firebase bağlantısı gerekir.';
    renderTrList();
  }
  const allProds = () => categories.flatMap(c => c.products.map(p => ({ p, c })));
  const fixTL = v => Math.round((+v || 0) * 100) / 100;

  // ---- 1) Satış özeti ----
  function aiSales(days){
    const from = days === 1 ? dayStart() : Date.now() - days * 864e5, S = saleLog.filter(x => x.ts >= from), m = {}, hrs = {};
    S.forEach(x => { arr(x.items).forEach(i => { const o = m[i.name] || (m[i.name] = { adet: 0, ciro: 0 }); o.adet += i.qty; o.ciro = fixTL(o.ciro + i.qty * i.unit); }); const h = new Date(x.ts).getHours(); hrs[h] = (hrs[h] || 0) + 1; });
    const top = Object.entries(m).sort((a, b) => b[1].ciro - a[1].ciro).slice(0, 30).map(([ad, v]) => ({ ad, adet: v.adet, ciro: v.ciro }));
    const ciro = fixTL(S.reduce((a, x) => a + (x.total || 0), 0));
    return { donemGun: days, adisyonSayisi: S.length, toplamCiro: ciro, ortalamaAdisyon: S.length ? fixTL(ciro / S.length) : 0, toplamMisafir: S.reduce((a, x) => a + (x.guests || 0), 0), saatlereGoreAdisyon: hrs, urunler: top, toplamGiderKaydi: fixTL(giderler.reduce((a, g) => a + g.amount, 0)) };
  }
  $id('aiSumBtn').addEventListener('click', () => aiRun($id('aiSumBtn'), async () => {
    const d = aiSales(+$id('aiSumDays').value);
    if(!d.adisyonSayisi){ showToast('Bu dönemde satış kaydı yok.'); return; }
    const t = await aiAsk('Bir kafenin satış verisini yorumla. Türkçe, sade düz metin yaz (markdown, tablo, ** kullanma; madde için • kullan). Başlıklar: "Genel durum", "En çok satanlar", "Dikkat çeken noktalar", "Önerim (3 madde)". Veride olmayan sayı uydurma; veri azsa bunu belirt.\nVeri: ' + JSON.stringify(d));
    const o = $id('aiSumOut'); o.style.display = ''; o.textContent = t;
  }));

  // ---- 2) Menü açıklaması ----
  var aiDescRes = [];
  $id('aiDescBtn').addEventListener('click', () => aiRun($id('aiDescBtn'), async () => {
    const list = allProds().filter(x => !(x.p.desc || '').trim()).slice(0, 40);
    if(!list.length){ showToast('Tüm ürünlerin açıklaması dolu.'); return; }
    const out = arr(await aiJSON('Aşağıdaki kafe ürünleri için QR menüde görünecek, iştah açıcı, en fazla 90 karakterlik tek cümlelik Türkçe açıklama yaz. Ürün adında olmayan malzeme, içerik veya menşei UYDURMA; emin değilsen genel ve nötr kal. Ayrıca ürün adından makul biçimde çıkarılabilen olası alerjenleri ("süt","gluten","yumurta","fındık","susam","soya","deniz ürünü" gibi) "alerjen" dizisine yaz; emin değilsen boş bırak. Çıktı: [{"i":0,"aciklama":"...","alerjen":["..."]}] ("i" girdideki sıra numarasıdır).\nÜrünler: ' + JSON.stringify(list.map((x, i) => ({ i, ad: x.p.name, kategori: x.c.name })))));
    aiDescRes = list.map((x, i) => { const r = out.find(o => o && +o.i === i) || {}; return { p: x.p, desc: String(r.aciklama || '').trim(), al: arr(r.alerjen).map(String) }; }).filter(r => r.desc);
    const w = $id('aiDescOut');
    w.innerHTML = aiDescRes.map((r, i) => '<div class="ai-row"><input type="checkbox" data-d="' + i + '" checked><div style="flex:1;min-width:0"><b>' + esc(r.p.name) + '</b><br><input type="text" data-t="' + i + '" value="' + esc(r.desc) + '" style="width:100%">' + (r.al.length ? '<br><small>Olası alerjen: ' + esc(r.al.join(', ')) + '</small>' : '') + '</div></div>').join('') +
      '<div class="ai-row"><label><input type="checkbox" id="aiDescAl"> Olası alerjen notunu da ekle (taslak, kesin değildir)</label></div><div class="ai-row"><button class="btn-mini" id="aiDescApply">✔ Seçilenleri uygula</button></div>';
    $id('aiDescApply').onclick = () => {
      const withAl = $id('aiDescAl').checked; let n = 0;
      w.querySelectorAll('input[data-d]').forEach(cb => { if(!cb.checked) return; const i = +cb.dataset.d, r = aiDescRes[i], t = (w.querySelector('input[data-t="' + i + '"]').value || '').trim(); if(!t) return; r.p.desc = t + (withAl && r.al.length ? ' · Olası alerjenler: ' + r.al.join(', ') + ' (lütfen garsona sorun)' : ''); n++; });
      try{ renderCatList(); renderProductGrid(); }catch(e){} saveState(); publishPublic(); w.innerHTML = ''; showToast(n + ' ürün açıklaması uygulandı.');
    };
  }));

  // ---- 3) Menü çevirisi ----
  function renderTrList(){
    const w = $id('aiTrList'); if(!w) return; const tr = settings.trm || {};
    w.innerHTML = Object.keys(tr).filter(k => AI_LANGS[k]).map(k => '<div class="ai-row"><span style="flex:1">🌍 ' + AI_LANGS[k] + ' — ' + arr(tr[k]).length + ' metin</span><button class="btn-mini" data-del="' + k + '">Sil</button></div>').join('');
    w.querySelectorAll('[data-del]').forEach(b => b.onclick = () => { delete settings.trm[b.dataset.del]; saveState(); publishPublic(); renderTrList(); });
  }
  $id('aiTrBtn').addEventListener('click', () => aiRun($id('aiTrBtn'), async () => {
    const code = $id('aiTrLang').value, set = new Set(), btn = $id('aiTrBtn');
    categories.forEach(c => { [c.name, c.grp, c.sub].forEach(x => x && set.add(String(x))); c.products.forEach(p => { set.add(String(p.name)); if(p.desc) set.add(String(p.desc)); }); });
    arr(groupMeta).forEach(m => m && m.name && set.add(String(m.name)));
    const src = [...set].filter(x => x.trim()), res = {};
    for(let k = 0; k < src.length; k += 50){
      btn.textContent = '⏳ ' + Math.min(k + 50, src.length) + '/' + src.length;
      const chunk = src.slice(k, k + 50), out = arr(await aiJSON('Bir kafe menüsündeki metinleri Türkçeden ' + AI_LANGS[code] + ' diline çevir. Ürün adlarını doğal ve iştah açıcı çevir; marka ve özel isimleri (ör. Latte, Tiramisu) olduğu gibi bırak. Anlam ekleme veya çıkarma. Çıktı: [{"i":0,"t":"çeviri"}] ("i" girdideki sıradır).\nMetinler: ' + JSON.stringify(chunk.map((t, i) => ({ i, t })))));
      chunk.forEach((t, i) => { const r = out.find(o => o && +o.i === i); if(r && typeof r.t === 'string' && r.t.trim()) res[t] = r.t.trim(); });
    }
    const n = Object.keys(res).length; if(!n){ showToast('Çeviri alınamadı, tekrar deneyin.'); return; }
    settings.trm = settings.trm || {}; settings.trm[code] = Object.entries(res);
    saveState(); publishPublic(); renderTrList(); showToast(AI_LANGS[code] + ': ' + n + '/' + src.length + ' metin çevrildi, müşteri menüsüne eklendi.');
  }));
  function trMap(code){
    const raw = ((pubData && pubData.trm) || settings.trm || {})[code]; if(!raw) return null;
    if(_trC[code] && _trC[code].raw === raw) return _trC[code].m;
    const m = {}; arr(raw).forEach(p => { p = arr(p); if(p[0]) m[p[0]] = p[1]; }); _trC[code] = { raw, m }; return m;
  }
  function T(x){ if(!cLang || x == null) return x; const m = trMap(cLang); return (m && m[x]) || x; }
  function renderLangChips(){
    const el = $id('cLang'); if(!el) return;
    const codes = Object.keys((pubData && pubData.trm) || settings.trm || {}).filter(k => AI_LANGS[k]);
    if(cLang && codes.indexOf(cLang) < 0) cLang = '';
    const h = codes.length ? ['tr'].concat(codes).map(c => '<button type="button" class="' + ((c === 'tr' ? !cLang : c === cLang) ? 'on' : '') + '" data-l="' + c + '">' + c.toUpperCase() + '</button>').join('') : '';
    if(el.dataset.h !== h){ el.dataset.h = h; el.innerHTML = h; }
    el.style.display = h ? '' : 'none'; $id('customerView').dir = cLang === 'ar' ? 'rtl' : 'ltr';
  }
  $id('cLang').addEventListener('click', e => { const b = e.target.closest('button'); if(!b) return; cLang = b.dataset.l === 'tr' ? '' : b.dataset.l; try{ localStorage.setItem('cLang', cLang); }catch(x){} renderLangChips(); renderCustomer(); });

  // ---- 4) Müşteri menü asistanı ----
  function aiMenuText(){ return customerData().categories.map(c => c.products.map(p => c.name + ' | ' + p.name + ' | ' + p.price + ' TL' + (p.desc ? ' | ' + p.desc : '')).join('\n')).join('\n').slice(0, 14000); }
  function openAiChat(){
    const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 1300;
    bg.innerHTML = '<div class="modal-box"><h3 style="margin:0 0 6px">💬 Menü Asistanı</h3><div id="aiLog" style="max-height:44vh;overflow:auto"><div class="ai-bub a">Merhaba, hoş geldiniz! 😊 Bugün canınız ne çekiyor, nasıl bir şey arıyorsunuz? Birlikte bakalım.</div></div><div style="display:flex;gap:6px;margin-top:8px"><input id="aiQ" type="text" placeholder="Örn: tatlı bir şey, bol sütlü bir kahve…" style="flex:1;padding:10px;border:1px solid var(--line);border-radius:8px;background:var(--panel-2);color:var(--ink)"><button class="btn-save" id="aiSend" style="margin:0;width:auto;padding:0 14px">Gönder</button></div><button class="btn-save" id="aiClose" style="margin:8px 0 0;background:var(--ink-faint)">Kapat</button></div>';
    document.body.appendChild(bg);
    const log = bg.querySelector('#aiLog'), q = bg.querySelector('#aiQ'), send = bg.querySelector('#aiSend');
    const add = (c, t) => { const d = document.createElement('div'); d.className = 'ai-bub ' + c; d.textContent = t; log.appendChild(d); log.scrollTop = log.scrollHeight; };
    bg.querySelector('#aiClose').onclick = () => bg.remove();
    const go = async () => {
      const t = q.value.trim(); if(!t) return; q.value = '';
      if(aiChatN >= 10){ add('a', 'Soru sınırına ulaştınız. Lütfen garsonumuza danışın.'); return; }
      aiChatN++; add('u', t); send.disabled = true;
      try{
        const hist = aiChatHist.slice(-6).join('\n');
        const a = await aiAsk('Sen bir kafenin güler yüzlü, samimi dijital menü asistanısın. Birinci amacın satış yapmak DEĞİL, müşteriyi anlamak: canının ne çektiğini, keyfini, kiminle geldiğini, damak tadını ve acelesi olup olmadığını anlamaya çalış. İsteği belirsizse önce sıcak, tek ve kısa bir soru sor (örn. "Tatlı mı, ferah bir şey mi?"). Yeterince anladığında menüden 1-2 uygun ürün öner ve nedenini kısaca söyle. Asla baskı yapma, pahalı veya fazla ürün itme; müşteri bir şey almak istemezse de nazikçe saygı göster. SADECE aşağıdaki menüdeki ürünlerden öner; menüde olmayan ürün, malzeme, içerik veya fiyat UYDURMA. Alerji, hassasiyet, helal/vegan gibi kesin bilgi gerektiren konularda kesin konuşma, garsona sormalarını söyle. Müşterinin yazdığı dilde, en fazla 3-4 kısa cümleyle, sıcak ve doğal konuş (uygunsa tek bir emoji). Ürün önerirsen fiyatını TL olarak belirt. Sipariş alma; müşteri sepete kendisi ekler.\n\nMENÜ (kategori | ürün | fiyat | açıklama):\n' + aiMenuText() + '\n\nÖNCEKİ KONUŞMA:\n' + hist + '\n\nMÜŞTERİ: ' + t);
        add('a', a); aiChatHist.push('Müşteri: ' + t, 'Asistan: ' + a);
      }catch(e){ console.error('AI', e); add('a', (staffMode || /debug/.test(location.search)) ? 'Hata: ' + aiErr(e) : 'Şu an yanıt veremiyorum, lütfen garsonumuza danışın.'); }
      send.disabled = false; q.focus();
    };
    send.onclick = go; q.addEventListener('keydown', e => { if(e.key === 'Enter') go(); }); q.focus();
  }
  function aiCustUI(){ const b = $id('cAiBtn'); if(b) b.style.display = window.__fbApp ? '' : 'none'; const n = $id('cNoteAi'); if(n) n.style.display = (window.__fbApp && $id('cNote').style.display !== 'none') ? '' : 'none'; }
  $id('cAiBtn').addEventListener('click', openAiChat);

  // ---- 5) Sipariş notu düzenleme ----
  async function aiCleanNote(t){
    return (await aiAsk('Bir kafede müşteri/garson sipariş notunu mutfak ekranı için düzenle: kısa, net, virgülle ayrılmış olsun; gereksiz kelimeleri at; YENİ BİLGİ EKLEME, anlamı değiştirme. Alerji veya hassasiyet varsa mutlaka koru ve notu "ALERJİ:" ile başlat. Yalnızca düzenlenmiş notu yaz, tırnak veya açıklama ekleme.\nNot: ' + JSON.stringify(t))).replace(/^["'`]+|["'`]+$/g, '').slice(0, 200);
  }
  $id('cNoteAi').addEventListener('click', () => { const el = $id('cNote'), v = el.value.trim(); if(v.length < 4) return; aiRun($id('cNoteAi'), async () => { el.value = await aiCleanNote(v); }); });
  function aiAttachNoteBtn(id){
    const el = $id(id); if(!el || el.dataset.ai || !window.__fbApp) return; el.dataset.ai = '1';
    const b = document.createElement('button'); b.type = 'button'; b.className = 'btn-mini'; b.textContent = '✨ Mutfak için düzenle'; b.style.marginTop = '6px';
    b.onclick = () => { const v = el.value.trim(); if(!v){ showToast('Önce notu yazın.'); return; } aiRun(b, async () => { el.value = await aiCleanNote(v); }); };
    el.insertAdjacentElement('afterend', b);
  }

  // ---- 6) Stok & fiyat önerisi ----
  $id('aiStkBtn').addEventListener('click', () => aiRun($id('aiStkBtn'), async () => {
    const from = Date.now() - 14 * 864e5, S = saleLog.filter(x => x.ts >= from), m = {}, days = new Set();
    S.forEach(x => { days.add(new Date(x.ts).toDateString()); arr(x.items).forEach(i => { const o = m[i.name] || (m[i.name] = { adet: 0, ciro: 0 }); o.adet += i.qty; o.ciro = fixTL(o.ciro + i.qty * i.unit); }); });
    if(!S.length){ showToast('Son 14 günde satış kaydı yok.'); return; }
    const price = {}; allProds().forEach(x => { price[x.p.name] = x.p.price; });
    const sold = Object.entries(m).sort((a, b) => b[1].adet - a[1].adet).slice(0, 40).map(([ad, v]) => ({ ad, adet: v.adet, ciro: v.ciro, fiyat: price[ad] }));
    const unsold = allProds().filter(x => !m[x.p.name]).slice(0, 25).map(x => ({ ad: x.p.name, fiyat: x.p.price }));
    const t = await aiAsk('Bir kafe için satış verisine göre öneri hazırla. Türkçe, sade düz metin (markdown, tablo, ** yok; madde için •). Başlıklar: "Hazırlık / stok önerisi" (çok satanlar için günlük ortalama ve haftalık tahmini adet; veride kaç günlük kayıt olduğunu hesaba kat), "Az satanlar" (menüden çıkarma, kampanya veya yeniden konumlandırma fikri), "Fiyat fikirleri" (en fazla 5 madde, küçük ve gerekçeli; maliyet verisi yok, bunu belirt). Kesin karar verme, öneri dili kullan; veride olmayan sayı uydurma.\nKayıtlı gün sayısı: ' + days.size + '\nSatılanlar: ' + JSON.stringify(sold) + '\nSon 14 günde hiç satılmayanlar: ' + JSON.stringify(unsold));
    const o = $id('aiStkOut'); o.style.display = ''; o.textContent = t + '\n\n⚠ Bunlar tahmindir; maliyet, sezon ve stok durumunuzu kendiniz değerlendirin.';
  }));

  // ---- 7) Fotoğraftan veri girişi ----
  function aiFilePart(file){
    return new Promise((res, rej) => {
      const fr = new FileReader(); fr.onerror = () => rej(new Error('Dosya okunamadı'));
      fr.onload = () => { const im = new Image(); im.onerror = () => rej(new Error('Görsel açılamadı'));
        im.onload = () => { const k = Math.min(1, 1600 / Math.max(im.width, im.height)), cv = document.createElement('canvas'); cv.width = Math.round(im.width * k); cv.height = Math.round(im.height * k); cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height); res({ inlineData: { data: cv.toDataURL('image/jpeg', 0.85).split(',')[1], mimeType: 'image/jpeg' } }); };
        im.src = fr.result; };
      fr.readAsDataURL(file);
    });
  }
  $id('aiPhotoBtn').addEventListener('click', () => aiRun($id('aiPhotoBtn'), async () => {
    const f = $id('aiPhoto').files[0]; if(!f){ showToast('Önce bir fotoğraf seçin.'); return; }
    const r = await aiJSON('Bu görsel bir kafe/işletme fişi, faturası veya el yazısı listesidir. İçindekileri oku. Okuyamadığın veya emin olmadığın alanı boş ("") ya da 0 bırak, UYDURMA. Çıktı: {"tedarikci":"","tarih":"gg.aa.yyyy","toplam":0,"kalemler":[{"ad":"","adet":0,"birimFiyat":0,"tutar":0}]}', [await aiFilePart(f)]);
    const kal = arr(r.kalemler), sum = fixTL(kal.reduce((a, k) => a + (+k.tutar || 0), 0)), tot = +r.toplam || sum, o = $id('aiPhotoOut');
    o.innerHTML = '<div class="ai-row"><b>Gider adı</b><input type="text" id="aiPhName" value="' + esc(r.tedarikci ? r.tedarikci + ' — fiş/fatura' : 'Fiş / Fatura') + '"></div>' +
      '<div class="ai-row"><b>Tutar (₺)</b><input type="text" id="aiPhAmt" inputmode="decimal" value="' + tot + '"></div>' +
      '<div class="ai-row"><b>Tarih</b><input type="text" id="aiPhDate" placeholder="gg.aa.yyyy" value="' + esc(r.tarih || '') + '"></div>' +
      kal.map(k => '<div class="ai-row"><span style="flex:1">' + esc(k.ad || '?') + ' · ' + (+k.adet || 0) + ' × ' + (+k.birimFiyat || 0) + '</span><b>₺' + (+k.tutar || 0) + '</b></div>').join('') +
      '<div class="ai-row"><small style="flex:1">Okunan rakamları mutlaka kontrol edin; gerekirse yukarıdaki alanları düzeltin.</small><button class="btn-mini" id="aiPhAdd">＋ Gider olarak ekle</button></div>';
    $id('aiPhAdd').onclick = () => {
      const name = $id('aiPhName').value.trim(), amount = parseFloat(String($id('aiPhAmt').value).replace(',', '.')), dt = $id('aiPhDate').value.trim();
      if(!name || !(amount > 0)){ showToast('Gider adı ve geçerli bir tutar gerekli.'); return; }
      giderler.push({ name, amount: fixTL(amount), date: /^\d{1,2}\.\d{1,2}\.\d{4}$/.test(dt) ? dt : new Date().toLocaleDateString('tr-TR') });
      renderGiderler(); saveState(); o.innerHTML = ''; $id('aiPhoto').value = ''; showToast(name + ' gider olarak eklendi.');
    };
  }));

  $id('aiTestBtn').addEventListener('click', async () => {
    const o = $id('aiTestOut'); o.style.display = ''; o.textContent = '⏳ Test ediliyor…';
    try{ const t = await aiAsk('Sadece "tamam" yaz.'); o.textContent = '✔ Çalışıyor. Yanıt: ' + t; }
    catch(e){ console.error('AI', e); o.textContent = '✖ ' + aiErr(e) + '\n\nTeknik ayrıntı:\n' + String((e && e.code) || '') + ' ' + String((e && e.message) || e).slice(0, 700) + '\n\nApp Check anahtarı: ' + (APPCHECK_SITE_KEY ? 'tanımlı (' + (APPCHECK_ENTERPRISE ? 'Enterprise' : 'v3') + ')' : 'boş') + '\nSDK: ' + window.__fbB; }
  });
  document.querySelectorAll('.nav-item[data-screen="ai"]').forEach(el => el.addEventListener('click', aiRefreshUI));
  aiRefreshUI();


  // =====================================================================
  // YÖNETİCİ SORU-CEVAP + OTOMATİK ÜRÜN GÖRSELİ
  // =====================================================================
  const APP_GUIDE = `Sistem: ${APP_CONFIG.brand.name} adisyon / dijital menü uygulaması. Sol menü ve ekranlar:
- Ana Sayfa: bugünkü satış, misafir, açık sipariş, gider ve grafikler (yalnızca rapor yetkisi olanlar).
- Dijital Menü: masa seçip müşteri QR kodunu gösterir/yazdırmaya hazırlar.
- Yapay Zekâ: satış özeti, menü açıklaması yazma, menü çevirisi, stok/fiyat önerisi, fotoğraftan gider girişi, bağlantı testi.
- Tanımlamalar: Masa/Bölgeler (bölge, masa ekleme, toplu masa, ad değiştirme/silme), Menü/Ürünler (ana kategori > alt kategori, ürün ekle/düzenle, toplu fiyat düzenleme, toplu fotoğraf, "Sadece menü modu" anahtarı), Birimler, Özellikler (sipariş notları), KDV Oranları (★ ile varsayılan), İndirimler, Mutfak Grupları (Mutfak/Bar/Nargile ekranlarına yönlendirme), Müşteriler (açık hesap, tahsilat, CSV indir), Ödenmezler (ikram gerekçeleri).
- Sipariş: Bölgeler (masalar; beyaz boş, kırmızı sipariş bekliyor/mutfakta, yeşil teslim edilmiş) ve Siparişler (kanban) sekmeleri; ⛶ tam ekran, 📶 bağlantı durumu, ↻ yenile. Masaya tıklayınca menüden ürün seçilir, "Sepeti Gör > Onayla ve Kaydet" ile mutfağa gider.
- Adisyon ekranında: kişi sayısı, ürün notu, ⇄ Ürün/Masa Taşı, ✕ Adisyonu İptal (neden + yönetici PIN), 💳 Ödeme Al (nakit, kart, açık hesap, hesap bölme, indirim, ikram), 🖨️ fiş yazdır, ✎ masaya müşteri adı.
- Paket / Gel-Al: yeni sipariş, yola çıktı / hazır işaretleme.
- İşlemler: Gider/Masraf, Zayi.
- Kullanıcılar: kullanıcı ekleme (görev, şifre, bölge, engelleme) ve Yetkiler tablosu (görev bazlı).
- Raporlar: Ürün Satış, Gün Sonu (Günü Kapat, geçmiş günler, iptal kayıtları, CSV), Vardiya, Restaurant İstatistikleri, Fire.
- Ayarlar: Genel (restoran adı, gün başlangıcı, vardiya saati, ilk adisyon no, Wi-Fi adı/şifresi, yönetici PIN), Ödeme Tipleri, Yedek & Sistem (yedek indir/yükle, verileri sıfırla).
- Sağ üst: 🔔 müşteri siparişleri onayı, 👨‍🍳 mutfak ekranı, ❓ soru sor, ⎋ çıkış, güneş/ay ile karanlık mod.
- Müşteri tarafı: logoya 4 kez dokunmak personel girişini açar.`;
  let askHist = [];
  function askContext(){
    let d = 'Menüde ' + categories.reduce((n, c) => n + c.products.length, 0) + ' ürün, ' + categories.length + ' alt kategori var; ' + regions.reduce((n, r) => n + r.tables.length, 0) + ' masa tanımlı; açık adisyon: ' + Object.keys(carts).filter(k => (carts[k] || []).length).length + '.';
    if(can('reports')){ try{ d += '\nSatış verisi (son 7 gün): ' + JSON.stringify(aiSales(7)).slice(0, 5000); }catch(e){} }
    return d;
  }
  function openAskAdmin(){
    if(!window.__fbApp){ showToast('Soru sorma için Firebase (canlı) bağlantısı gerekir.'); return; }
    const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 1400;
    bg.innerHTML = '<div class="modal-box" style="max-width:560px"><h3 style="margin:0 0 4px">❓ Soru Sor</h3><p style="margin:0 0 8px;font-size:.82rem;color:var(--ink-faint)">Uygulamada bir şeyin nerede olduğunu, nasıl yapılacağını veya satışlarınızı sorun.</p><div id="askLog" style="max-height:46vh;overflow:auto"></div><div style="display:flex;gap:6px;margin-top:8px"><input id="askQ" type="text" placeholder="Örn: Ürün fiyatlarını nasıl toplu artırırım?" style="flex:1;padding:10px;border:1px solid var(--line);border-radius:8px;background:var(--panel-2);color:var(--ink)"><button class="btn-save" id="askSend" style="margin:0;width:auto;padding:0 14px">Sor</button></div><button class="btn-save" id="askClose" style="margin:8px 0 0;background:var(--ink-faint)">Kapat</button></div>';
    document.body.appendChild(bg);
    const log = bg.querySelector('#askLog'), q = bg.querySelector('#askQ'), send = bg.querySelector('#askSend');
    const add = (c, t) => { const d = document.createElement('div'); d.className = 'ai-bub ' + c; d.textContent = t; log.appendChild(d); log.scrollTop = log.scrollHeight; };
    if(!askHist.length) add('a', 'Merhaba! Uygulamayla ilgili ne öğrenmek istersiniz?'); else askHist.forEach(h => add(h.r, h.t));
    bg.querySelector('#askClose').onclick = () => bg.remove();
    const go = async () => {
      const t = q.value.trim(); if(!t) return; q.value = ''; add('u', t); askHist.push({ r: 'u', t }); send.disabled = true;
      try{
        const hist = askHist.slice(-9, -1).map(h => (h.r === 'u' ? 'Yönetici: ' : 'Asistan: ') + h.t).join('\n');
        const a = await aiAsk('Sen bir kafe adisyon uygulamasının yardımcısısın; kullanıcı işletme yöneticisi/personeli. Türkçe, kısa ve net yanıtla (düz metin, markdown yok; adımları 1) 2) ile yaz). Uygulama soruları için aşağıdaki rehberi kullan ve hangi menü/ekranda hangi düğmeye basılacağını söyle. Rehberde olmayan bir özelliği VAR diye uydurma; yoksa dürüstçe söyle. Satış/işletme sorularında yalnızca verilen veriye dayan, veri yoksa uydurma. Genel işletme/kafe sorularına da kısa yardımcı ol.\n\nREHBER:\n' + APP_GUIDE + '\n\nGÜNCEL DURUM:\n' + askContext() + '\n\nÖNCEKİ KONUŞMA:\n' + hist + '\n\nSORU: ' + t);
        add('a', a); askHist.push({ r: 'a', t: a });
      }catch(e){ console.error('AI', e); add('a', 'Hata: ' + aiErr(e)); }
      send.disabled = false; q.focus();
    };
    send.onclick = go; q.addEventListener('keydown', e => { if(e.key === 'Enter') go(); }); q.focus();
  }
  $id('btnAsk').addEventListener('click', openAskAdmin);

  // ---- OTOMATİK GÖRSEL: ürün / alt kategori / ana kategori kaydedilirken görsel yoksa üretilir ----
  // Zincir: Gemini görsel modelleri -> Imagen -> Pollinations (yapay zekâ) -> Wikimedia Commons (gerçek fotoğraf, yapay zekâ doğrulamalı)
  // Hiçbiri çalışmazsa ürüne uygun çizim JPEG olarak KAYDEDİLİR (alan asla boş kalmaz) ve arka planda 10 dk'da bir gerçek görsel yeniden denenir.
  const IMGLOG = [], provDead = {}, imgQ = [], imgProm = new Map(), imgTry = new Map(); let imgBusy = false;
  const sigOf = x => (x || '').length + ':' + (x || '').slice(-40);
  const wt = (pr, ms, l) => Promise.race([pr, new Promise((_, rj) => setTimeout(() => rj(new Error(l + ' zaman aşımı')), ms))]);
  function imgNote(m){ IMGLOG.unshift(new Date().toLocaleTimeString('tr-TR') + ' · ' + m); IMGLOG.length = Math.min(IMGLOG.length, 40); console.warn('[görsel]', m); }
  function blobToThumb(blob, max){
    return new Promise(res => { const u = URL.createObjectURL(blob), im = new Image(); im.onerror = () => { URL.revokeObjectURL(u); res(''); };
      im.onload = () => { let d = ''; try{ const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); d = c.toDataURL('image/jpeg', 0.78); }catch(e){} URL.revokeObjectURL(u); res(d); }; im.src = u; });
  }
  function dataUrlToThumb(dataUrl, max){
    return new Promise(res => { const im = new Image(); im.onerror = () => res(''); im.onload = () => { try{ const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', 0.78)); }catch(e){ res(''); } }; im.src = dataUrl; });
  }
  async function pGemini(model, prompt){
    await aiInit(); const m = AIM.gm(AIM.ai, { model, generationConfig: { responseModalities: ['TEXT', 'IMAGE'] } });
    const r = await wt(m.generateContent(prompt), 70000, model);
    for(const c of (r.response.candidates || [])) for(const pt of ((c.content || {}).parts || [])) if(pt.inlineData && pt.inlineData.data){ const d = await dataUrlToThumb('data:' + (pt.inlineData.mimeType || 'image/png') + ';base64,' + pt.inlineData.data, 420); if(d) return d; }
    throw new Error('yanıtta görsel yok' + (r.response.promptFeedback && r.response.promptFeedback.blockReason ? ' (' + r.response.promptFeedback.blockReason + ')' : ''));
  }
  async function pImagen(model, prompt){
    await aiInit(); const mod = await import(window.__fbB + 'firebase-ai.js');
    const m = mod.getImagenModel(AIM.ai, { model, generationConfig: { numberOfImages: 1, aspectRatio: '1:1' } });
    const r = await wt(m.generateImages(prompt), 70000, model), im = (r.images || [])[0];
    if(!im) throw new Error('görsel yok' + (r.filteredReason ? ' (' + r.filteredReason + ')' : ''));
    const d = await dataUrlToThumb('data:' + (im.mimeType || 'image/png') + ';base64,' + im.bytesBase64Encoded, 420); if(!d) throw new Error('görsel okunamadı'); return d;
  }
  async function pPollinations(prompt){
    const r = await wt(fetch('https://image.pollinations.ai/prompt/' + encodeURIComponent(prompt) + '?width=512&height=512&nologo=true&model=flux&seed=' + Math.floor(Math.random() * 1e6)), 70000, 'pollinations');
    if(!r.ok) throw new Error('HTTP ' + r.status); const b = await r.blob();
    if(!/^image\//.test(b.type) || b.size < 4000) throw new Error('geçersiz yanıt'); const d = await blobToThumb(b, 420); if(!d) throw new Error('görsel okunamadı'); return d;
  }
  async function pCommons(en, name){
    const api = 'https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrlimit=10&gsrsearch=' + encodeURIComponent(en + ' filetype:bitmap') + '&prop=imageinfo&iiprop=url|mime|size&iiurlwidth=600&format=json&origin=*';
    const j = await (await wt(fetch(api), 20000, 'commons')).json();
    const pages = Object.values((j.query || {}).pages || {}).sort((a, b) => a.index - b.index); let tried = 0;
    for(const pg of pages){
      const ii = (pg.imageinfo || [])[0]; if(!ii || !/jpeg/.test(ii.mime) || ii.width < 400 || !ii.thumburl) continue; if(++tried > 5) break;
      let d = ''; try{ const rb = await wt(fetch(ii.thumburl), 25000, 'foto'); if(!rb.ok) continue; d = await blobToThumb(await rb.blob(), 420); }catch(e){ continue; } if(!d) continue;
      try{ const ans = await aiAsk('Bu görsel, bir kafe menüsünde "' + name + '" (' + en + ') için kullanılabilecek, doğru ve iştah açıcı bir ürün fotoğrafı mı? İçinde insan yüzü, yazı veya alakasız konu varsa HAYIR de. Yalnızca EVET veya HAYIR yaz.', [{ inlineData: { data: d.split(',')[1], mimeType: 'image/jpeg' } }]); if(!/^\s*evet/i.test(ans)) continue; }catch(e){ /* doğrulama yapılamadıysa ilk uygun fotoğraf kabul edilir */ }
      return d;
    }
    throw new Error('uygun fotoğraf bulunamadı');
  }
  function rasterFallback(name, icon){
    return new Promise(res => {
      const c = document.createElement('canvas'); c.width = 420; c.height = 315; const x = c.getContext('2d'), h = artHue(name), g = x.createLinearGradient(0, 0, 420, 315);
      g.addColorStop(0, 'hsl(' + h + ',90%,91%)'); g.addColorStop(1, 'hsl(' + ((h + 40) % 360) + ',85%,82%)'); x.fillStyle = g; x.fillRect(0, 0, 420, 315);
      const done = () => { try{ res(c.toDataURL('image/jpeg', 0.8)); }catch(e){ res(''); } };
      const emo = () => { x.font = '140px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(icon || '🍽️', 210, 158); done(); };
      const src = illus(name); if(!src){ emo(); return; }
      const im = new Image(); im.onload = () => { x.drawImage(im, 60, 20, 300, 225); done(); }; im.onerror = emo; im.src = src;
    });
  }
  async function enName(j){
    try{ const t = await aiAsk('Bir kafe menüsündeki "' + j.name + '" (' + j.ctx + ') için görsel arama/üretimi amacıyla kısa İngilizce karşılık yaz (en fazla 6 kelime, örn. "turkish black olives in a bowl"). Yalnızca karşılığı yaz.'); return t.replace(/["'`\n]/g, '').slice(0, 80) || j.name; }catch(e){ return j.name; }
  }
  const imgPrompt = (j, en) => j.kind === 'prod'
    ? 'Professional appetizing food photography of ' + en + ', served at a cafe, 45 degree angle, soft natural light, clean light neutral background, single subject centered, photorealistic, no text, no logo, no watermark, no people'
    : 'Professional appetizing food and drink photography representing the menu category "' + en + '", a styled arrangement on a table, soft natural light, clean light background, photorealistic, no text, no logo, no watermark, no people';
  function provList(en, name, prompt){
    return [
      { key: 'gem1', label: 'Gemini görsel (2.5 flash image)', fn: () => pGemini('gemini-2.5-flash-image', prompt) },
      { key: 'gem2', label: 'Gemini görsel (preview)', fn: () => pGemini('gemini-2.5-flash-image-preview', prompt) },
      { key: 'img1', label: 'Imagen 4 fast', fn: () => pImagen('imagen-4.0-fast-generate-001', prompt) },
      { key: 'img2', label: 'Imagen 4', fn: () => pImagen('imagen-4.0-generate-001', prompt) },
      { key: 'poll', label: 'Pollinations (yapay zekâ)', fn: () => pPollinations(prompt) },
      { key: 'comm', label: 'Wikimedia Commons (gerçek fotoğraf)', fn: () => pCommons(en, name) }
    ];
  }
  const jobTarget = j => {
    if(j.kind === 'grp'){ const g = menuGroups(categories).find(x => x.name === j.name), m = groupMeta.find(x => x.name === j.name) || {}; return { img: g ? g.img : '', auto: m.imgAuto, ok: !!g }; }
    return { img: j.obj.img, auto: j.obj.imgAuto, ok: categories.some(c => c === j.obj || c.products.indexOf(j.obj) >= 0) };
  };
  const jobKey = j => j.kind + ':' + (j.kind === 'grp' ? j.name : (j.obj.name + '|' + (j.obj.sub || '')));
  function applyImg(j, d, real){
    const sig = real ? undefined : sigOf(d);
    if(j.kind === 'grp'){
      gmSet(j.name, { img: d, imgAuto: sig }); if(real){ const m = groupMeta.find(x => x.name === j.name); if(m) delete m.imgAuto; }
      categories.forEach(c => { if(grpName(c) === j.name && !c.sub){ c.img = d; if(real) delete c.imgAuto; else c.imgAuto = sig; } });
    } else { j.obj.img = d; if(real) delete j.obj.imgAuto; else j.obj.imgAuto = sig; }
    menuRender(); saveState(); publishPublic();
  }
  async function imgRun(j){
    const t = jobTarget(j); if(!t.ok) return false;
    if(imgOk(t.img) && !(t.auto && t.auto === sigOf(t.img))) return true;   // arada görsel yüklendiyse dokunma
    let d = '', via = '';
    if(window.__fbApp){
      showToast('🎨 “' + j.name + '” için görsel hazırlanıyor…', 4000);
      const en = await enName(j), prompt = imgPrompt(j, en);
      for(const pv of provList(en, j.name, prompt)){
        if((provDead[pv.key] || 0) > Date.now()) continue;
        try{ d = await pv.fn(); if(d){ via = pv.label; break; } }
        catch(e){ const m = String((e && e.message) || e).replace(/https?:\/\/\S+/g, '').slice(0, 160); imgNote(j.name + ' · ' + pv.label + ' ✖ ' + m); provDead[pv.key] = Date.now() + (/404|not.?found|permission|403|billing|quota|429|not supported|invalid|app.?check/i.test(m) ? 20 * 60000 : 2 * 60000); }
      }
    }
    const real = !!d;
    if(!d) d = await rasterFallback(j.name, j.obj && j.obj.icon);
    if(!d){ imgNote(j.name + ' · hiçbir görsel üretilemedi'); return false; }
    // kullanıcı bu sırada kendi görselini yüklediyse ezme
    const t2 = jobTarget(j); if(imgOk(t2.img) && !(t2.auto && t2.auto === sigOf(t2.img))) return true;
    applyImg(j, d, real);
    showToast(real ? '✔ “' + j.name + '” görseli oluşturuldu' + (via ? ' (' + via + ')' : '') + '.' : '“' + j.name + '” için geçici görsel kaydedildi; gerçek görsel arka planda yeniden denenecek.', 3500);
    return real;
  }
  async function imgPump(){
    if(imgBusy) return; imgBusy = true;
    try{ while(imgQ.length){ const j = imgQ.shift(); let ok = false; try{ ok = await imgRun(j); }catch(e){ imgNote(j.name + ' · iş hatası: ' + ((e && e.message) || e)); } imgProm.delete(jobKey(j)); j.res(ok); await new Promise(r => setTimeout(r, 700)); } }
    finally{ imgBusy = false; }
  }
  function imgQueue(kind, target, ctxCat, retry){
    let j;
    if(kind === 'cat' && !target.sub){ kind = 'grp'; target = grpName(target); }
    if(kind === 'grp') j = { kind, name: target, ctx: 'ana kategori' };
    else if(kind === 'cat') j = { kind, obj: target, name: target.sub || target.name, ctx: grpName(target) };
    else j = { kind: 'prod', obj: target, name: target.name, ctx: ctxCat ? catLabel(ctxCat) : '' };
    const t = jobTarget(j); if(!t.ok) return Promise.resolve(false);
    if(imgOk(t.img) && !(retry && t.auto && t.auto === sigOf(t.img))) return Promise.resolve(true);
    const k = jobKey(j); if(imgProm.has(k)) return imgProm.get(k);
    const pr = new Promise(res => { j.res = res; }); imgProm.set(k, pr); imgQ.push(j); imgPump(); return pr;
  }
  // geçici (çizim) görselli öğeler 10 dakikada bir gerçek görsel için yeniden denenir
  function imgRetryScan(){
    if(!staffMode || !window.__fbApp || !can('menu')) return;
    const due = k => { const n = Date.now(); if(n - (imgTry.get(k) || 0) < 10 * 60000) return false; imgTry.set(k, n); return true; }, auto = o => o && o.imgAuto && o.imgAuto === sigOf(o.img);
    categories.forEach(c => { if(c.sub && auto(c) && due('c' + c.name)) imgQueue('cat', c, null, true); c.products.forEach(pr => { if(auto(pr) && due('p' + pr.name)) imgQueue('prod', pr, c, true); }); });
    groupMeta.forEach(m => { if(auto(m) && due('g' + m.name)) imgQueue('grp', m.name, null, true); });
  }
  setInterval(imgRetryScan, 60000); setTimeout(imgRetryScan, 20000);

  // ---- Yapay Zekâ ekranı: toplu üretim + tanılama ----
  (function(){
    const card = document.createElement('div'); card.className = 'panel-card';
    card.innerHTML = '<div class="panel-head"><div class="pi">🎨</div><div><h2>Görsel üretimi</h2><p>Yeni ürün / alt kategori / ana kategori kaydedilirken görseli yoksa otomatik hazırlanır. Buradan eksikleri toplu üretebilir ve hangi kaynağın çalıştığını test edebilirsiniz.</p></div></div>' +
      '<div class="ai-row"><button class="btn-mini" id="aiImgBtn">✨ Eksik görselleri üret (10’ar)</button><button class="btn-mini" id="aiImgTest">🧪 Görsel üretim testi</button><span id="aiImgSt" class="ai-st"></span></div><div class="ai-out" id="aiImgDiag" style="display:none"></div>';
    $id('screen-ai').appendChild(card);
    $id('aiImgBtn').addEventListener('click', () => aiRun($id('aiImgBtn'), async () => {
      const miss = [];
      menuGroups(categories).forEach(g => { if(!imgOk(g.img)) miss.push(['grp', g.name]); g.subs.forEach(sb => { if(sb.cat.sub && !imgOk(sb.cat.img)) miss.push(['cat', sb.cat]); }); });
      categories.forEach(c => c.products.forEach(pr => { if(!imgOk(pr.img)) miss.push(['prod', pr, c]); }));
      const list = miss.slice(0, 10); if(!list.length){ showToast('Tüm ürün ve kategorilerin görseli var.'); return; }
      let ok = 0; for(let i = 0; i < list.length; i++){ const x = list[i]; $id('aiImgSt').textContent = (i + 1) + '/' + list.length; if(await imgQueue(x[0], x[1], x[2])) ok++; }
      $id('aiImgSt').textContent = ok + ' gerçek görsel eklendi, ' + (list.length - ok) + ' tanesi geçici görselle kaldı (arka planda yeniden denenecek); toplam eksik: ' + (miss.length - list.length);
    }));
    $id('aiImgTest').addEventListener('click', () => aiRun($id('aiImgTest'), async () => {
      const o = $id('aiImgDiag'); o.style.display = ''; o.innerHTML = '⏳ Test ediliyor…'; let html = '', first = '';
      const en = 'turkish black olives in a bowl', pr = imgPrompt({ kind: 'prod' }, en);
      for(const pv of provList(en, 'Kırmızı Zeytin', pr)){
        const t0 = Date.now();
        try{ const d = await pv.fn(); html += '✔ ' + pv.label + ' — ' + Math.round((Date.now() - t0) / 1000) + ' sn\n'; if(!first) first = d; }
        catch(e){ html += '✖ ' + pv.label + ' — ' + String((e && e.message) || e).replace(/https?:\/\/\S+/g, '').slice(0, 220) + '\n'; }
        o.textContent = html + '…';
      }
      o.textContent = html + (IMGLOG.length ? '\nSon hatalar:\n' + IMGLOG.slice(0, 8).join('\n') : '');
      if(first){ const im = document.createElement('img'); im.src = first; im.style.cssText = 'display:block;margin-top:10px;max-width:220px;border-radius:10px'; o.appendChild(im); }
    }));
  })();


  // =====================================================================
  // MÜŞTERİ EKRANI ŞİFRESİ + YENİ KENAR MENÜ İŞLEVLERİ
  // Not: şifre kapısı arayüz düzeyindedir (menüyü yalnızca masadakilere göstermek / sahte siparişi azaltmak için); veritabanı kuralı değildir.
  // =====================================================================
  const custHashOf = pw => sha256('posmusteri|' + pw);
  const CU_KEY = 'posCustOK'; let custOKmem = '', custFails = 0, custLockUntil = 0;
  function custPwHash(){ if(pubData) return pubData.custPw || ''; return (typeof RT !== 'undefined' && RT.local && settings.custPw) ? custHashOf(settings.custPw) : ''; }
  function custGateNeeded(){
    const h = custPwHash(); if(!h) return false;
    let ok = custOKmem; try{ ok = localStorage.getItem(CU_KEY) || ok; }catch(e){}
    return ok !== h;
  }
  function ensureGate(){
    let g = $id('custGate'); if(g) return g;
    g = document.createElement('div'); g.id = 'custGate';
    g.innerHTML = '<div class="cg-box"><div class="cg-logo" id="cgLogo"></div><h2>' + esc(settings.restName || 'Menü') + '</h2><p>Menüyü görmek için masanızdaki şifreyi girin.</p><input id="cgPw" type="password" inputmode="text" autocomplete="off" placeholder="Şifre"><div class="cg-err" id="cgErr"></div><button class="go" id="cgGo" type="button">Menüyü Aç</button></div>';
    document.body.appendChild(g);
    try{ $id('cgLogo').innerHTML = $id('cLogo').innerHTML; }catch(e){}
    $id('cgLogo').addEventListener('click', () => onLogoTap());   // personel girişi: logoya 4 dokunuş
    const go = () => {
      const err = $id('cgErr'), now = Date.now();
      if(now < custLockUntil){ err.textContent = Math.ceil((custLockUntil - now) / 1000) + ' sn bekleyin.'; return; }
      const v = $id('cgPw').value.trim(), h = custPwHash(); if(!v) return;
      if(custHashOf(v) === h){ custOKmem = h; try{ localStorage.setItem(CU_KEY, h); }catch(e){} custFails = 0; $id('cgPw').value = ''; err.textContent = ''; renderCustomer(); }
      else{ custFails++; if(custFails >= 5){ custFails = 0; custLockUntil = Date.now() + 30000; err.textContent = 'Çok fazla deneme. 30 sn bekleyin.'; } else err.textContent = 'Şifre hatalı.'; $id('cgPw').select(); }
    };
    $id('cgGo').addEventListener('click', go); $id('cgPw').addEventListener('keydown', e => { if(e.key === 'Enter') go(); });
    return g;
  }
  function showCustGate(){ const g = ensureGate(); g.classList.add('show'); document.body.classList.add('cust-locked'); }
  function hideCustGate(){ const g = $id('custGate'); if(g) g.classList.remove('show'); document.body.classList.remove('cust-locked'); }

  function custLockRender(){
    const on = !!settings.custPw, c = $id('custLockCard'); if(!c) return;
    c.classList.toggle('on', on); $id('clIc').textContent = on ? '🔒' : '🔓';
    $id('clState').textContent = on ? 'Korumalı · müşteri şifre girer' : 'Kapalı · menü herkese açık';
    $id('clAct').textContent = on ? 'Değiştir' : 'Ayarla';
  }
  function openCustPw(){
    if(!can('settings')){ showToast('Bu işlem için yetkiniz yok.'); return; }
    const bg = document.createElement('div'); bg.className = 'modal-bg show'; bg.style.zIndex = 3000;
    bg.innerHTML = '<div class="modal-box" role="dialog" aria-modal="true"><h3 style="margin:0 0 4px">🔒 Müşteri ekranı şifresi</h3><p style="margin:0 0 12px;font-size:.84rem;color:var(--ink-dim);line-height:1.45">Şifre belirlerseniz müşteriler QR ile menüyü açtığında önce bu şifreyi girer. Şifreyi masalara yazabilir veya garsonlarla paylaşabilirsiniz. Şifreyi değiştirdiğinizde herkesten yeniden istenir.</p><div style="display:flex;gap:6px"><input id="cpIn" type="text" maxlength="24" autocomplete="off" placeholder="En az 3 karakter" style="flex:1"><button class="btn-mini" id="cpRnd" type="button">🎲 Rastgele</button></div><div id="cpErr" style="color:var(--red);font-size:.82rem;min-height:18px;margin-top:6px"></div><div style="display:flex;gap:8px;margin-top:6px"><button class="btn-save" id="cpSave" style="margin:0;flex:1">Kaydet</button>' + (settings.custPw ? '<button class="btn-save" id="cpOff" style="margin:0;flex:1;background:var(--ink-faint)">Şifreyi Kaldır</button>' : '') + '<button class="btn-save" id="cpNo" style="margin:0;flex:1;background:var(--ink-faint)">Kapat</button></div></div>';
    document.body.appendChild(bg); const inp = bg.querySelector('#cpIn'); inp.value = settings.custPw || ''; setTimeout(() => inp.focus(), 30);
    const done = () => bg.remove();
    bg.querySelector('#cpNo').onclick = done; bg.addEventListener('click', e => { if(e.target === bg) done(); });
    bg.querySelector('#cpRnd').onclick = () => { const w = 'ABCDEFGHJKLMNPRSTUVYZ', n = '23456789'; inp.value = w[Math.random() * w.length | 0] + w[Math.random() * w.length | 0] + n[Math.random() * n.length | 0] + n[Math.random() * n.length | 0] + n[Math.random() * n.length | 0]; };
    const save = () => { const v = inp.value.trim(); if(v.length < 3){ bg.querySelector('#cpErr').textContent = 'En az 3 karakter girin.'; return; } settings.custPw = v; finish('Müşteri ekranı şifresi kaydedildi.'); };
    const finish = m => { custLockRender(); publishPublic(); saveState(); showToast(m); done(); };
    bg.querySelector('#cpSave').onclick = save; inp.addEventListener('keydown', e => { if(e.key === 'Enter') save(); });
    const off = bg.querySelector('#cpOff'); if(off) off.onclick = () => { settings.custPw = ''; finish('Şifre kaldırıldı: menü herkese açık.'); };
  }
  $id('custLockCard').addEventListener('click', openCustPw);
  $id('navCO').addEventListener('click', () => { $id('sidebar').classList.remove('open'); $id('btnCO').click(); });
  $id('sbLogout').addEventListener('click', () => $id('btnLogout').click());
  setInterval(() => { [['coBadge', 'sbCO'], ['kBadge', 'sbK']].forEach(([a, b]) => { const x = $id(a), y = $id(b); if(x && y){ y.textContent = x.textContent; y.classList.toggle('on', x.classList.contains('on')); } }); if(staffMode) custLockRender(); }, 1000);


  // =====================================================================
  // CİRO TAKİBİ — gün / ay / yıl / özel aralık (işletme günü = Ayarlar'daki gün başlangıcına göre)
  // Ciro = alınan ödemelerin toplamı (Gün Sonu "Toplam satış" ile aynı). Net = ciro − açık hesap − gider.
  // =====================================================================
  const CT_PRE = [['today', 'Bugün'], ['yest', 'Dün'], ['d7', 'Son 7 gün'], ['week', 'Bu hafta'], ['d30', 'Son 30 gün'], ['month', 'Bu ay'], ['pmonth', 'Geçen ay'], ['year', 'Bu yıl'], ['pyear', 'Geçen yıl'], ['all', 'Tümü']];
  const CT_MONTHS = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'], CT_DAYS = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
  let ctPreset = 'month', ctGroup = '', ctLast = null;
  const ct2 = n => String(n).padStart(2, '0');
  const ctKey = d => d.getFullYear() + '-' + ct2(d.getMonth() + 1) + '-' + ct2(d.getDate());
  const ctDate = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d, 12); };
  const ctAdd = (k, n) => { const d = ctDate(k); d.setDate(d.getDate() + n); return ctKey(d); };
  function ctBizKey(ts){ const [h, m] = (settings.dayStart || '05:00').split(':').map(Number); return ctKey(new Date(ts - ((h || 0) * 60 + (m || 0)) * 60000)); }
  const ctDiff = (a, b) => Math.round((ctDate(b) - ctDate(a)) / 864e5);
  const ctShort = v => { const a = Math.abs(v); return (v < 0 ? '−' : '') + '₺' + (a >= 1e6 ? (a / 1e6).toLocaleString('tr-TR', { maximumFractionDigits: 1 }) + ' Mn' : Math.round(a).toLocaleString('tr-TR')); };
  function ctData(){
    const D = {}, get = k => D[k] || (D[k] = { sales: 0, cash: 0, open: 0, exp: 0, n: 0, guests: 0, waive: 0 });
    payLog.forEach(p => { if(!p || !p.ts) return; const o = get(ctBizKey(p.ts)), a = +p.amount || 0; o.sales += a; if(p.method === 'Nakit') o.cash += a; else if(p.method === 'Açık Hesap') o.open += a; });
    saleLog.forEach(x => { if(!x || !x.ts) return; const o = get(ctBizKey(x.ts)); o.n++; o.guests += (+x.guests || 0); });
    waiveLog.forEach(x => { if(x && x.ts) get(ctBizKey(x.ts)).waive += (+x.amount || 0); });
    giderler.forEach(g => { const m = /^(\d{1,2})\.(\d{1,2})\.(\d{4})$/.exec(String(g.date || '')); if(m) get(m[3] + '-' + ct2(m[2]) + '-' + ct2(m[1])).exp += (+g.amount || 0); });
    return D;
  }
  function ctPresetRange(p){
    const t = ctBizKey(Date.now()), d = ctDate(t), y = d.getFullYear(), m = d.getMonth();
    switch(p){
      case 'today': return [t, t]; case 'yest': return [ctAdd(t, -1), ctAdd(t, -1)]; case 'd7': return [ctAdd(t, -6), t]; case 'd30': return [ctAdd(t, -29), t];
      case 'week': { const wd = (d.getDay() + 6) % 7; return [ctAdd(t, -wd), t]; }
      case 'month': return [y + '-' + ct2(m + 1) + '-01', t];
      case 'pmonth': { const f = new Date(y, m - 1, 1, 12), l = new Date(y, m, 0, 12); return [ctKey(f), ctKey(l)]; }
      case 'year': return [y + '-01-01', t]; case 'pyear': return [(y - 1) + '-01-01', (y - 1) + '-12-31'];
      case 'all': { const ks = Object.keys(ctData()).sort(); return [ks[0] || t, ks.length ? (ks[ks.length - 1] > t ? ks[ks.length - 1] : t) : t]; }
    }
    return [t, t];
  }
  function ctSum(D, a, b){
    const r = { sales: 0, cash: 0, open: 0, exp: 0, n: 0, guests: 0, waive: 0, days: 0, best: null };
    Object.keys(D).forEach(k => { if(k < a || k > b) return; const o = D[k]; ['sales', 'cash', 'open', 'exp', 'n', 'guests', 'waive'].forEach(f => { r[f] += o[f]; }); if(o.sales > 0){ r.days++; if(!r.best || o.sales > r.best.v) r.best = { k, v: o.sales }; } });
    r.card = r.sales - r.cash - r.open; r.net = r.sales - r.open - r.exp; return r;
  }
  function ctBuckets(D, a, b, g){
    const out = [], mk = (key, label, short, f, t) => { const r = ctSum(D, f, t); r.key = key; r.label = label; r.short = short; out.push(r); };
    if(g === 'day'){ for(let k = a; k <= b; k = ctAdd(k, 1)){ const d = ctDate(k); mk(k, ct2(d.getDate()) + '.' + ct2(d.getMonth() + 1) + '.' + d.getFullYear() + ' ' + CT_DAYS[d.getDay()], ct2(d.getDate()) + '.' + ct2(d.getMonth() + 1), k, k); } }
    else if(g === 'month'){ const s = ctDate(a), e = ctDate(b); for(let y = s.getFullYear(), m = s.getMonth(); y < e.getFullYear() || (y === e.getFullYear() && m <= e.getMonth()); m++){ if(m > 11){ m = 0; y++; } const f = y + '-' + ct2(m + 1) + '-01', l = ctKey(new Date(y, m + 1, 0, 12)); mk(y + '-' + ct2(m + 1), CT_MONTHS[m] + ' ' + y, CT_MONTHS[m].slice(0, 3) + (s.getFullYear() !== e.getFullYear() ? ' ' + String(y).slice(2) : ''), f < a ? a : f, l > b ? b : l); } }
    else { for(let y = ctDate(a).getFullYear(); y <= ctDate(b).getFullYear(); y++) mk(String(y), String(y), String(y), y + '-01-01' < a ? a : y + '-01-01', y + '-12-31' > b ? b : y + '-12-31'); }
    return out;
  }
  function ctSvg(B){
    const W = 800, H = 290, L = 54, R = 12, T = 14, Bm = 34, pw = W - L - R, ph = H - T - Bm, mx = Math.max(1, ...B.map(x => x.sales));
    const step = Math.pow(10, Math.floor(Math.log10(mx / 4))), mult = [1, 2, 2.5, 5, 10].find(m => m * step * 4 >= mx) || 10, ys = step * mult, top = Math.ceil(mx / ys) * ys || 1;
    let g = '', i;
    for(i = 0; i * ys <= top + 1e-9; i++){ const y = T + ph - (i * ys / top) * ph; g += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + y + '" y2="' + y + '" stroke="var(--line)" stroke-width="1"/><text x="' + (L - 8) + '" y="' + (y + 4) + '" text-anchor="end" font-size="11" fill="var(--ink-faint)">' + ctShort(i * ys) + '</text>'; }
    const n = B.length, slot = pw / n, bw = Math.max(2, Math.min(34, slot * 0.7)), every = Math.max(1, Math.ceil(n / Math.floor(pw / 56)));
    let bars = '', xl = '', maxI = -1; B.forEach((x, j) => { if(x.sales > 0 && (maxI < 0 || x.sales > B[maxI].sales)) maxI = j; });
    B.forEach((x, j) => {
      const cx = L + slot * (j + .5), h = x.sales > 0 ? Math.max(2, x.sales / top * ph) : 0, y = T + ph - h;
      if(h) bars += '<path d="M' + (cx - bw / 2) + ',' + (T + ph) + 'V' + (y + 4) + 'Q' + (cx - bw / 2) + ',' + y + ' ' + (cx - bw / 2 + 4) + ',' + y + 'H' + (cx + bw / 2 - 4) + 'Q' + (cx + bw / 2) + ',' + y + ' ' + (cx + bw / 2) + ',' + (y + 4) + 'V' + (T + ph) + 'Z" fill="var(--ct-bar)"/>';
      bars += '<rect class="ct-hit" data-i="' + j + '" x="' + (L + slot * j) + '" y="' + T + '" width="' + slot + '" height="' + ph + '" fill="transparent"/>';
      if(j % every === 0) xl += '<text x="' + cx + '" y="' + (H - 12) + '" text-anchor="middle" font-size="11" fill="var(--ink-faint)">' + esc(x.short) + '</text>';
      if(j === maxI && n > 1) bars += '<text x="' + cx + '" y="' + (y - 5) + '" text-anchor="middle" font-size="11" font-weight="700" fill="var(--ink)">' + ctShort(x.sales) + '</text>';
    });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Ciro grafiği">' + g + '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + (T + ph) + '" y2="' + (T + ph) + '" stroke="var(--ink-faint)" stroke-width="1"/>' + bars + xl + '</svg><div class="ct-tip" id="ctTip"></div>';
  }
  function renderCiro(reset){
    if(!$id('screen-ciro')) return;
    if(reset && !$id('ctFrom').value){ const r = ctPresetRange(ctPreset); $id('ctFrom').value = r[0]; $id('ctTo').value = r[1]; }
    $id('ctPills').innerHTML = CT_PRE.map(p => '<button type="button" class="ct-pill' + (ctPreset === p[0] ? ' on' : '') + '" data-p="' + p[0] + '">' + p[1] + '</button>').join('');
    let a = $id('ctFrom').value, b = $id('ctTo').value; if(!a || !b) return; if(a > b){ const t = a; a = b; b = t; $id('ctFrom').value = a; $id('ctTo').value = b; }
    const nd = ctDiff(a, b) + 1, auto = nd <= 62 ? 'day' : nd <= 800 ? 'month' : 'year', g = ctGroup || auto;
    document.querySelectorAll('#ctSeg button').forEach(x => x.classList.toggle('on', x.dataset.g === g));
    const D = ctData(), T = ctSum(D, a, b), pa = ctAdd(a, -nd), pb = ctAdd(a, -1), PV = ctSum(D, pa, pb), B = ctBuckets(D, a, b, g);
    const dl = (v, pv) => pv > 0 ? '<em class="' + (v >= pv ? 'up' : 'dn') + '">' + (v >= pv ? '▲ ' : '▼ ') + Math.abs((v - pv) / pv * 100).toLocaleString('tr-TR', { maximumFractionDigits: 1 }) + '% önceki dönem (' + money(pv) + ')</em>' : '<em>Önceki dönemde veri yok</em>';
    const K = (l, v, x, cls) => '<div class="ct-kpi ' + (cls || '') + '"><small>' + l + '</small><b>' + v + '</b>' + (x || '') + '</div>';
    $id('ctKpis').innerHTML = K('Toplam ciro', money(T.sales), dl(T.sales, PV.sales), 'main') + K('Net kazanç', money(T.net), '<em>ciro − açık hesap − gider</em>') + K('Gider', money(T.exp), dl(T.exp, PV.exp).replace(/class="(up|dn)"/, 'class=""')) +
      K('Nakit', money(T.cash)) + K('Kart / Diğer', money(T.card)) + K('Açık hesap', money(T.open)) + K('Adisyon', String(T.n), '<em>ortalama ' + money(T.n ? T.sales / T.n : 0) + '</em>') + K('Misafir', String(T.guests), '<em>kişi başı ' + money(T.guests ? T.sales / T.guests : 0) + '</em>') +
      K('Günlük ortalama', money(T.days ? T.sales / T.days : 0), '<em>' + T.days + ' satışlı gün</em>') + K('En yüksek gün', T.best ? money(T.best.v) : '—', T.best ? '<em>' + ctDate(T.best.k).toLocaleDateString('tr-TR') + '</em>' : '') + K('İkram / ödenmez', money(T.waive));
    const fd = k => ctDate(k).toLocaleDateString('tr-TR');
    $id('ctChartTitle').textContent = (g === 'day' ? 'Günlük' : g === 'month' ? 'Aylık' : 'Yıllık') + ' ciro';
    $id('ctChartSub').textContent = fd(a) + ' – ' + fd(b) + ' · ' + nd + ' gün';
    $id('ctChart').innerHTML = T.sales || T.exp || T.n ? ctSvg(B) : '<div class="ct-empty">Bu aralıkta ödeme kaydı yok.</div>';
    const c = x => x ? money(x) : '<span class="zero">—</span>';
    $id('ctTable').innerHTML = '<table class="ct-table"><thead><tr><th>Dönem</th><th>Ciro</th><th>Nakit</th><th>Kart/Diğer</th><th>Açık hesap</th><th>Gider</th><th>Net</th><th>Adisyon</th></tr></thead><tbody>' +
      B.slice().reverse().map(x => '<tr><td>' + esc(x.label) + '</td><td>' + c(x.sales) + '</td><td>' + c(x.cash) + '</td><td>' + c(x.card) + '</td><td>' + c(x.open) + '</td><td>' + c(x.exp) + '</td><td>' + (x.sales || x.exp ? money(x.net) : '<span class="zero">—</span>') + '</td><td>' + (x.n || '<span class="zero">—</span>') + '</td></tr>').join('') +
      '</tbody><tfoot><tr><td>Toplam</td><td>' + money(T.sales) + '</td><td>' + money(T.cash) + '</td><td>' + money(T.card) + '</td><td>' + money(T.open) + '</td><td>' + money(T.exp) + '</td><td>' + money(T.net) + '</td><td>' + T.n + '</td></tr></tfoot></table>';
    ctLast = { B, T, a, b, g };
  }
  $id('ctPills').addEventListener('click', e => { const bt = e.target.closest('[data-p]'); if(!bt) return; ctPreset = bt.dataset.p; ctGroup = ''; const r = ctPresetRange(ctPreset); $id('ctFrom').value = r[0]; $id('ctTo').value = r[1]; renderCiro(); });
  ['ctFrom', 'ctTo'].forEach(i => $id(i).addEventListener('change', () => { ctPreset = ''; ctGroup = ''; renderCiro(); }));
  $id('ctSeg').addEventListener('click', e => { const bt = e.target.closest('[data-g]'); if(!bt) return; ctGroup = bt.dataset.g; renderCiro(); });
  $id('ctChart').addEventListener('pointermove', e => {
    const h = e.target.closest && e.target.closest('.ct-hit'), tip = $id('ctTip'); if(!tip) return;
    if(!h || !ctLast){ tip.style.display = 'none'; return; }
    const x = ctLast.B[+h.dataset.i], box = $id('ctChart').getBoundingClientRect();
    tip.innerHTML = '<b>' + esc(x.label) + '</b>Ciro: ' + money(x.sales) + '<br>Gider: ' + money(x.exp) + '<br>Net: ' + money(x.net) + '<br>Adisyon: ' + x.n;
    tip.style.display = 'block'; const tw = tip.offsetWidth; let left = e.clientX - box.left + 14; if(left + tw > box.width) left = e.clientX - box.left - tw - 14; tip.style.left = Math.max(0, left) + 'px'; tip.style.top = Math.max(0, e.clientY - box.top - 20) + 'px';
  });
  $id('ctChart').addEventListener('pointerleave', () => { const t = $id('ctTip'); if(t) t.style.display = 'none'; });
  $id('ctCsv').addEventListener('click', () => {
    if(!ctLast) return; const r = [['Dönem', 'Ciro', 'Nakit', 'Kart/Diğer', 'Açık hesap', 'Gider', 'Net', 'Adisyon']];
    ctLast.B.forEach(x => r.push([x.label, x.sales, x.cash, x.card, x.open, x.exp, x.net, x.n])); const T = ctLast.T; r.push(['TOPLAM', T.sales, T.cash, T.card, T.open, T.exp, T.net, T.n]);
    downloadFile('ciro-' + ctLast.a + '_' + ctLast.b + '.csv', csvOf(r));
  });
    // ======================================================================
  // STOK MODÜLÜ — malzeme, reçete, otomatik düşüm, kritik uyarı, fire, mal kabul, rapor
  // ======================================================================
  const STK = { items: [], rec: {}, log: [] };
  STK.prod = {}; STK.plog = []; STK.pset = { cust: 'out', staff: true, block: true, low: 5 };
  let stkMode = 'live', skVis = false, skF = { q: '', cat: '', f: 'tracked' }, skSel = {}, skShMode = 'add', skShQ = '', skShCat = '';
  let stkTab = 'stok', stkR = { f: new Date(Date.now() - 29 * 864e5).toISOString().slice(0, 10), t: new Date().toISOString().slice(0, 10) };
  const stkUnits = ['Adet', 'gr', 'kg', 'lt', 'ml', 'Porsiyon'], stkLbl = { in: 'Mal kabul', sale: 'Satış', fire: 'Fire', adj: 'Sayım' };
  const stkId = () => 's' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
  const stkItem = id => STK.items.find(x => x.id === id);
  const stkByName = n => STK.items.find(x => x.name.toLowerCase() === String(n || '').trim().toLowerCase());
  const stkN = v => { const n = parseFloat(String(v).replace(',', '.')); return isFinite(n) ? n : NaN; };
  const stkFmt = n => (Math.round(n * 100) / 100).toLocaleString('tr-TR');
  const stkProds = () => { const a = []; categories.forEach(c => c.products.forEach(p => a.push(p))); return a; };
  const stkNames = () => STK.items.map(x => x.name);
  const stkState = x => x.qty <= 0 ? ['bad', 'Tükendi'] : x.qty <= x.min ? ['bad', 'Kritik'] : x.qty <= x.min * 1.5 ? ['warn', 'Azalıyor'] : ['ok', 'Yeterli'];
  function stkMove(t, x, q, note, cost){
    x.qty = Math.round((x.qty + q) * 1000) / 1000;
    STK.log.push({ ts: Date.now(), t, id: x.id, q, c: cost == null ? x.cost : cost, note: note || '', u: uname() });
    if(STK.log.length > 4000) STK.log.splice(0, STK.log.length - 4000);
  }
  function stkBadge(){ let n = STK.items.filter(x => x.qty <= x.min).length; try{ n += Object.keys(STK.prod).filter(k => stkStatus(k)[0] !== 'ok').length; }catch(e){} const b = document.getElementById('sbStk'); if(b){ b.textContent = n; b.classList.toggle('on', n > 0); } }
  function stkSave(){ stkBadge(); saveState(); stkRender(); }
  function stkConsume(e){   // her satışta reçeteye göre otomatik düşüm
    ((e && e.items) || []).forEach(i => { if(i && stkTracked(i.name)) stkPMove(i.name, -(+i.qty || 1), 'sale'); });
    ((e && e.items) || []).forEach(i => (STK.rec[i.name] || []).forEach(r => { const x = stkItem(r.id); if(x) stkMove('sale', x, -(r.q * (i.qty || 1)), i.name); }));
    stkBadge();
  }
  function stkApplyIn(it, q, pr, note, last){
    pr = isFinite(pr) ? pr : it.cost;
    const nc = (last || it.qty <= 0) ? pr : (it.qty * it.cost + q * pr) / (it.qty + q);
    stkMove('in', it, q, note, pr); it.cost = Math.round(nc * 100) / 100;
  }
  const stkPick = (v, label) => ({ id: 'item', label: label || 'Malzeme', type: 'select', options: stkNames(), value: v || '' });
  function stkItemForm(x){
    const n = !x; x = x || { name: '', unit: 'gr', qty: 0, min: 0, cost: 0, sup: '' };
    openForm({ title: n ? 'Yeni malzeme' : 'Malzemeyi düzenle', sub: 'Reçetelerde kullanılacak ham madde veya sarf malzemesi.', fields: [
      { id: 'name', label: 'Malzeme adı', value: x.name, placeholder: 'Örn. Nargile tütünü (elma)' },
      { id: 'unit', label: 'Birim', type: 'select', options: stkUnits, value: x.unit },
      { id: 'qty', label: 'Mevcut stok (açılış)', type: 'number', step: '0.01', value: x.qty },
      { id: 'min', label: 'Kritik seviye (altında uyarı verir)', type: 'number', step: '0.01', value: x.min },
      { id: 'cost', label: 'Birim maliyet (₺)', type: 'number', step: '0.01', value: x.cost },
      { id: 'sup', label: 'Tedarikçi', value: x.sup || '' }
    ].filter(f => n || f.id !== 'qty'), onOk(v){
      if(!v.name) return 'Malzeme adı gerekli.';
      const d = stkByName(v.name); if(d && d !== x) return 'Bu isimde bir malzeme zaten var.';
      if(!(v.min >= 0) || !(v.cost >= 0)) return 'Kritik seviye ve maliyet 0 veya daha büyük olmalı.';
      if(n){ const it = { id: stkId(), name: v.name, unit: v.unit, qty: 0, min: v.min, cost: v.cost, sup: v.sup }; STK.items.push(it); if(v.qty > 0) stkMove('in', it, v.qty, 'Açılış stoku'); }
      else Object.assign(x, { name: v.name, unit: v.unit, min: v.min, cost: v.cost, sup: v.sup });
      stkSave();
    } });
  }
  function stkInForm(id){
    if(!STK.items.length) return showToast('Önce bir malzeme ekleyin.');
    const x = stkItem(id) || STK.items[0];
    openForm({ title: 'Mal kabul', sub: 'Tedarikçi faturasındaki alış stoğa eklenir.', fields: [
      stkPick(x.name), { id: 'qty', label: 'Gelen miktar', type: 'number', step: '0.01', value: '' },
      { id: 'price', label: 'Birim alış fiyatı (₺)', type: 'number', step: '0.01', value: x.cost },
      { id: 'inv', label: 'Fatura / irsaliye no (isteğe bağlı)', value: '' },
      { id: 'last', type: 'checkbox', label: 'Birim maliyet', text: 'Maliyeti son alış fiyatına eşitle (kapalıysa ağırlıklı ortalama)', value: false }
    ], onOk(v){
      const it = stkByName(v.item); if(!it) return 'Malzeme seçin.';
      if(!(v.qty > 0)) return 'Miktar 0’dan büyük olmalı.';
      if(!(v.price >= 0)) return 'Birim fiyat geçersiz.';
      stkApplyIn(it, v.qty, v.price, v.inv ? 'Fatura ' + v.inv : 'Mal kabul', v.last); stkSave(); showToast(it.name + ' stoğa eklendi.');
    } });
  }
  function stkBulkForm(){
    openForm({ title: 'Toplu stok girişi', sub: 'Her satıra: malzeme; miktar; birim fiyat (fiyat boşsa mevcut maliyet kullanılır).', fields: [
      { id: 'txt', type: 'textarea', label: 'Satırlar', value: '' }
    ], onOk(v){
      const miss = [], ok = [];
      v.txt.split('\n').map(l => l.trim()).filter(Boolean).forEach(l => {
        const p = l.split(';'), it = stkByName(p[0]), q = stkN(p[1]), pr = p[2] == null || p[2].trim() === '' ? NaN : stkN(p[2]);
        if(!it || !(q > 0)) miss.push(l); else ok.push([it, q, pr]);
      });
      if(miss.length) return 'Okunamayan satır: ' + miss[0];
      if(!ok.length) return 'Satır yok.';
      ok.forEach(a => stkApplyIn(a[0], a[1], a[2], 'Toplu giriş')); stkSave(); showToast(ok.length + ' kalem stoğa eklendi.');
    } });
  }
  function stkFireForm(id){
    if(!STK.items.length) return showToast('Önce bir malzeme ekleyin.');
    const x = stkItem(id) || STK.items[0];
    openForm({ title: 'Fire / zayi işle', sub: 'Stoktan düşülür ve maliyet raporuna yansır.', fields: [
      stkPick(x.name), { id: 'qty', label: 'Miktar', type: 'number', step: '0.01', value: '' },
      { id: 'reason', label: 'Neden', type: 'select', options: ['Döküldü', 'Bozuldu', 'Kırıldı', 'Son kullanma tarihi geçti', 'Mutfak hatası', 'Diğer'], value: 'Döküldü' }
    ], onOk(v){
      const it = stkByName(v.item); if(!it) return 'Malzeme seçin.';
      if(!(v.qty > 0)) return 'Miktar 0’dan büyük olmalı.';
      if(v.qty > it.qty) return 'Stokta yalnızca ' + stkFmt(it.qty) + ' ' + it.unit + ' var.';
      stkMove('fire', it, -v.qty, v.reason);
      lists.zayi.push({ name: it.name, qty: v.qty, ts: Date.now(), sub: new Date().toLocaleDateString('tr-TR') + ' · ' + v.reason, val: stkFmt(v.qty) + ' ' + it.unit + ' (' + money(v.qty * it.cost) + ')' });
      try{ renderLists(); renderReports(); }catch(_){}
      stkSave(); showToast('Fire işlendi.');
    } });
  }
  function stkCountForm(id){
    const x = stkItem(id); if(!x) return;
    openForm({ title: 'Sayım düzeltmesi: ' + x.name, sub: 'Sistemdeki stok: ' + stkFmt(x.qty) + ' ' + x.unit + '. Raflarda saydığınız gerçek miktarı girin.', fields: [
      { id: 'qty', label: 'Sayılan miktar (' + x.unit + ')', type: 'number', step: '0.01', value: x.qty }
    ], onOk(v){
      if(!(v.qty >= 0)) return 'Geçerli bir miktar girin.';
      const d = v.qty - x.qty; if(d !== 0) stkMove('adj', x, d, 'Sayım farkı'); stkSave();
    } });
  }
  function stkRecForm(p){
    if(!STK.items.length) return showToast('Önce malzeme ekleyin.');
    const cur = (STK.rec[p.name] || []).map(r => { const x = stkItem(r.id); return x ? x.name + '; ' + r.q : ''; }).filter(Boolean).join('\n');
    openForm({ title: 'Reçete: ' + p.name, sub: 'Her satıra: malzeme; bir porsiyondaki miktar. Satış yapıldıkça stoktan otomatik düşer.', fields: [
      { id: 'txt', type: 'textarea', label: 'Malzemeler (' + stkNames().slice(0, 4).join(', ') + '…)', value: cur }
    ], onOk(v){
      const out = [];
      for(const l of v.txt.split('\n').map(s => s.trim()).filter(Boolean)){
        const a = l.split(';'), it = stkByName(a[0]), q = stkN(a[1]);
        if(!it) return 'Tanımsız malzeme: ' + a[0].trim();
        if(!(q > 0)) return 'Miktar geçersiz: ' + l;
        out.push({ id: it.id, q });
      }
      if(out.length) STK.rec[p.name] = out; else delete STK.rec[p.name];
      stkSave();
    } });
  }
  function stkSeed(){
    [['Nargile tütünü', 'gr', 5000, 500, 0.6], ['Kömür', 'Adet', 400, 80, 0.5], ['Folyo', 'Adet', 300, 50, 0.3], ['Kahve çekirdeği', 'gr', 3000, 500, 0.9], ['Süt', 'lt', 20, 5, 38], ['Kağıt bardak', 'Adet', 500, 100, 1.2]]
      .forEach(a => { if(!stkByName(a[0])){ const it = { id: stkId(), name: a[0], unit: a[1], qty: 0, min: a[3], cost: a[4], sup: '' }; STK.items.push(it); stkMove('in', it, a[2], 'Açılış stoku'); } });
    stkSave();
  }
  // ---- görünümler ----
  function stkViewStock(){
    const L = STK.items, crit = L.filter(x => x.qty <= x.min), val = L.reduce((a, x) => a + Math.max(0, x.qty) * x.cost, 0);
    const noRec = stkProds().filter(p => !(STK.rec[p.name] || []).length).length;
    if(!L.length) return '<div class="stk-empty">Henüz malzeme yok. Malzemeleri tek tek ekleyebilir ya da örnek bir başlangıç listesi yükleyebilirsiniz.<br><button class="btn-mini" data-a="seed" style="margin-top:12px">Örnek malzemeleri ekle</button></div>';
    let h = '<div class="ct-kpis"><div class="ct-kpi"><small>Malzeme çeşidi</small><b>' + L.length + '</b></div><div class="ct-kpi' + (crit.length ? ' stk-bad' : '') + '"><small>Kritik / tükenen</small><b>' + crit.length + '</b></div><div class="ct-kpi"><small>Stok değeri</small><b>' + money(val) + '</b></div><div class="ct-kpi"><small>Reçetesiz ürün</small><b>' + noRec + '</b><em>Satışta stoktan düşmez</em></div></div>';
    if(crit.length) h += '<div class="stk-alert"><b>Stok uyarısı:</b> ' + crit.map(x => esc(x.name) + ' (' + stkFmt(x.qty) + ' ' + esc(x.unit) + ')').join(' · ') + '</div>';
    h += '<div class="ct-tablewrap"><table class="ct-table"><thead><tr><th>Malzeme</th><th>Durum</th><th>Seviye</th><th>Stok</th><th>Kritik</th><th>Birim maliyet</th><th>Değer</th><th></th></tr></thead><tbody>' +
      L.slice().sort((a, b) => (a.qty / (a.min || 1)) - (b.qty / (b.min || 1))).map(x => {
        const s = stkState(x), pct = Math.max(0, Math.min(100, x.min ? x.qty / (x.min * 3) * 100 : (x.qty > 0 ? 100 : 0)));
        return '<tr><td><b>' + esc(x.name) + '</b>' + (x.sup ? '<br><small class="stk-sub">' + esc(x.sup) + '</small>' : '') + '</td><td><span class="stk-b ' + s[0] + '">' + s[1] + '</span></td><td><div class="stk-bar"><i class="' + s[0] + '" style="width:' + pct + '%"></i></div></td><td>' + stkFmt(x.qty) + ' ' + esc(x.unit) + '</td><td>' + stkFmt(x.min) + '</td><td>' + money(x.cost) + '</td><td>' + money(Math.max(0, x.qty) * x.cost) + '</td><td class="stk-act"><button data-a="in" data-id="' + x.id + '">Giriş</button><button data-a="fire" data-id="' + x.id + '">Fire</button><button data-a="count" data-id="' + x.id + '">Sayım</button><button data-a="edit" data-id="' + x.id + '">Düzenle</button><button data-a="del" data-id="' + x.id + '" class="del">Sil</button></td></tr>';
      }).join('') + '</tbody></table></div>';
    return h;
  }
  function stkViewRecipes(){
    const P = stkProds();
    return '<p class="stk-note">Ürüne tıklayarak reçetesini girin. Maliyet, malzemelerin güncel birim maliyetinden hesaplanır.</p><div class="ct-tablewrap"><table class="ct-table"><thead><tr><th>Ürün</th><th>Kalem</th><th>Reçete maliyeti</th><th>Satış fiyatı</th><th>Kâr marjı</th><th></th></tr></thead><tbody>' + P.map((p, i) => {
      const R = STK.rec[p.name] || [], c = R.reduce((a, r) => { const x = stkItem(r.id); return a + (x ? x.cost * r.q : 0); }, 0), pr = +p.price || 0, mg = pr > 0 && R.length ? (pr - c) / pr * 100 : null;
      return '<tr class="stk-row" data-a="rec" data-i="' + i + '"><td><b>' + esc(p.name) + '</b></td><td>' + (R.length ? R.length : '<span class="stk-b warn">Reçete yok</span>') + '</td><td>' + (R.length ? money(c) : '—') + '</td><td>' + money(pr) + '</td><td>' + (mg == null ? '—' : '<span class="stk-b ' + (mg < 40 ? 'bad' : mg < 60 ? 'warn' : 'ok') + '">%' + mg.toFixed(0) + '</span>') + '</td><td class="stk-act"><button data-a="rec" data-i="' + i + '">Reçete</button></td></tr>';
    }).join('') + '</tbody></table></div>';
  }
  function stkAgg(){
    const f = new Date(stkR.f + 'T00:00:00').getTime(), t = new Date(stkR.t + 'T00:00:00').getTime() + 864e5, m = {}, T = { cons: 0, fire: 0, buy: 0 };
    STK.log.forEach(e => {
      if(e.ts < f || e.ts >= t) return; const x = stkItem(e.id); if(!x) return;
      const o = m[e.id] || (m[e.id] = { x, s: 0, sc: 0, f: 0, fc: 0, b: 0 }), c = Math.abs(e.q) * e.c;
      if(e.t === 'sale'){ o.s -= e.q; o.sc += c; T.cons += c; } else if(e.t === 'fire'){ o.f -= e.q; o.fc += c; T.fire += c; } else if(e.t === 'in'){ o.b += e.q; T.buy += e.q * e.c; }
    });
    return { rows: Object.values(m), T };
  }
  function stkViewReport(){
    const { rows, T } = stkAgg();
    const bars = (arr, key, fmt) => { const mx = Math.max(1e-9, ...arr.map(o => o[key])); return arr.map(o => '<div class="bar-row"><div class="bname">' + esc(o.x.name) + '</div><div class="btrack"><div class="bfill" style="width:' + (o[key] / mx * 100) + '%"></div></div><div class="bval">' + fmt(o) + '</div></div>').join('') || '<p class="stk-note">Bu aralıkta kayıt yok.</p>'; };
    const low = STK.items.filter(x => x.min > 0).map(x => ({ x, r: Math.max(0, x.qty / x.min) })).sort((a, b) => a.r - b.r).slice(0, 6);
    return '<div class="ct-range"><label>Başlangıç<input type="date" id="stkFrom" data-r="f" value="' + stkR.f + '"></label><label>Bitiş<input type="date" id="stkTo" data-r="t" value="' + stkR.t + '"></label><button class="btn-mini" data-a="csv" style="margin-left:auto">⬇ CSV</button></div>' +
      '<div class="ct-kpis"><div class="ct-kpi"><small>Tüketim maliyeti</small><b>' + money(T.cons) + '</b></div><div class="ct-kpi' + (T.fire > 0 ? ' stk-bad' : '') + '"><small>Fire maliyeti</small><b>' + money(T.fire) + '</b><em>Fire oranı %' + ((T.cons + T.fire) ? (T.fire / (T.cons + T.fire) * 100).toFixed(1) : '0') + '</em></div><div class="ct-kpi"><small>Mal alımı</small><b>' + money(T.buy) + '</b></div></div>' +
      '<div class="stk-r"><h3 class="stk-h">En çok tüketilen malzemeler</h3>' + bars(rows.filter(o => o.s > 0).sort((a, b) => b.sc - a.sc).slice(0, 8), 'sc', o => stkFmt(o.s) + ' ' + esc(o.x.unit) + ' · ' + money(o.sc)) +
      '<h3 class="stk-h">Fire (zayi) maliyeti</h3>' + bars(rows.filter(o => o.f > 0).sort((a, b) => b.fc - a.fc).slice(0, 6), 'fc', o => stkFmt(o.f) + ' ' + esc(o.x.unit) + ' · ' + money(o.fc)) +
      '<h3 class="stk-h">Seviyesi en düşük malzemeler</h3>' + (low.map(o => '<div class="bar-row"><div class="bname">' + esc(o.x.name) + '</div><div class="btrack"><div class="bfill stk-' + stkState(o.x)[0] + '" style="width:' + Math.min(100, o.r * 50) + '%"></div></div><div class="bval">' + stkFmt(o.x.qty) + ' ' + esc(o.x.unit) + '</div></div>').join('') || '<p class="stk-note">Kritik seviye tanımlı malzeme yok.</p>') + '</div>';
  }
  function stkViewLog(){
    const L = STK.log.slice(-100).reverse();
    return L.length ? '<div class="ct-tablewrap"><table class="ct-table"><thead><tr><th>Tarih</th><th>Malzeme</th><th>İşlem</th><th>Miktar</th><th>Not</th><th>Kullanıcı</th></tr></thead><tbody>' + L.map(e => { const x = stkItem(e.id); return '<tr><td>' + new Date(e.ts).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) + '</td><td>' + esc(x ? x.name : '(silinmiş)') + '</td><td>' + (stkLbl[e.t] || e.t) + '</td><td>' + (e.q > 0 ? '+' : '') + stkFmt(e.q) + '</td><td>' + esc(e.note) + '</td><td>' + esc(e.u || '') + '</td></tr>'; }).join('') + '</tbody></table></div>' : '<div class="stk-empty">Henüz hareket yok.</div>';
  }
  function stkRender(){
    try{ stkLiveRender(); }catch(err){ console.error(err); }
    const el = $id('stkBody'); if(!el) return; stkBadge();
    if(stkMode !== 'adv') return;
    document.querySelectorAll('#stkTabs .tab').forEach(t => t.classList.toggle('active', t.dataset.t === stkTab));
    el.innerHTML = ({ stok: stkViewStock, recete: stkViewRecipes, rapor: stkViewReport, hareket: stkViewLog })[stkTab]();
  }
  document.addEventListener('click', e => {
    const tb = e.target.closest('#stkTabs .tab'); if(tb){ stkTab = tb.dataset.t; return stkRender(); }
    const b = e.target.closest('#screen-stok [data-a]'); if(!b) return; e.stopPropagation();
    const a = b.dataset.a, id = b.dataset.id;
    if(a === 'new') stkItemForm(); else if(a === 'in') stkInForm(id); else if(a === 'bulk') stkBulkForm(); else if(a === 'fire') stkFireForm(id);
    else if(a === 'count') stkCountForm(id); else if(a === 'edit') stkItemForm(stkItem(id)); else if(a === 'seed') stkSeed();
    else if(a === 'rec') stkRecForm(stkProds()[+b.dataset.i]);
    else if(a === 'del'){ const x = stkItem(id); if(x && confirm(x.name + ' silinsin mi? Reçetelerden de çıkarılır.')){ STK.items = STK.items.filter(y => y.id !== id); Object.keys(STK.rec).forEach(k => { STK.rec[k] = STK.rec[k].filter(r => r.id !== id); if(!STK.rec[k].length) delete STK.rec[k]; }); stkSave(); } }
    else if(a === 'csv'){ const { rows } = stkAgg(); downloadFile('stok-rapor-' + stkR.f + '_' + stkR.t + '.csv', csvOf([['Malzeme', 'Birim', 'Tüketim', 'Tüketim maliyeti', 'Fire', 'Fire maliyeti', 'Alım', 'Güncel stok']].concat(rows.map(o => [o.x.name, o.x.unit, o.s, o.sc.toFixed(2), o.f, o.fc.toFixed(2), o.b, o.x.qty])))); }
  }, true);
  document.addEventListener('change', e => { const r = e.target.dataset && e.target.dataset.r; if(r && e.target.closest('#screen-stok') && e.target.value){ stkR[r] = e.target.value; stkRender(); } });
  // ---- uygulama ile bağlantı: kayıt/senkron, ekran yönlendirme, satış kancası ----
  const _snap = snapshot; snapshot = function(){ const o = _snap.apply(this, arguments); o.stock = Object.assign({}, STK, { prod: skPack() }); return o; };
  const _apply = applyState; applyState = function(s, p){
    if(s && s.stock && typeof s.stock === 'object'){ STK.items = Array.isArray(s.stock.items) ? s.stock.items : []; STK.rec = s.stock.rec && typeof s.stock.rec === 'object' ? s.stock.rec : {}; STK.log = Array.isArray(s.stock.log) ? s.stock.log : [];
      STK.prod = {}; arr(s.stock.prod).forEach(x => { if(x && x.n) STK.prod[x.n] = { q: +x.q || 0, min: (x.m == null ? undefined : +x.m) }; });
      STK.plog = Array.isArray(s.stock.plog) ? s.stock.plog.filter(Boolean) : []; STK.pset = Object.assign({ cust: 'out', staff: true, block: true, low: 5 }, (s.stock.pset && typeof s.stock.pset === 'object') ? s.stock.pset : {}); }
    const r = _apply.apply(this, arguments); stkBadge(); return r;
  };
  const _lp = logPriv; logPriv = function(k, e){ if(k === 'saleLog'){ try{ stkConsume(e); }catch(err){ console.error(err); } } return _lp.apply(this, arguments); };
  const _show = showScreen; showScreen = function(n){ const r = _show.apply(this, arguments); if(n === 'stok') stkRender(); return r; };
  titles.stok = 'Stok'; SCR_PERM.stok = 'stock';
  setInterval(stkBadge, 4000);

  // ======================================================================
  // CANLI ÜRÜN STOĞU — menüdeki ürünler üzerinden adet takibi, sade ve canlı
  // ======================================================================
  const SK_LBL = { in: 'Giriş', out: 'Çıkış', sale: 'Satış', set: 'Sayım', start: 'Takip başladı', stop: 'Takip bitti' };
  const skInt = v => { const n = parseInt(String(v).replace(',', '.'), 10); return isFinite(n) ? n : NaN; };
  const skEsc = x => esc(String(x == null ? '' : x));
  const stkTracked = n => Object.prototype.hasOwnProperty.call(STK.prod, n);
  const stkLow = n => { const t = STK.prod[n]; return (t && isFinite(t.min) && t.min !== null && t.min !== '') ? +t.min : (+STK.pset.low || 5); };
  function stkReserved(n){ let q = 0; Object.keys(carts).forEach(k => (carts[k] || []).forEach(it => { if(it && it.name === n) q += (+it.qty || 0); })); return q; }
  function stkAvail(n){ return stkTracked(n) ? Math.max(0, Math.floor(STK.prod[n].q) - stkReserved(n)) : null; }
  function stkStatus(n, av){ av = av == null ? stkAvail(n) : av; return av <= 0 ? ['bad', 'Tükendi'] : av <= stkLow(n) ? ['warn', 'Azalıyor'] : ['ok', 'Yeterli']; }
  function stkPMove(n, d, t, note){
    const x = STK.prod[n]; if(!x || !isFinite(d)) return;
    const nq = Math.max(0, Math.round((x.q + d) * 1000) / 1000), real = nq - x.q; x.q = nq;
    if(real !== 0 || t === 'start' || t === 'stop') STK.plog.push({ ts: Date.now(), n, d: real, t, note: note || '', u: uname() });
    if(STK.plog.length > 2000) STK.plog.splice(0, STK.plog.length - 2000);
  }
  function skAll(){
    const a = [], seen = new Set();
    categories.forEach(c => (c.products || []).forEach(p => { if(p && p.name && !seen.has(p.name)){ seen.add(p.name); a.push({ p, cat: c.grp || c.name }); } }));
    return a;
  }
  const skSee = () => !!(curUser && (curUser.admin || can('stock') || STK.pset.staff !== false));
  const skChip = n => { if(!stkTracked(n) || !skSee()) return ''; const av = stkAvail(n), s = stkStatus(n, av); return '<span class="sk-mini ' + s[0] + '">' + (av <= 0 ? 'Tükendi' : av + ' adet') + '</span>'; };
  function stkPublic(){
    const P = STK.pset, o = [], l = [];
    if(P.cust === 'hide') return { m: 'hide' };
    Object.keys(STK.prod).forEach(n => { const av = stkAvail(n); if(av <= 0) o.push(n); else if(P.cust === 'low' && av <= stkLow(n)) l.push({ n, q: av }); });
    return { m: P.cust === 'low' ? 'low' : 'out', b: P.block ? 1 : 0, o, l };
  }
  let _skPubSig = '', _skPubFail = 0;
  function stkPushPublic(){
    if(RT.local || !staffMode || !curUser || Date.now() - _skPubFail < 60000) return;
    let d; try{ d = stkPublic(); }catch(e){ return; }
    const sig = JSON.stringify(d); if(sig === _skPubSig) return; _skPubSig = sig;
    try{ Promise.resolve(RT.set('public/stock', d)).catch(() => { _skPubFail = Date.now(); _skPubSig = ''; }); }catch(e){ _skPubFail = Date.now(); }
  }
  function skSave(){ stkBadge(); saveState(); stkRender(); try{ stkPushPublic(); }catch(e){} }
  // ---- görünümler ----
  function skModesUI(){
    const adv = stkMode === 'adv', live = $id('stkLive'); if(!live) return;
    live.style.display = adv ? 'none' : ''; $id('stkAdv').style.display = adv ? '' : 'none';
    $id('stkHeadLive').style.display = adv ? 'none' : ''; $id('stkHeadAdv').style.display = adv ? '' : 'none';
    document.querySelectorAll('#stkModes button').forEach(b => b.classList.toggle('on', b.dataset.sm === stkMode));
    const p = $id('stkSub'); if(p) p.textContent = adv ? 'Malzeme stokları, reçeteler, fire ve tüketim raporları' : 'Ürünlerinizin canlı adet stoğu';
  }
  function skStatusCard(n){ const av = stkAvail(n), s = stkStatus(n, av); return { av, s }; }
  function skGridHtml(){
    const q = skF.q.trim().toLocaleLowerCase('tr-TR');
    let L = skAll().filter(x => (!skF.cat || x.cat === skF.cat) && (!q || x.p.name.toLocaleLowerCase('tr-TR').includes(q)));
    const sev = n => { const s = stkStatus(n)[0]; return s === 'bad' ? 0 : s === 'warn' ? 1 : 2; };
    if(skF.f === 'untracked') L = L.filter(x => !stkTracked(x.p.name));
    else{
      L = L.filter(x => stkTracked(x.p.name));
      if(skF.f === 'low') L = L.filter(x => stkStatus(x.p.name)[0] === 'warn');
      if(skF.f === 'out') L = L.filter(x => stkStatus(x.p.name)[0] === 'bad');
      L.sort((a, b) => sev(a.p.name) - sev(b.p.name) || a.p.name.localeCompare(b.p.name, 'tr'));
    }
    if(!L.length){
      const none = !Object.keys(STK.prod).length && !skF.q && !skF.cat && skF.f === 'tracked';
      return '<div class="sk-empty"><div class="sk-ei">📦</div><b>' + (none ? 'Stok takibi henüz başlamadı' : 'Bu görünümde ürün yok') + '</b><p>' + (none ? 'Ürünleri menüdeki gibi seçin, adetlerini yazın; satış yapıldıkça stok kendiliğinden düşer.' : 'Filtreyi veya aramayı değiştirin.') + '</p>' + (none ? '<button class="sk-primary" data-sa="add">＋ Stok ekle</button>' : '') + '</div>';
    }
    return '<div class="sk-grid">' + L.map(x => {
      const p = x.p, n = p.name, tr = stkTracked(n), en = skEsc(n);
      if(!tr) return '<div class="sk-card off"><div class="sk-top"><div class="sk-vis">' + visHtml(p, '', 'v-mp') + '</div><div class="sk-nm"><b>' + en + '</b><small>' + skEsc(x.cat) + '</small></div></div><div class="sk-nt">Stok takibi kapalı</div><div class="sk-act"><button class="sk-btn" data-sa="on" data-n="' + en + '">Takibe al</button></div></div>';
      const { av, s } = skStatusCard(n), q = Math.floor(STK.prod[n].q), rs = stkReserved(n), lo = stkLow(n), pct = Math.max(0, Math.min(100, av / Math.max(lo * 3, 1) * 100));
      return '<div class="sk-card ' + s[0] + '"><div class="sk-top"><div class="sk-vis">' + visHtml(p, '', 'v-mp') + '</div><div class="sk-nm"><b>' + en + '</b><small>' + skEsc(x.cat) + '</small></div><span class="sk-pill ' + s[0] + '">' + s[1] + '</span></div>' +
        '<div class="sk-q"><b>' + q + '</b><span>adet</span>' + (rs ? '<em>' + rs + ' adisyonda</em>' : '') + '</div><div class="sk-bar"><i class="' + s[0] + '" style="width:' + pct + '%"></i></div>' +
        '<div class="sk-act"><button class="sk-sq" data-sa="dec" data-n="' + en + '" aria-label="Azalt">−</button><button class="sk-sq" data-sa="inc" data-n="' + en + '" aria-label="Artır">＋</button><button class="sk-btn" data-sa="set" data-n="' + en + '">Sayım</button><button class="sk-btn ghost" data-sa="off" data-n="' + en + '" title="Takibi bırak">⋯</button></div></div>';
    }).join('') + '</div>';
  }
  function skVisPanel(){
    const P = STK.pset, can2 = !!(curUser && (curUser.admin || can('settings'))), dis = can2 ? '' : ' disabled';
    const seg = (k, t) => '<button class="' + (P.cust === k ? 'on' : '') + '" data-sa="cust:' + k + '"' + dis + '>' + t + '</button>';
    const tg = (k, t, d) => '<div class="sk-row"><div><b>' + t + '</b><small>' + d + '</small></div><button class="sk-tg ' + (P[k] !== false && P[k] ? 'on' : '') + '" data-sa="tg:' + k + '"' + dis + ' role="switch" aria-checked="' + !!P[k] + '"><i></i></button></div>';
    return '<div class="sk-vp"><div class="sk-vph"><b>Stok görünürlüğü</b><small>' + (can2 ? 'Stoğun kime ve nasıl gösterileceğini seçin.' : 'Bu ayarları yalnızca yönetici değiştirebilir.') + '</small></div>' +
      '<div class="sk-row col"><div><b>Müşteri menüsünde</b><small>Müşteri sipariş verirken ürünün durumunu görür.</small></div><div class="sk-seg">' + seg('hide', 'Gösterme') + seg('out', '“Tükendi”') + seg('low', 'Tükendi + Son adetler') + '</div></div>' +
      tg('staff', 'Personel ekranlarında stok görünsün', 'Kapalıysa yalnızca stok yetkisi olanlar görür.') + tg('block', 'Tükenen ürün sipariş edilemesin', 'Hem müşteri hem personel tükenen ürünü ekleyemez.') +
      '<div class="sk-row"><div><b>Azalıyor uyarısı</b><small>Bu adedin altına inen ürün “Azalıyor” olur.</small></div><input type="number" min="1" max="999" class="sk-num" id="skLow" value="' + (+P.low || 5) + '"' + dis + '></div></div>';
  }
  function skLiveView(){
    const all = skAll(), tr = all.filter(x => stkTracked(x.p.name)), st = x => stkStatus(x.p.name)[0];
    const nW = tr.filter(x => st(x) === 'warn').length, nB = tr.filter(x => st(x) === 'bad').length, cats = []; all.forEach(x => { if(cats.indexOf(x.cat) < 0) cats.push(x.cat); });
    const fb = (k, t) => '<button class="' + (skF.f === k ? 'on' : '') + '" data-sf="' + k + '">' + t + '</button>';
    return '<div class="sk-kpis"><div class="sk-kpi"><small>Takipteki ürün</small><b>' + tr.length + '</b></div><div class="sk-kpi warn"><small>Azalan</small><b>' + nW + '</b></div><div class="sk-kpi bad"><small>Tükenen</small><b>' + nB + '</b></div></div>' +
      (skVis ? skVisPanel() : '') +
      '<div class="sk-tools"><input id="skSearch" class="sk-search" type="search" placeholder="Ürün ara…" value="' + skEsc(skF.q) + '" autocomplete="off"><div class="sk-seg">' + fb('tracked', 'Takipte') + fb('low', 'Azalan') + fb('out', 'Tükenen') + fb('untracked', 'Takipte değil') + '</div></div>' +
      '<div class="sk-chips"><button class="sk-chip ' + (!skF.cat ? 'on' : '') + '" data-sc="">Tümü</button>' + cats.map(c => '<button class="sk-chip ' + (skF.cat === c ? 'on' : '') + '" data-sc="' + skEsc(c) + '">' + skEsc(c) + '</button>').join('') + '</div><div id="skGrid">' + skGridHtml() + '</div>';
  }
  function skLogView(){
    const L = STK.plog.slice(-200).reverse();
    if(!L.length) return '<div class="sk-empty"><div class="sk-ei">🕘</div><b>Henüz hareket yok</b><p>Stok girişleri, sayımlar ve satışlar burada listelenir.</p></div>';
    return '<div class="sk-log">' + L.map(e => '<div class="sk-lr"><div class="sk-ld ' + (e.d > 0 ? 'in' : e.d < 0 ? 'out' : '') + '">' + (e.d > 0 ? '+' : '') + (e.d || 0) + '</div><div class="sk-lm"><b>' + skEsc(e.n) + '</b><small>' + (SK_LBL[e.t] || e.t) + (e.note ? ' · ' + skEsc(e.note) : '') + (e.u ? ' · ' + skEsc(e.u) : '') + '</small></div><time>' + new Date(e.ts).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) + '</time></div>').join('') + '</div>';
  }
  function stkLiveRender(){
    const h = $id('stkLive'); if(!h) return; skModesUI();
    if(stkMode === 'adv') return;
    const keep = document.activeElement && document.activeElement.id === 'skSearch';
    h.innerHTML = stkMode === 'log' ? skLogView() : skLiveView();
    if(keep){ const i = $id('skSearch'); if(i){ i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }
  }
  // ---- "Stok ekle" penceresi: ürünleri menüdeki gibi seç, adedi yaz ----
  function skSheetEl(){ let ov = document.getElementById('skSheet'); if(!ov){ ov = document.createElement('div'); ov.id = 'skSheet'; ov.className = 'sk-ov'; document.body.appendChild(ov); } return ov; }
  function skOpenSheet(){ skSel = {}; skShMode = 'add'; skShQ = ''; skShCat = ''; const ov = skSheetEl(); ov.style.display = 'flex'; skSheetRender(); setTimeout(() => { const i = document.getElementById('skShSearch'); if(i) i.focus(); }, 60); }
  function skCloseSheet(){ const ov = document.getElementById('skSheet'); if(ov) ov.style.display = 'none'; }
  function skShGrid(){
    const q = skShQ.trim().toLocaleLowerCase('tr-TR'), L = skAll().filter(x => (!skShCat || x.cat === skShCat) && (!q || x.p.name.toLocaleLowerCase('tr-TR').includes(q)));
    if(!L.length) return '<p class="sk-none">Ürün bulunamadı.</p>';
    return L.map(x => {
      const n = x.p.name, en = skEsc(n), on = Object.prototype.hasOwnProperty.call(skSel, n), cur = stkTracked(n) ? Math.floor(STK.prod[n].q) + ' adet' : 'takipte değil';
      return '<div class="sk-tile' + (on ? ' on' : '') + '" data-sn="' + en + '"><div class="sk-vis">' + visHtml(x.p, '', 'v-mp') + '</div><b>' + en + '</b><small>Stok: ' + cur + '</small>' +
        (on ? '<div class="sk-tctl"><button data-sp="-1" aria-label="Azalt">−</button><input type="number" inputmode="numeric" min="0" data-sq value="' + skSel[n] + '" aria-label="Adet"><button data-sp="1" aria-label="Artır">＋</button></div>' : '<div class="sk-tctl pick">＋ Seç</div>') + '</div>';
    }).join('');
  }
  function skShSum(){
    const ks = Object.keys(skSel), tot = ks.reduce((a, k) => a + (skSel[k] || 0), 0), b = document.getElementById('skShOk'), s = document.getElementById('skShSum');
    if(s) s.innerHTML = ks.length ? '<b>' + ks.length + ' ürün</b> · ' + (skShMode === 'add' ? 'toplam +' : 'sayım toplamı ') + tot + ' adet' : 'Ürün seçin';
    if(b){ b.disabled = !ks.length; b.textContent = skShMode === 'add' ? 'Stoğa ekle' : 'Sayımı kaydet'; }
  }
  function skSheetRender(){
    const ov = skSheetEl(), cats = []; skAll().forEach(x => { if(cats.indexOf(x.cat) < 0) cats.push(x.cat); });
    const gs = ov.querySelector('#skShGrid'), st = gs ? gs.scrollTop : 0;
    ov.innerHTML = '<div class="sk-sheet" role="dialog" aria-label="Stok ekle"><div class="sk-sh-head"><div><b>' + (skShMode === 'add' ? 'Stok ekle' : 'Stok sayımı') + '</b><small>' + (skShMode === 'add' ? 'Ürünleri menüdeki gibi seçin, eklenecek adedi yazın.' : 'Raftaki gerçek adedi yazın; stok bu sayıya eşitlenir.') + '</small></div><button class="sk-x" data-sx="close" aria-label="Kapat">✕</button></div>' +
      '<div class="sk-seg sk-seg2"><button class="' + (skShMode === 'add' ? 'on' : '') + '" data-sx="m:add">Stoğa ekle</button><button class="' + (skShMode === 'set' ? 'on' : '') + '" data-sx="m:set">Sayıma eşitle</button></div>' +
      '<input id="skShSearch" class="sk-search" type="search" placeholder="Ürün ara…" value="' + skEsc(skShQ) + '" autocomplete="off">' +
      '<div class="sk-chips"><button class="sk-chip ' + (!skShCat ? 'on' : '') + '" data-sx="c:">Tümü</button>' + cats.map(c => '<button class="sk-chip ' + (skShCat === c ? 'on' : '') + '" data-sx="c:' + skEsc(c) + '">' + skEsc(c) + '</button>').join('') + '</div>' +
      '<div class="sk-sh-grid" id="skShGrid">' + skShGrid() + '</div><div class="sk-sh-foot"><div id="skShSum"></div><button class="sk-primary" id="skShOk" data-sx="ok">Stoğa ekle</button></div></div>';
    const g = ov.querySelector('#skShGrid'); if(g) g.scrollTop = st; skShSum();
  }
  function skApply(){
    const ks = Object.keys(skSel); if(!ks.length) return;
    const done = [];
    ks.forEach(n => {
      const q = Math.max(0, skInt(skSel[n]) || 0); if(skShMode === 'add' && q <= 0) return;
      if(!stkTracked(n)){ STK.prod[n] = { q: 0 }; stkPMove(n, 0, 'start'); }
      if(skShMode === 'add') stkPMove(n, q, 'in'); else stkPMove(n, q - STK.prod[n].q, 'set');
      done.push(q + ' ' + n);
    });
    skCloseSheet(); if(!done.length) return; skSave();
    showToast(done.slice(0, 3).join(', ') + (done.length > 3 ? ' +' + (done.length - 3) + ' ürün' : '') + (skShMode === 'add' ? ' stoğa eklendi.' : ' olarak sayıldı.'));
  }
  function skSetForm(n){
    if(!stkTracked(n)) return; const x = STK.prod[n];
    openForm({ title: n, sub: 'Raftaki gerçek adedi yazın; stok bu sayıya eşitlenir.', fields: [
      { id: 'qty', label: 'Mevcut adet', type: 'number', step: '1', value: Math.floor(x.q) },
      { id: 'min', label: 'Azalınca uyar (adet)', type: 'number', step: '1', value: stkLow(n) }
    ], onOk(v){
      const q = skInt(v.qty), m = skInt(v.min);
      if(!(q >= 0)) return 'Adet 0 veya daha büyük olmalı.'; if(!(m >= 0)) return 'Uyarı adedi geçersiz.';
      x.min = m; if(q !== Math.floor(x.q)) stkPMove(n, q - x.q, 'set'); skSave();
    } });
  }
  // ---- olaylar ----
  document.addEventListener('click', e => {
    const sh = e.target.closest('#skSheet');
    if(sh){
      if(e.target.id === 'skSheet'){ skCloseSheet(); return; }
      const sx = e.target.closest('[data-sx]');
      if(sx){ const v = sx.dataset.sx;
        if(v === 'close') skCloseSheet(); else if(v === 'ok') skApply();
        else if(v.indexOf('m:') === 0){ skShMode = v.slice(2); skSheetRender(); }
        else if(v.indexOf('c:') === 0){ skShCat = v.slice(2); skSheetRender(); }
        return; }
      const tile = e.target.closest('.sk-tile'); if(!tile) return; const n = tile.dataset.sn, sp = e.target.closest('[data-sp]');
      if(e.target.closest('[data-sq]')) return;
      if(sp){ const d = +sp.dataset.sp, cur = skInt(skSel[n]); skSel[n] = Math.max(skShMode === 'add' ? 1 : 0, (isFinite(cur) ? cur : 0) + d); if(skSel[n] === 0 && skShMode === 'add') delete skSel[n]; }
      else if(Object.prototype.hasOwnProperty.call(skSel, n)){ if(!e.target.closest('.sk-tctl')) delete skSel[n]; }
      else skSel[n] = skShMode === 'add' ? 1 : (stkTracked(n) ? Math.floor(STK.prod[n].q) : 0);
      skSheetRender(); return;
    }
    if(!e.target.closest('#screen-stok')) return;
    const sm = e.target.closest('#stkModes [data-sm]'); if(sm){ stkMode = sm.dataset.sm; stkRender(); return; }
    const sf = e.target.closest('[data-sf]'); if(sf){ skF.f = sf.dataset.sf; stkRender(); return; }
    const sc = e.target.closest('[data-sc]'); if(sc){ skF.cat = sc.dataset.sc; stkRender(); return; }
    const b = e.target.closest('[data-sa]'); if(!b || b.disabled) return; e.stopPropagation();
    const a = b.dataset.sa, n = b.dataset.n;
    if(a === 'add') skOpenSheet();
    else if(a === 'vis'){ skVis = !skVis; stkRender(); }
    else if(a === 'inc' && stkTracked(n)){ stkPMove(n, 1, 'in'); skSave(); }
    else if(a === 'dec' && stkTracked(n)){ stkPMove(n, -1, 'out'); skSave(); }
    else if(a === 'set') skSetForm(n);
    else if(a === 'on'){ STK.prod[n] = { q: 0 }; stkPMove(n, 0, 'start'); skSave(); skSetForm(n); }
    else if(a === 'off' && stkTracked(n)){ if(confirm(n + ' için stok takibi bırakılsın mı? Ürün normal şekilde satılmaya devam eder.')){ stkPMove(n, 0, 'stop'); delete STK.prod[n]; skSave(); } }
    else if(a.indexOf('cust:') === 0){ STK.pset.cust = a.slice(5); skSave(); }
    else if(a.indexOf('tg:') === 0){ const k = a.slice(3); STK.pset[k] = !STK.pset[k]; skSave(); }
  }, true);
  document.addEventListener('input', e => {
    if(e.target.id === 'skSearch'){ skF.q = e.target.value; const g = $id('skGrid'); if(g) g.innerHTML = skGridHtml(); return; }
    if(e.target.id === 'skShSearch'){ skShQ = e.target.value; const g = document.getElementById('skShGrid'); if(g) g.innerHTML = skShGrid(); return; }
    if(e.target.matches && e.target.matches('#skSheet [data-sq]')){ const t = e.target.closest('.sk-tile'); if(t){ const v = skInt(e.target.value); skSel[t.dataset.sn] = isFinite(v) ? Math.max(0, v) : 0; skShSum(); } }
  });
  document.addEventListener('change', e => { if(e.target.id === 'skLow' && e.target.closest('#screen-stok')){ const v = skInt(e.target.value); if(v >= 1 && v <= 999){ STK.pset.low = v; skSave(); } else e.target.value = STK.pset.low; } });
  // ---- stil ----
  (function(){
    const st = document.createElement('style'); st.textContent = `
.stk2 .sk-seg{display:inline-flex;background:rgba(120,120,128,.13);border-radius:12px;padding:3px;gap:2px;flex-wrap:wrap}
.stk2 .sk-seg button,.sk-ov .sk-seg button{border:0;background:transparent;color:var(--ink-dim,#666);padding:7px 13px;border-radius:10px;font:600 .85rem inherit;cursor:pointer}
.stk2 .sk-seg button.on,.sk-ov .sk-seg button.on{background:var(--panel,#fff);color:var(--ink,#222);box-shadow:0 1px 4px rgba(0,0,0,.14)}
.stk2 .sk-seg button:disabled{opacity:.5;cursor:not-allowed}
#stkModes{margin:4px 0 16px}
.sk-kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px}
.sk-kpi{border:1px solid var(--line,#e3e3e3);background:var(--panel,#fff);border-radius:14px;padding:12px 14px}.sk-kpi small{display:block;color:var(--ink-dim,#777);font-size:.76rem}.sk-kpi b{font-size:1.6rem;line-height:1.2}
.sk-kpi.warn b{color:#d98c00}.sk-kpi.bad b{color:#d64545}
.sk-tools{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:10px}
.sk-search{flex:1;min-width:150px;padding:10px 14px;border:1px solid var(--line,#ddd);border-radius:12px;background:var(--panel,#fff);color:inherit;font:inherit;box-sizing:border-box}
.sk-chips{display:flex;gap:6px;overflow-x:auto;padding:2px 0 8px;margin-bottom:6px;scrollbar-width:none}.sk-chips::-webkit-scrollbar{display:none}
.sk-chip{white-space:nowrap;border:1px solid var(--line,#ddd);background:var(--panel,#fff);color:inherit;border-radius:999px;padding:6px 13px;font:500 .82rem inherit;cursor:pointer}
.sk-chip.on{background:var(--ink,#222);color:var(--panel,#fff);border-color:transparent}
.sk-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(215px,1fr));gap:12px}
.sk-card{border:1px solid var(--line,#e3e3e3);background:var(--panel,#fff);border-radius:16px;padding:13px;display:flex;flex-direction:column;gap:9px;transition:box-shadow .15s}
.sk-card:hover{box-shadow:0 4px 16px rgba(0,0,0,.07)}.sk-card.off{opacity:.7}
.sk-card.bad{border-color:rgba(214,69,69,.4)}.sk-card.warn{border-color:rgba(217,140,0,.4)}
.sk-top{display:flex;gap:10px;align-items:center}.sk-vis{width:46px;height:46px;flex:0 0 46px;border-radius:12px;overflow:hidden;position:relative}
.sk-vis .vis{width:100%!important;height:100%!important;min-height:0!important;border-radius:12px;aspect-ratio:auto}
.sk-nm{flex:1;min-width:0}.sk-nm b{display:block;font-size:.93rem;line-height:1.25;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.sk-nm small{color:var(--ink-faint,#999);font-size:.74rem}
.sk-pill{font-size:.7rem;font-weight:700;padding:3px 9px;border-radius:999px;white-space:nowrap}
.sk-pill.ok{background:rgba(31,157,106,.14);color:#1f9d6a}.sk-pill.warn{background:rgba(217,140,0,.16);color:#c07a00}.sk-pill.bad{background:rgba(214,69,69,.15);color:#d64545}
.sk-q{display:flex;align-items:baseline;gap:6px}.sk-q b{font-size:2rem;line-height:1}.sk-q span{color:var(--ink-dim,#777);font-size:.85rem}.sk-q em{margin-left:auto;font-style:normal;font-size:.74rem;color:var(--ink-faint,#999)}
.sk-bar{height:6px;border-radius:6px;background:rgba(120,120,128,.15);overflow:hidden}.sk-bar i{display:block;height:100%;border-radius:6px}
.sk-bar i.ok{background:#1f9d6a}.sk-bar i.warn{background:#e0a100}.sk-bar i.bad{background:#d64545}
.sk-act{display:flex;gap:6px;align-items:center}.sk-nt{font-size:.8rem;color:var(--ink-faint,#999)}
.sk-sq{width:38px;height:38px;border-radius:11px;border:1px solid var(--line,#ddd);background:var(--panel,#fff);color:inherit;font-size:1.15rem;cursor:pointer}
.sk-btn{border:1px solid var(--line,#ddd);background:var(--panel,#fff);color:inherit;border-radius:11px;padding:0 14px;height:38px;font:600 .84rem inherit;cursor:pointer}.sk-btn.ghost{margin-left:auto;padding:0 12px}
.sk-sq:hover,.sk-btn:hover{border-color:var(--ink-dim,#999)}
.sk-primary{border:0;background:var(--red,#cf2e2e);color:#fff;border-radius:12px;padding:11px 20px;font:700 .92rem inherit;cursor:pointer}.sk-primary:disabled{opacity:.45;cursor:not-allowed}
.sk-empty{text-align:center;padding:42px 16px;color:var(--ink-dim,#777)}.sk-empty b{display:block;font-size:1.05rem;color:var(--ink,#222);margin:6px 0 4px}.sk-empty p{max-width:380px;margin:0 auto 16px;font-size:.88rem}.sk-ei{font-size:2.4rem}
.sk-vp{border:1px solid var(--line,#e3e3e3);background:var(--panel,#fff);border-radius:16px;padding:14px 16px;margin-bottom:14px}.sk-vph{margin-bottom:6px}.sk-vph small{display:block;color:var(--ink-faint,#999);font-size:.78rem}
.sk-row{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:11px 0;border-top:1px solid var(--line,#eee)}.sk-row.col{flex-direction:column;align-items:flex-start}
.sk-row small{display:block;color:var(--ink-faint,#999);font-size:.76rem;margin-top:2px}
.sk-tg{width:46px;height:26px;border-radius:99px;border:0;background:rgba(120,120,128,.3);position:relative;cursor:pointer;flex:0 0 46px;transition:background .15s}
.sk-tg i{position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:left .15s}.sk-tg.on{background:#1f9d6a}.sk-tg.on i{left:23px}.sk-tg:disabled{opacity:.5}
.sk-num{width:78px;padding:8px;border:1px solid var(--line,#ddd);border-radius:10px;background:var(--panel,#fff);color:inherit;font:inherit;text-align:center}
.sk-log{border:1px solid var(--line,#e3e3e3);border-radius:16px;overflow:hidden;background:var(--panel,#fff)}
.sk-lr{display:flex;align-items:center;gap:12px;padding:11px 14px;border-top:1px solid var(--line,#eee)}.sk-lr:first-child{border-top:0}
.sk-ld{min-width:52px;text-align:center;font-weight:700;padding:5px 8px;border-radius:9px;background:rgba(120,120,128,.13)}.sk-ld.in{background:rgba(31,157,106,.14);color:#1f9d6a}.sk-ld.out{background:rgba(214,69,69,.13);color:#d64545}
.sk-lm{flex:1;min-width:0}.sk-lm small{display:block;color:var(--ink-faint,#999);font-size:.76rem}.sk-lr time{color:var(--ink-faint,#999);font-size:.76rem;white-space:nowrap}
.sk-ov{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:2500;display:none;align-items:center;justify-content:center;padding:14px}
.sk-sheet{background:var(--panel,#fff);color:var(--ink,#222);width:100%;max-width:860px;max-height:92vh;border-radius:20px;display:flex;flex-direction:column;padding:18px;gap:10px;box-shadow:0 24px 70px rgba(0,0,0,.35)}
.sk-sh-head{display:flex;justify-content:space-between;align-items:flex-start;gap:10px}.sk-sh-head b{font-size:1.15rem}.sk-sh-head small{display:block;color:var(--ink-faint,#888);font-size:.8rem;margin-top:2px}
.sk-x{border:0;background:rgba(120,120,128,.15);width:34px;height:34px;border-radius:50%;cursor:pointer;color:inherit;font-size:1rem}
.sk-seg2{align-self:flex-start}
.sk-sh-grid{flex:1;overflow:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;padding:2px;align-content:start;min-height:180px}
.sk-tile{border:1.5px solid var(--line,#e3e3e3);border-radius:14px;padding:10px;display:flex;flex-direction:column;gap:5px;cursor:pointer;background:var(--panel,#fff)}
.sk-tile .sk-vis{width:100%;height:78px;flex:none}.sk-tile b{font-size:.85rem;line-height:1.25;min-height:2.1em}.sk-tile small{color:var(--ink-faint,#999);font-size:.72rem}
.sk-tile.on{border-color:var(--red,#cf2e2e);box-shadow:0 0 0 2px rgba(207,46,46,.12)}
.sk-tctl{display:flex;align-items:center;gap:4px;margin-top:2px}.sk-tctl.pick{justify-content:center;color:var(--red,#cf2e2e);font-weight:700;font-size:.82rem;padding:6px 0}
.sk-tctl button{width:30px;height:32px;border:1px solid var(--line,#ddd);background:var(--panel,#fff);color:inherit;border-radius:9px;font-size:1rem;cursor:pointer}
.sk-tctl input{flex:1;min-width:0;width:100%;height:32px;border:1px solid var(--line,#ddd);border-radius:9px;text-align:center;font:700 .95rem inherit;background:var(--panel,#fff);color:inherit}
.sk-sh-foot{display:flex;align-items:center;justify-content:space-between;gap:12px;border-top:1px solid var(--line,#eee);padding-top:12px}#skShSum{font-size:.9rem;color:var(--ink-dim,#666)}
.sk-none{grid-column:1/-1;text-align:center;color:var(--ink-faint,#999);padding:30px 0}
.sk-mini{position:absolute;top:8px;right:8px;font-size:.7rem;font-weight:700;padding:3px 8px;border-radius:999px;z-index:2;backdrop-filter:blur(4px)}
.sk-mini.ok{background:rgba(31,157,106,.9);color:#fff}.sk-mini.warn{background:rgba(224,161,0,.95);color:#fff}.sk-mini.bad{background:rgba(214,69,69,.95);color:#fff}
.mp-card{position:relative}
.c-item{position:relative}.c-stk{display:inline-block;margin-top:4px;font-size:.72rem;font-weight:700;padding:2px 9px;border-radius:999px}
.c-stk.out{background:rgba(214,69,69,.14);color:#d64545}.c-stk.low{background:rgba(224,161,0,.18);color:#b57d00}
.c-item.c-out .vis{filter:grayscale(1);opacity:.55}.c-item.c-out .nm b{opacity:.6}.c-soldout{font-size:.78rem;font-weight:700;color:#d64545}
@media(max-width:560px){.sk-kpis{gap:8px}.sk-kpi{padding:10px}.sk-kpi b{font-size:1.35rem}.sk-grid{grid-template-columns:repeat(2,1fr)}.sk-sheet{max-height:96vh;padding:14px}.sk-sh-grid{grid-template-columns:repeat(2,1fr)}.sk-tools .sk-seg{width:100%}}
`; document.head.appendChild(st);
  })();

  const skPack = () => Object.keys(STK.prod).map(n => ({ n, q: STK.prod[n].q, m: (STK.prod[n].min == null || !isFinite(STK.prod[n].min)) ? null : STK.prod[n].min }));
  function custStk(n){
    const pd = getPub(), st = pd && pd.stock; if(!st || !st.m || st.m === 'hide') return null;
    if(arr(st.o).indexOf(n) >= 0) return { out: 1, b: st.b };
    const l = arr(st.l).find(x => x && x.n === n); if(st.m === 'low' && l) return { left: +l.q, b: st.b };
    return null;
  }
  const _ssv = saveState; saveState = function(){ const r = _ssv.apply(this, arguments); try{ stkPushPublic(); }catch(e){} return r; };
  setInterval(() => { try{ const sc = $id('screen-stok'), a = document.activeElement, sh = document.getElementById('skSheet'); if(sc && sc.offsetParent && stkMode !== 'adv' && !(a && /INPUT|TEXTAREA|SELECT/.test(a.tagName)) && !(sh && sh.style.display === 'flex')) stkLiveRender(); }catch(e){} }, 5000);

  smFullApply('siparis-masa');
  bootApp();

